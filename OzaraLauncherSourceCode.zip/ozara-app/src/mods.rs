//! Bloxstrap-style content mods: files you drop in Ozara's Mods folder get copied
//! into Roblox's content folder when you apply them, so you can swap cosmetic
//! assets like the skybox. This DOES modify Roblox's installed files (same as
//! Bloxstrap's Mods), so it carries a small risk and is off by default.
//!
//! The Mods folder mirrors a Roblox version folder, e.g. a file at
//! `Mods/content/sky/sky512_bk.tex` is copied to
//! `Versions/<ver>/content/sky/sky512_bk.tex`. The original it overwrites is
//! backed up next to it as `<name>.ozara-bak`, so mods can be removed cleanly.

use std::path::{Path, PathBuf};

pub fn mods_dir() -> PathBuf {
    let dir = crate::sys::data_dir().join("Mods");
    let _ = std::fs::create_dir_all(&dir);
    dir
}

/// Every file inside the Mods folder, as paths relative to it.
fn mod_files() -> Vec<PathBuf> {
    let root = mods_dir();
    let mut out = Vec::new();
    walk(&root, &root, &mut out);
    out
}

fn walk(base: &Path, dir: &Path, out: &mut Vec<PathBuf>) {
    let Ok(entries) = std::fs::read_dir(dir) else { return };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            walk(base, &path, out);
        } else if let Ok(rel) = path.strip_prefix(base) {
            out.push(rel.to_path_buf());
        }
    }
}

fn backup_path(target: &Path) -> PathBuf {
    let mut name = target.file_name().unwrap_or_default().to_os_string();
    name.push(".ozara-bak");
    target.with_file_name(name)
}

/// Copies every mod file into each Roblox version's folder, backing up any
/// original it overwrites. Returns how many files were applied (per version).
pub fn apply(version_dirs: &[PathBuf]) -> Result<usize, String> {
    let files = mod_files();
    if files.is_empty() {
        return Err("Your Mods folder is empty — put files in it first.".into());
    }
    let src_root = mods_dir();
    let mut applied = 0usize;
    for version in version_dirs {
        for rel in &files {
            let src = src_root.join(rel);
            let target = version.join(rel);
            if let Some(parent) = target.parent() {
                std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            // Back up the original once, so Remove can restore it.
            let bak = backup_path(&target);
            if target.exists() && !bak.exists() {
                std::fs::rename(&target, &bak).map_err(|e| e.to_string())?;
            }
            make_writable(&target); // clear any read-only lock from a previous apply
            std::fs::copy(&src, &target).map_err(|e| format!("Could not copy a mod file: {e}"))?;
            applied += 1;
        }
    }
    Ok(applied)
}

fn make_writable(path: &Path) {
    if let Ok(meta) = std::fs::metadata(path) {
        let mut perm = meta.permissions();
        #[allow(clippy::permissions_set_readonly_false)]
        perm.set_readonly(false);
        let _ = std::fs::set_permissions(path, perm);
    }
}

/// Theme guard: rewrites any applied mod file whose installed copy is missing or
/// differs from the Mods-folder source, so branding can't be casually stripped
/// while Ozara runs. Returns how many files it restored. Cheap for a small theme.
pub fn heal(version_dirs: &[PathBuf]) -> usize {
    let files = mod_files();
    let src_root = mods_dir();
    let mut healed = 0usize;
    for version in version_dirs {
        for rel in &files {
            let Ok(want) = std::fs::read(src_root.join(rel)) else {
                continue;
            };
            let target = version.join(rel);
            if std::fs::read(&target).ok().as_deref() == Some(want.as_slice()) {
                continue; // already correct
            }
            make_writable(&target); // in case it was locked read-only
            if let Some(parent) = target.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            if std::fs::write(&target, &want).is_ok() {
                healed += 1;
            }
        }
    }
    healed
}

/// Sets (or clears) the read-only attribute on every applied theme file — a
/// first-line deterrent against casual edits.
pub fn set_locked(version_dirs: &[PathBuf], locked: bool) {
    let files = mod_files();
    for version in version_dirs {
        for rel in &files {
            let target = version.join(rel);
            if let Ok(meta) = std::fs::metadata(&target) {
                let mut perm = meta.permissions();
                perm.set_readonly(locked);
                let _ = std::fs::set_permissions(&target, perm);
            }
        }
    }
}

/// Undoes `apply`: restores backed-up originals and deletes mod files that were
/// brand new (no original existed).
pub fn remove(version_dirs: &[PathBuf]) -> Result<(), String> {
    let files = mod_files();
    for version in version_dirs {
        for rel in &files {
            let target = version.join(rel);
            make_writable(&target); // clear the read-only lock so we can restore
            let bak = backup_path(&target);
            if bak.exists() {
                let _ = std::fs::remove_file(&target);
                std::fs::rename(&bak, &target).map_err(|e| e.to_string())?;
            } else if target.exists() {
                let _ = std::fs::remove_file(&target);
            }
        }
    }
    Ok(())
}
