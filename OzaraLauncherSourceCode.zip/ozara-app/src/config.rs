//! Sign-in settings. Ozara needs a Roblox OAuth app ("client ID") registered by you.

/// Port Ozara listens on for Roblox's redirect. Register this exact redirect URL in the Creator Dashboard:
/// http://localhost:53682/callback
pub const REDIRECT_PORT: u16 = 53682;

pub fn redirect_uri() -> String {
    format!("http://localhost:{REDIRECT_PORT}/callback")
}

/// Client ID from the OAuth 2.0 Apps page. Taken from the OZARA_CLIENT_ID environment variable,
/// or from the file `client_id.txt` in Ozara's data folder (%APPDATA%\Ozara).
pub fn client_id() -> Option<String> {
    if let Ok(v) = std::env::var("OZARA_CLIENT_ID") {
        let v = v.trim().to_string();
        if !v.is_empty() {
            return Some(v);
        }
    }
    let file = crate::sys::data_dir().join("client_id.txt");
    std::fs::read_to_string(file)
        .ok()
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
}
