//! Detects the overlay shortcut by polling the keyboard state with Windows' own
//! `GetAsyncKeyState`. This is the same public, documented API push-to-talk and
//! screenshot tools use to notice a key is held even when their window isn't
//! focused — it reads key state, not other processes' memory, and installs no
//! hook. Not injection, not a cheat.
//!
//! The trigger is F8. A function key has one fixed virtual-key code on every
//! keyboard layout, unlike ';', which moves around (and sits in different places
//! on a Czech vs. a US layout) — that layout dependence is why the old Ctrl+;
//! shortcut was unreliable.

/// The virtual-key code Ozara listens for. VK_F8 = 0x77.
#[cfg(windows)]
pub const TRIGGER_LABEL: &str = "F8";

#[cfg(not(windows))]
pub const TRIGGER_LABEL: &str = "F8";

#[cfg(windows)]
pub fn start(tx: std::sync::mpsc::Sender<crate::Msg>, ctx: eframe::egui::Context) {
    use std::time::Duration;
    use windows_sys::Win32::Foundation::POINT;
    use windows_sys::Win32::UI::Input::KeyboardAndMouse::{GetAsyncKeyState, VK_F8, VK_LBUTTON};
    use windows_sys::Win32::UI::WindowsAndMessaging::GetCursorPos;

    fn is_down(vk: i32) -> bool {
        (unsafe { GetAsyncKeyState(vk) } as u16) & 0x8000 != 0
    }

    crate::sys::debug_log("hotkey listener started (F8 + badge click)");
    std::thread::spawn(move || {
        let (mut f8_was, mut lmb_was) = (false, false);
        loop {
            std::thread::sleep(Duration::from_millis(30));

            let f8 = is_down(VK_F8 as i32);
            if f8 && !f8_was {
                crate::sys::debug_log("F8 pressed");
                let _ = tx.send(crate::Msg::ToggleOverlay);
                ctx.request_repaint();
            }
            f8_was = f8;

            // Catch a left-click that lands on the corner badge. The badge window
            // can't receive the click itself (it never takes focus), so we check
            // the cursor against the badge's published screen rectangle.
            let lmb = is_down(VK_LBUTTON as i32);
            if lmb && !lmb_was {
                let mut pt = POINT { x: 0, y: 0 };
                if unsafe { GetCursorPos(&mut pt) } != 0 && crate::badge::hit(pt.x, pt.y) {
                    crate::sys::debug_log("badge clicked");
                    let _ = tx.send(crate::Msg::ShowOverlay);
                    ctx.request_repaint();
                }
            }
            lmb_was = lmb;
        }
    });
}

#[cfg(not(windows))]
pub fn start(_tx: std::sync::mpsc::Sender<crate::Msg>, _ctx: eframe::egui::Context) {}
