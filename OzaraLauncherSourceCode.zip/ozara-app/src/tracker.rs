//! Watches Roblox's log file to record playtime sessions and know the current server.

use crate::sys::now_unix;
use ozara_core::{logs, paths, playtime};
use std::fs;
use std::path::{Path, PathBuf};

pub struct Tracker {
    roblox: Option<PathBuf>,
    file: PathBuf,
    pub sessions: Vec<playtime::Session>,
    /// Server the player is in right now, if the log says so.
    pub current: Option<logs::JoinEvent>,
    /// Index into `sessions` of the session still running.
    open: Option<usize>,
}

impl Tracker {
    pub fn new(roblox: Option<PathBuf>, data_dir: &Path) -> Self {
        let file = data_dir.join("playtime.tsv");
        let sessions = fs::read_to_string(&file)
            .map(|t| playtime::parse_sessions(&t))
            .unwrap_or_default();
        Tracker {
            roblox,
            file,
            sessions,
            current: None,
            open: None,
        }
    }

    /// Call every few seconds.
    pub fn tick(&mut self) {
        let Some(roblox) = &self.roblox else { return };
        let text = paths::latest_player_log(&paths::logs_dir(roblox))
            .and_then(|p| fs::read_to_string(p).ok())
            .unwrap_or_default();
        let now = now_unix();
        let current = logs::current_join(&text);

        // A different server (or none) ends the running session.
        let changed = match (&self.current, &current) {
            (Some(a), Some(b)) => a.job_id != b.job_id,
            (None, None) => false,
            _ => true,
        };
        if changed {
            self.open = None;
        }
        if let Some(ev) = &current {
            match self.open {
                Some(i) => self.sessions[i].end = now,
                None => {
                    let start = ev.at.unwrap_or(now);
                    // Ozara may have been restarted mid-game: carry on the saved session.
                    let existing = self
                        .sessions
                        .iter()
                        .position(|s| s.place_id == ev.place_id && s.start == start);
                    let i = match existing {
                        Some(i) => i,
                        None => {
                            self.sessions.push(playtime::Session {
                                place_id: ev.place_id.clone(),
                                start,
                                end: now,
                            });
                            self.sessions.len() - 1
                        }
                    };
                    self.sessions[i].end = now;
                    self.open = Some(i);
                }
            }
            self.save();
        }
        self.current = current;
    }

    fn save(&self) {
        let text: String = self
            .sessions
            .iter()
            .map(|s| playtime::format_session(s) + "\n")
            .collect();
        let _ = fs::write(&self.file, text);
    }

    /// Fold in sessions found by `scan_backfill`: skips anything already known
    /// (same place and start), appends the rest, and saves if anything changed.
    /// Returns whether any session was actually added.
    pub fn merge_backfill(&mut self, extra: Vec<playtime::Session>) -> bool {
        let mut added = false;
        for s in extra {
            let known = self
                .sessions
                .iter()
                .any(|e| e.place_id == s.place_id && e.start == s.start);
            if !known {
                self.sessions.push(s);
                added = true;
            }
        }
        if added {
            self.save();
        }
        added
    }
}

/// Reads every Roblox Player log Ozara can find (capped at the most recent 200,
/// so a machine with years of logs doesn't stall startup) and turns them into
/// playtime sessions, so history from before Ozara was ever opened still shows
/// up. Does real file I/O, so it belongs on a background thread.
pub fn scan_backfill(roblox: &Path) -> Vec<playtime::Session> {
    let mut sessions = Vec::new();
    for path in paths::recent_player_logs(&paths::logs_dir(roblox), 200) {
        let Ok(text) = fs::read_to_string(&path) else {
            continue;
        };
        for (ev, end) in logs::sessions_from_log(&text) {
            let Some(start) = ev.at else { continue };
            if end >= start {
                sessions.push(playtime::Session {
                    place_id: ev.place_id,
                    start,
                    end,
                });
            }
        }
    }
    sessions
}
