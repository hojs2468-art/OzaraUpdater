//! System-tray icon. Closing the window hides Ozara to the tray instead of quitting;
//! click the tray icon (or "Open Ozara") to bring it back, "Quit Ozara" to exit.
//! Only uses the normal Windows notification area: nothing is injected anywhere.

use eframe::egui;
use std::sync::atomic::{AtomicBool, Ordering};

static QUITTING: AtomicBool = AtomicBool::new(false);

/// True once "Quit Ozara" was chosen, so the close request is allowed through.
pub fn quitting() -> bool {
    QUITTING.load(Ordering::SeqCst)
}

/// Keeps the tray icon alive for as long as it is held.
#[cfg(windows)]
pub struct Tray {
    _icon: tray_icon::TrayIcon,
}

#[cfg(not(windows))]
pub struct Tray;

#[cfg(windows)]
fn show(ctx: &egui::Context) {
    // Bring the window back on-screen (it's parked far off-screen while "in tray",
    // not hidden, so the overlay keeps drawing) and back into the taskbar.
    crate::sys::set_taskbar_visible("Ozara", true);
    ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(egui::pos2(100.0, 80.0)));
    ctx.send_viewport_cmd(egui::ViewportCommand::Visible(true));
    ctx.send_viewport_cmd(egui::ViewportCommand::Minimized(false));
    ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
    ctx.request_repaint();
}

#[cfg(windows)]
fn quit_now(ctx: &egui::Context) -> ! {
    QUITTING.store(true, Ordering::SeqCst);
    ctx.send_viewport_cmd(egui::ViewportCommand::Close);
    ctx.request_repaint();
    // Playtime is saved every few seconds, so a hard exit loses nothing.
    std::thread::sleep(std::time::Duration::from_millis(1500));
    std::process::exit(0);
}

#[cfg(windows)]
pub fn start(tx: std::sync::mpsc::Sender<crate::Msg>, ctx: &egui::Context) -> Option<Tray> {
    use tray_icon::menu::{Menu, MenuEvent, MenuItem};
    use tray_icon::{Icon, MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};

    // The real Ozara mark, not the window-titlebar icon, so the tray matches the brand.
    let img = image::load_from_memory(include_bytes!("../assets/mark.png"))
        .ok()?
        .into_rgba8();
    let (w, h) = (img.width(), img.height());
    let icon = Icon::from_rgba(img.into_raw(), w, h).ok()?;

    let open = MenuItem::new("Open Ozara", true, None);
    let overlay = MenuItem::new("Show overlay", true, None);
    let quit = MenuItem::new("Quit Ozara", true, None);
    let menu = Menu::new();
    menu.append(&open).ok()?;
    menu.append(&overlay).ok()?;
    menu.append(&quit).ok()?;

    let tray = TrayIconBuilder::new()
        .with_tooltip("Ozara")
        .with_icon(icon)
        .with_menu(Box::new(menu))
        .with_menu_on_left_click(false)
        .build()
        .ok()?;

    let open_id = open.id().clone();
    let overlay_id = overlay.id().clone();
    let quit_id = quit.id().clone();
    let ctx = ctx.clone();
    std::thread::spawn(move || {
        let mut ticks = 0u32;
        loop {
            while let Ok(ev) = MenuEvent::receiver().try_recv() {
                if ev.id == open_id {
                    show(&ctx);
                } else if ev.id == overlay_id {
                    // Bypasses the focus check — the tray is a deliberate "show it now".
                    let _ = tx.send(crate::Msg::ShowOverlay);
                    ctx.request_repaint();
                } else if ev.id == quit_id {
                    quit_now(&ctx);
                }
            }
            while let Ok(ev) = TrayIconEvent::receiver().try_recv() {
                if let TrayIconEvent::Click {
                    button: MouseButton::Left,
                    button_state: MouseButtonState::Up,
                    ..
                } = ev
                {
                    show(&ctx);
                }
            }
            // A hidden window may stop redrawing; a slow nudge keeps playtime tracking ticking.
            ticks += 1;
            if ticks % 40 == 0 {
                ctx.request_repaint();
            }
            std::thread::sleep(std::time::Duration::from_millis(120));
        }
    });
    Some(Tray { _icon: tray })
}

#[cfg(not(windows))]
pub fn start(_tx: std::sync::mpsc::Sender<crate::Msg>, _ctx: &egui::Context) -> Option<Tray> {
    None
}
