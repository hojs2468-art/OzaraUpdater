//! Texture-cache downscaler. After you've loaded a game once, its textures sit
//! in Roblox's local asset cache. This scans that cache and shrinks the PNG
//! image blobs in place, which lowers texture detail and VRAM use. It never
//! touches Roblox's memory or code — it only rewrites local image files, and
//! it's reversible by clearing the Roblox cache (Roblox re-downloads originals).
//!
//! Safety choices:
//!   * Only files that are a *raw* PNG (signature at byte 0) are rewritten, so
//!     we never corrupt a wrapped/length-prefixed cache entry.
//!   * A size floor stops small images (UI icons, fonts) from being touched.
//!   * Scan mode changes nothing — it just reports what's there.

use ozara_core::texcache::{self, RawFmt};
use std::io::{Cursor, Read};
use std::path::{Path, PathBuf};

const MAX_FILE_BYTES: u64 = 32 * 1024 * 1024; // skip anything bigger than a texture
const MAX_FILES: usize = 300_000; // don't walk forever on a huge cache
const SCAN_HEAD: usize = 128; // bytes read per file in scan (RBXH header + PNG IHDR)

/// Where the resize quality knob lives; Triangle is a good speed/quality mix.
const FILTER: image::imageops::FilterType = image::imageops::FilterType::Triangle;

#[derive(Default)]
pub struct Scan {
    pub dirs: usize,
    pub files: usize,
    pub shrinkable: usize,   // PNG/JPEG textures above the floor — these we shrink
    pub other_imgs: usize,   // WebP/KTX textures we can't re-encode, left alone
    pub largest: u32,        // biggest larger-side dimension seen
}

/// A cache entry's image body, located inside its RBXH wrapper (or at byte 0 for
/// a legacy raw file). `body_off` is where the image starts.
struct Located {
    body_off: usize,
    fmt: Option<RawFmt>,
    other_image: bool, // a WebP/KTX image body we recognise but can't re-encode
}

/// Works out where the image body is and whether we can shrink it, from the
/// file's leading bytes and its total length on disk.
fn locate(head: &[u8], file_len: u64) -> Located {
    let body_off = texcache::rbxh_inline_body(head, file_len as usize).unwrap_or(0);
    let body = head.get(body_off..).unwrap_or(&[]);
    let fmt = texcache::raw_fmt(body);
    // Recognise the texture formats we deliberately don't touch, to report them.
    let other_image = fmt.is_none()
        && (body.starts_with(b"RIFF") || body.starts_with(&[0xAB, b'K', b'T', b'X']));
    Located {
        body_off,
        fmt,
        other_image,
    }
}

#[derive(Default)]
pub struct Apply {
    pub shrunk: usize,
    pub skipped: usize,
    pub errors: usize,
    pub bytes_before: u64,
    pub bytes_after: u64,
}

/// The cache directories that actually exist on this PC.
pub fn existing_dirs() -> Vec<PathBuf> {
    let la = std::env::var("LOCALAPPDATA").unwrap_or_default();
    let tmp = std::env::var("TEMP").unwrap_or_default();
    texcache::cache_dirs(&la, &tmp)
        .into_iter()
        .filter(|d| d.is_dir())
        .collect()
}

fn walk(dir: &Path, out: &mut Vec<PathBuf>) {
    if out.len() >= MAX_FILES {
        return;
    }
    let Ok(entries) = std::fs::read_dir(dir) else {
        return;
    };
    for entry in entries.flatten() {
        if out.len() >= MAX_FILES {
            return;
        }
        let path = entry.path();
        match entry.file_type() {
            Ok(t) if t.is_dir() => walk(&path, out),
            Ok(t) if t.is_file() => out.push(path),
            _ => {}
        }
    }
}

/// Reads up to `n` leading bytes of a file.
fn read_head(path: &Path, n: usize) -> Option<Vec<u8>> {
    let mut f = std::fs::File::open(path).ok()?;
    let mut buf = vec![0u8; n];
    let read = f.read(&mut buf).ok()?;
    buf.truncate(read);
    Some(buf)
}

/// Image dimensions from a leading slice, by format. JPEG needs the SOF to be
/// within the slice; returns None if it isn't (apply reads the whole file).
fn dims(fmt: RawFmt, head: &[u8]) -> Option<(u32, u32)> {
    match fmt {
        RawFmt::Png => texcache::png_dims(head),
        RawFmt::Jpeg => texcache::jpeg_dims(head),
    }
}

/// The `image` format tag to re-encode back into, matching the source.
fn out_fmt(fmt: RawFmt) -> image::ImageFormat {
    match fmt {
        RawFmt::Png => image::ImageFormat::Png,
        RawFmt::Jpeg => image::ImageFormat::Jpeg,
    }
}

/// Looks at the cache without changing anything. `cap` is the target max side
/// (0 = original): "shrinkable" counts textures larger than the cap.
pub fn scan(cap: u32) -> Scan {
    let dirs = existing_dirs();
    let mut report = Scan {
        dirs: dirs.len(),
        ..Default::default()
    };
    let mut files = Vec::new();
    for d in &dirs {
        walk(d, &mut files);
    }
    report.files = files.len();
    for path in &files {
        let Ok(meta) = std::fs::metadata(path) else {
            continue;
        };
        let Some(head) = read_head(path, SCAN_HEAD) else {
            continue;
        };
        let loc = locate(&head, meta.len());
        let body = &head[loc.body_off.min(head.len())..];
        if let Some(fmt) = loc.fmt {
            match dims(fmt, body) {
                Some((w, h)) => {
                    report.largest = report.largest.max(w.max(h));
                    if cap != 0 && w.max(h) > cap {
                        report.shrinkable += 1;
                    }
                }
                // JPEG SOF can sit past the 128-byte head; count as a candidate,
                // apply reads the whole file and decides exactly.
                None => report.shrinkable += 1,
            }
        } else if loc.other_image {
            report.other_imgs += 1;
        }
    }
    report
}

/// Shrinks every PNG/JPEG cache texture larger than `cap` pixels (0 = original,
/// does nothing). Cheap to re-run: files already within the cap are skipped from
/// the 128-byte head, without reading the whole file.
pub fn apply(cap: u32) -> Result<Apply, String> {
    let dirs = existing_dirs();
    if dirs.is_empty() {
        return Err("No Roblox asset cache found yet — load a game once, then try again.".into());
    }
    if cap == 0 {
        return Ok(Apply::default()); // "Original" — nothing to do
    }
    let mut files = Vec::new();
    for d in &dirs {
        walk(d, &mut files);
    }
    let mut out = Apply::default();
    for path in &files {
        let Ok(meta) = std::fs::metadata(path) else {
            continue;
        };
        if !meta.is_file() || meta.len() > MAX_FILE_BYTES {
            continue;
        }
        let Some(head) = read_head(path, SCAN_HEAD) else {
            continue;
        };
        // Find the image body (inside an RBXH wrapper, or raw at byte 0) and
        // confirm it's a PNG/JPEG we can re-encode. Everything else is skipped.
        let loc = locate(&head, meta.len());
        let Some(fmt) = loc.fmt else {
            continue;
        };
        // Cheap path: if the dimensions are already in the head (PNG always, and
        // small JPEGs) and the image is within the cap, skip without a full read.
        let head_body = &head[loc.body_off.min(head.len())..];
        if let Some((w, h)) = dims(fmt, head_body) {
            if texcache::cap_dims(w, h, cap) == (w, h) {
                out.skipped += 1;
                continue;
            }
        }
        let full = match std::fs::read(path) {
            Ok(b) => b,
            Err(_) => {
                out.errors += 1;
                continue;
            }
        };
        let body = &full[loc.body_off.min(full.len())..];
        let Some((w, h)) = dims(fmt, body) else {
            continue;
        };
        let (nw, nh) = texcache::cap_dims(w, h, cap);
        if (nw, nh) == (w, h) {
            out.skipped += 1;
            continue;
        }
        match shrink_file(path, &full, loc.body_off, fmt, nw, nh) {
            Ok((before, after)) => {
                out.shrunk += 1;
                out.bytes_before += before;
                out.bytes_after += after;
            }
            Err(_) => out.errors += 1,
        }
    }
    Ok(out)
}

/// Decodes the image body (at `body_off` inside `full`), resizes to (nw, nh),
/// re-encodes in the same format, re-wraps it in the RBXH container if there was
/// one, and overwrites the file. Returns (bytes before, bytes after).
fn shrink_file(
    path: &Path,
    full: &[u8],
    body_off: usize,
    fmt: RawFmt,
    nw: u32,
    nh: u32,
) -> Result<(u64, u64), String> {
    let before = full.len() as u64;
    let body = &full[body_off..];
    let img = image::load_from_memory_with_format(body, out_fmt(fmt)).map_err(|e| e.to_string())?;
    let resized = img.resize_exact(nw, nh, FILTER);
    let mut encoded = Cursor::new(Vec::new());
    resized
        .write_to(&mut encoded, out_fmt(fmt))
        .map_err(|e| e.to_string())?;
    let new_body = encoded.into_inner();
    // Put the smaller body back where it came from: inside the wrapper, or raw.
    let data = if body_off == 0 {
        new_body
    } else {
        texcache::rbxh_rewrap(full, &new_body)
    };
    let after = data.len() as u64;
    // Only write if we actually saved space — a tiny image can re-encode larger.
    if after >= before {
        return Ok((before, before));
    }
    std::fs::write(path, &data).map_err(|e| e.to_string())?;
    Ok((before, after))
}
