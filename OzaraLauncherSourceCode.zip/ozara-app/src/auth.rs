//! Sign in with Roblox: OAuth 2.0 authorization code flow with PKCE, through the browser.
//! Ozara never sees your password. It asks for `openid profile` (who you are) plus
//! two optional read-only scopes for premium/verified status and linked socials —
//! Roblox's consent screen lets the user decline either. The access token is used
//! once right after sign-in, then thrown away; it is never written to disk.

use crate::config;
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use ozara_core::oauth::{self, Callback};
use rand::RngCore;
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::io::{self, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::Path;
use std::time::{Duration, Instant};

#[derive(Clone, Debug)]
pub struct Profile {
    pub user_id: String,
    pub name: String,
    pub username: String,
    /// Premium/ID-verified status. Only ever `Some` for a real "Sign in with
    /// Roblox" (not the no-sign-in username link), and only when Roblox grants
    /// the `user.advanced:read` scope the sign-in asks for.
    pub verified: Option<bool>,
}

#[derive(Deserialize)]
struct TokenResp {
    access_token: String,
}

#[derive(Deserialize)]
struct UserInfo {
    sub: String,
    #[serde(default)]
    name: Option<String>,
    #[serde(default)]
    preferred_username: Option<String>,
}

#[derive(Deserialize, Default)]
struct CloudUser {
    #[serde(default)]
    verified: Option<bool>,
}

/// Roblox's Open Cloud "Get User" endpoint, called with the access token from
/// sign-in. Only returns anything useful if the token carries the
/// `user.advanced:read` scope; if Roblox didn't grant it (or anything else
/// goes wrong) this just returns `None` rather than failing the sign-in.
fn fetch_verified(user_id: &str, access_token: &str) -> Option<bool> {
    let url = format!("https://apis.roblox.com/cloud/v2/users/{user_id}");
    let resp = ureq::get(&url)
        .set("Authorization", &format!("Bearer {access_token}"))
        .call()
        .ok()?;
    resp.into_json::<CloudUser>().ok()?.verified
}

fn random_url_string(bytes: usize) -> String {
    let mut buf = vec![0u8; bytes];
    rand::thread_rng().fill_bytes(&mut buf);
    URL_SAFE_NO_PAD.encode(buf)
}

fn describe(e: ureq::Error) -> String {
    match e {
        ureq::Error::Status(code, resp) => {
            let body = resp.into_string().unwrap_or_default();
            let body: String = body.chars().take(200).collect();
            format!("Roblox answered with error {code}: {body}")
        }
        other => format!("Could not reach Roblox: {other}"),
    }
}

fn respond(stream: &mut TcpStream, status: u16, message: &str) {
    let body = format!(
        "<html><body style=\"font-family:sans-serif;background:#1a1328;color:#fff;text-align:center;padding-top:80px\"><h2>Ozara</h2><p>{message}</p></body></html>"
    );
    let reply = format!(
        "HTTP/1.1 {status} OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
        body.len()
    );
    let _ = stream.write_all(reply.as_bytes());
}

fn wait_for_code(
    listener: &TcpListener,
    expected_state: &str,
    timeout: Duration,
) -> Result<String, String> {
    listener.set_nonblocking(true).map_err(|e| e.to_string())?;
    let deadline = Instant::now() + timeout;
    loop {
        if Instant::now() > deadline {
            return Err("Sign-in timed out. Try again.".into());
        }
        match listener.accept() {
            Ok((mut stream, _)) => {
                let _ = stream.set_nonblocking(false);
                let _ = stream.set_read_timeout(Some(Duration::from_secs(5)));
                let mut buf = [0u8; 4096];
                let n = stream.read(&mut buf).unwrap_or(0);
                let request = String::from_utf8_lossy(&buf[..n]).to_string();
                match oauth::parse_callback(&request) {
                    Callback::Code { code, state } => {
                        if state != expected_state {
                            respond(
                                &mut stream,
                                400,
                                "Sign-in was rejected. You can close this tab.",
                            );
                            return Err("Sign-in was rejected (state mismatch).".into());
                        }
                        respond(
                            &mut stream,
                            200,
                            "You're signed in. You can close this tab and go back to Ozara.",
                        );
                        return Ok(code);
                    }
                    Callback::Denied(why) => {
                        respond(
                            &mut stream,
                            200,
                            "Sign-in was cancelled. You can close this tab.",
                        );
                        return Err(format!("Roblox sign-in was cancelled ({why})."));
                    }
                    Callback::Other => respond(&mut stream, 404, "Not found"),
                }
            }
            Err(e) if e.kind() == io::ErrorKind::WouldBlock => {
                std::thread::sleep(Duration::from_millis(100))
            }
            Err(e) => return Err(e.to_string()),
        }
    }
}

/// Runs the whole sign-in. Blocks until the user finishes in the browser, so call it on a thread.
pub fn sign_in(client_id: &str) -> Result<Profile, String> {
    let verifier = random_url_string(48);
    let challenge = URL_SAFE_NO_PAD.encode(Sha256::digest(verifier.as_bytes()));
    let state = random_url_string(16);
    let redirect = config::redirect_uri();

    let listener = TcpListener::bind(("127.0.0.1", config::REDIRECT_PORT)).map_err(|e| {
        format!(
            "Could not listen on port {} ({e}). Close other copies of Ozara and retry.",
            config::REDIRECT_PORT
        )
    })?;

    let url = oauth::authorize_url(client_id, &redirect, &challenge, &state);
    crate::sys::open_link(&url).map_err(|e| format!("Could not open your browser: {e}"))?;

    let code = wait_for_code(&listener, &state, Duration::from_secs(300))?;

    let token: TokenResp = ureq::post("https://apis.roblox.com/oauth/v1/token")
        .send_form(&[
            ("grant_type", "authorization_code"),
            ("code", code.as_str()),
            ("client_id", client_id),
            ("code_verifier", verifier.as_str()),
            ("redirect_uri", redirect.as_str()),
        ])
        .map_err(describe)?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;

    let info: UserInfo = ureq::get("https://apis.roblox.com/oauth/v1/userinfo")
        .set("Authorization", &format!("Bearer {}", token.access_token))
        .call()
        .map_err(describe)?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;

    let username = info.preferred_username.unwrap_or_default();
    let verified = fetch_verified(&info.sub, &token.access_token);
    Ok(Profile {
        user_id: info.sub,
        name: info
            .name
            .filter(|n| !n.is_empty())
            .unwrap_or_else(|| username.clone()),
        username,
        verified,
    })
}

fn profile_file(dir: &Path) -> std::path::PathBuf {
    dir.join("profile.tsv")
}

pub fn save_profile(dir: &Path, p: &Profile) {
    let verified = match p.verified {
        Some(true) => "1",
        Some(false) => "0",
        None => "",
    };
    let _ = std::fs::write(
        profile_file(dir),
        format!("{}\t{}\t{}\t{}\n", p.user_id, p.name, p.username, verified),
    );
}

pub fn load_profile(dir: &Path) -> Option<Profile> {
    let text = std::fs::read_to_string(profile_file(dir)).ok()?;
    let mut parts = text.trim_end().split('\t');
    let user_id = parts.next()?.to_string();
    if !ozara_core::join::is_numeric_id(&user_id) {
        return None;
    }
    let name = parts.next()?.to_string();
    let username = parts.next().unwrap_or("").to_string();
    // Older profile.tsv files (before this field existed) simply won't have a 4th column.
    let verified = match parts.next() {
        Some("1") => Some(true),
        Some("0") => Some(false),
        _ => None,
    };
    Some(Profile {
        user_id,
        name,
        username,
        verified,
    })
}

pub fn clear_profile(dir: &Path) {
    let _ = std::fs::remove_file(profile_file(dir));
}
