//! Talking to the operating system: opening links, closing and detecting Roblox.
//! Only normal, documented OS actions: no memory access, no hooks, no injection.

use std::path::PathBuf;
use std::process::Command;

pub fn local_app_data() -> Option<PathBuf> {
    std::env::var_os("LOCALAPPDATA").map(PathBuf::from)
}

/// Where Ozara keeps its own files (playtime, settings).
pub fn data_dir() -> PathBuf {
    let base = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")))
        .unwrap_or_else(|| PathBuf::from("."));
    let dir = base.join("Ozara");
    let _ = std::fs::create_dir_all(&dir);
    dir
}

pub fn now_unix() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

/// Open a roblox:// link (or any URL) with the default handler.
pub fn open_link(link: &str) -> Result<(), String> {
    open::that(link).map_err(|e| e.to_string())
}

#[cfg(windows)]
fn hidden(cmd: &mut Command) -> &mut Command {
    use std::os::windows::process::CommandExt;
    cmd.creation_flags(0x0800_0000) // CREATE_NO_WINDOW
}

#[cfg(not(windows))]
fn hidden(cmd: &mut Command) -> &mut Command {
    cmd
}

/// True while the Roblox player process exists.
pub fn roblox_running() -> bool {
    let mut cmd = Command::new("tasklist");
    hidden(&mut cmd).args(["/FI", "IMAGENAME eq RobloxPlayerBeta.exe", "/NH"]);
    match cmd.output() {
        Ok(out) => String::from_utf8_lossy(&out.stdout).contains("RobloxPlayerBeta.exe"),
        Err(_) => false,
    }
}

/// "Standby" prewarm: read the Roblox client binaries into the OS disk cache so
/// a cold launch doesn't wait on disk. Reads RobloxPlayerBeta.exe/.dll in each
/// player version folder, discarding the bytes. Returns total bytes read. This
/// only warms the OS cache — it starts no process and changes no files.
pub fn prewarm_roblox(version_dirs: &[PathBuf]) -> u64 {
    use std::io::Read;
    let mut total = 0u64;
    for dir in version_dirs {
        for name in ["RobloxPlayerBeta.exe", "RobloxPlayerBeta.dll"] {
            let path = dir.join(name);
            if let Ok(mut f) = std::fs::File::open(&path) {
                let mut buf = [0u8; 1 << 20]; // 1 MiB at a time
                loop {
                    match f.read(&mut buf) {
                        Ok(0) | Err(_) => break,
                        Ok(n) => total += n as u64,
                    }
                }
            }
        }
    }
    total
}

/// Ask Roblox to close normally (no /F, so it can save its settings).
pub fn close_roblox() {
    let mut cmd = Command::new("taskkill");
    hidden(&mut cmd).args(["/IM", "RobloxPlayerBeta.exe"]);
    let _ = cmd.output();
}

/// Wait up to `secs` seconds for Roblox to exit. True if it is gone.
pub fn wait_roblox_closed(secs: u64) -> bool {
    for _ in 0..(secs * 4) {
        if !roblox_running() {
            return true;
        }
        std::thread::sleep(std::time::Duration::from_millis(250));
    }
    !roblox_running()
}

/// Appends one timestamped line to `%APPDATA%\Ozara\overlay.log`, so if the
/// overlay misbehaves there's a record of what Ozara actually saw. Capped so it
/// can never grow without limit.
pub fn debug_log(line: &str) {
    use std::io::Write;
    let path = data_dir().join("overlay.log");
    if std::fs::metadata(&path)
        .map(|m| m.len() > 200_000)
        .unwrap_or(false)
    {
        let _ = std::fs::remove_file(&path);
    }
    if let Ok(mut f) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
    {
        let _ = writeln!(f, "{} {}", now_unix(), line);
    }
}

/// The focused window's program path and title, e.g.
/// ("c:\...\robloxplayerbeta.exe", "Roblox"). Same information Task Manager
/// shows for any window: no reading of the program's memory, no hook.
#[cfg(windows)]
pub fn foreground_window() -> (String, String) {
    use windows_sys::Win32::Foundation::CloseHandle;
    use windows_sys::Win32::System::Threading::{
        OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_WIN32,
        PROCESS_QUERY_LIMITED_INFORMATION,
    };
    use windows_sys::Win32::UI::WindowsAndMessaging::{
        GetForegroundWindow, GetWindowTextW, GetWindowThreadProcessId,
    };
    unsafe {
        let hwnd = GetForegroundWindow();
        if hwnd.is_null() {
            return (String::new(), String::new());
        }
        let mut title_buf = [0u16; 256];
        let n = GetWindowTextW(hwnd, title_buf.as_mut_ptr(), title_buf.len() as i32);
        let title = String::from_utf16_lossy(&title_buf[..n.max(0) as usize]);

        let mut pid: u32 = 0;
        GetWindowThreadProcessId(hwnd, &mut pid);
        let mut exe = String::new();
        if pid != 0 {
            let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
            if !handle.is_null() {
                let mut buf = [0u16; 260];
                let mut len = buf.len() as u32;
                if QueryFullProcessImageNameW(
                    handle,
                    PROCESS_NAME_WIN32,
                    buf.as_mut_ptr(),
                    &mut len,
                ) != 0
                {
                    exe = String::from_utf16_lossy(&buf[..len as usize]);
                }
                CloseHandle(handle);
            }
        }
        (exe.to_lowercase(), title)
    }
}

#[cfg(not(windows))]
pub fn foreground_window() -> (String, String) {
    (String::new(), String::new())
}

/// True while the focused window is Roblox: either the website player
/// (RobloxPlayerBeta.exe) or the Microsoft Store app, whose program lives in a
/// "ROBLOXCORPORATION..." folder, or any window titled exactly "Roblox".
pub fn roblox_focused() -> bool {
    let (exe, title) = foreground_window();
    let by_exe = exe.contains("roblox") && !exe.contains("ozara") && !exe.contains("studio");
    let by_title = title.trim() == "Roblox";
    by_exe || by_title
}

/// Installs a freshly downloaded `ozara.exe` over the running one and relaunches.
///
/// Windows won't let a running program overwrite its own file, so this writes the
/// new build next to it, then hands a tiny batch script the job of waiting for
/// Ozara to exit, swapping the files, and starting the new version. The caller
/// should exit Ozara right after this returns Ok. Only touches Ozara's own files.
#[cfg(windows)]
pub fn apply_update(new_exe: &[u8]) -> Result<(), String> {
    use std::os::windows::process::CommandExt;
    let current = std::env::current_exe().map_err(|e| format!("Can't find my own path: {e}"))?;
    let dir = current.parent().ok_or("Install folder has no parent.")?;
    let staged = dir.join("ozara-update.exe");
    std::fs::write(&staged, new_exe).map_err(|e| format!("Could not save the update: {e}"))?;

    let bat = std::env::temp_dir().join("ozara-update.bat");
    // Wait for this process to release the exe, replace it, relaunch, clean up.
    let script = format!(
        "@echo off\r\n\
         ping 127.0.0.1 -n 3 >nul\r\n\
         :retry\r\n\
         move /y \"{staged}\" \"{current}\" >nul 2>&1\r\n\
         if errorlevel 1 ( ping 127.0.0.1 -n 2 >nul & goto retry )\r\n\
         start \"\" \"{current}\"\r\n\
         del \"%~f0\"\r\n",
        staged = staged.display(),
        current = current.display(),
    );
    std::fs::write(&bat, script).map_err(|e| format!("Could not write the updater script: {e}"))?;

    Command::new("cmd")
        .creation_flags(0x0800_0000) // CREATE_NO_WINDOW
        .args(["/C", &bat.to_string_lossy()])
        .spawn()
        .map_err(|e| format!("Could not start the updater: {e}"))?;
    Ok(())
}

#[cfg(not(windows))]
pub fn apply_update(_new_exe: &[u8]) -> Result<(), String> {
    Err("Updating is only supported on Windows.".into())
}

/// Forces the window with this exact title to be borderless — no title bar, no
/// min/max/close buttons, no resize frame. We do this through Windows directly
/// because the UI framework's own "no decorations" flag doesn't take on every
/// system (which is why the overlay still showed an X / _ / □ bar). Safe: it only
/// changes window styles, and only of a window Ozara itself created.
#[cfg(windows)]
pub fn make_borderless(title: &str) {
    use windows_sys::Win32::UI::WindowsAndMessaging::{
        FindWindowW, GetWindowLongPtrW, SetWindowLongPtrW, SetWindowPos, GWL_STYLE, SWP_FRAMECHANGED,
        SWP_NOMOVE, SWP_NOSIZE, SWP_NOZORDER, WS_CAPTION, WS_MAXIMIZEBOX, WS_MINIMIZEBOX, WS_SYSMENU,
        WS_THICKFRAME,
    };
    let wide: Vec<u16> = title.encode_utf16().chain(std::iter::once(0)).collect();
    unsafe {
        let hwnd = FindWindowW(std::ptr::null(), wide.as_ptr());
        if hwnd.is_null() {
            return;
        }
        let strip =
            (WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU) as isize;
        let style = GetWindowLongPtrW(hwnd, GWL_STYLE);
        if style & strip != 0 {
            SetWindowLongPtrW(hwnd, GWL_STYLE, style & !strip);
            SetWindowPos(
                hwnd,
                std::ptr::null_mut(),
                0,
                0,
                0,
                0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
            );
        }
    }
}

#[cfg(not(windows))]
pub fn make_borderless(_title: &str) {}

/// Clips the window with this title to a circle (an ellipse filling its client
/// area). The corners outside the circle are removed by Windows itself, so they
/// show whatever's behind — which gives a real round, background-free overlay even
/// when GPU transparency isn't available. Only reshapes a window Ozara created.
#[cfg(windows)]
/// Returns true once it has clipped the window (so the caller can stop calling it
/// — re-clipping every frame flashes the square corners before each clip, which
/// is what caused the overlay to flicker). Once set, Windows keeps the region and
/// clips every later repaint for free.
pub fn make_circular(title: &str) -> bool {
    use std::ffi::c_void;
    use windows_sys::Win32::Foundation::RECT;
    use windows_sys::Win32::Graphics::Gdi::CreateEllipticRgn;
    use windows_sys::Win32::UI::WindowsAndMessaging::{FindWindowW, GetClientRect};

    // Declared directly against user32 to avoid depending on exactly which module
    // this crate version exposes SetWindowRgn under. HWND/HRGN are both void pointers.
    #[link(name = "user32")]
    extern "system" {
        fn SetWindowRgn(hwnd: *mut c_void, hrgn: *mut c_void, bredraw: i32) -> i32;
    }

    let wide: Vec<u16> = title.encode_utf16().chain(std::iter::once(0)).collect();
    unsafe {
        let hwnd = FindWindowW(std::ptr::null(), wide.as_ptr());
        if hwnd.is_null() {
            return false;
        }
        let mut rc = RECT { left: 0, top: 0, right: 0, bottom: 0 };
        if GetClientRect(hwnd, &mut rc) == 0 || rc.right <= 0 || rc.bottom <= 0 {
            return false;
        }
        // CreateEllipticRgn is exclusive of the right/bottom edge, so +1 fills it.
        let rgn = CreateEllipticRgn(0, 0, rc.right + 1, rc.bottom + 1);
        SetWindowRgn(hwnd, rgn as *mut c_void, 1);
        true
    }
}

#[cfg(not(windows))]
pub fn make_circular(_title: &str) -> bool {
    true
}

/// Shows or hides the window (by title) in the taskbar at runtime, without hiding
/// the window itself — so Ozara can vanish from the taskbar while you play Roblox
/// (living only in the tray) and reappear when Roblox closes. A tool-window style
/// is what keeps a window out of the taskbar; applying it needs a quick
/// hide/show, done here synchronously so the overlay loop never actually stops.
#[cfg(windows)]
pub fn set_taskbar_visible(title: &str, visible: bool) {
    use windows_sys::Win32::UI::WindowsAndMessaging::{
        FindWindowW, GetWindowLongPtrW, SetWindowLongPtrW, ShowWindow, GWL_EXSTYLE, SW_HIDE,
        SW_SHOWNOACTIVATE, WS_EX_APPWINDOW, WS_EX_TOOLWINDOW,
    };
    let wide: Vec<u16> = title.encode_utf16().chain(std::iter::once(0)).collect();
    unsafe {
        let hwnd = FindWindowW(std::ptr::null(), wide.as_ptr());
        if hwnd.is_null() {
            return;
        }
        let ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
        let tool = WS_EX_TOOLWINDOW as isize;
        let app = WS_EX_APPWINDOW as isize;
        let new = if visible {
            (ex & !tool) | app // normal taskbar button
        } else {
            (ex | tool) & !app // tool window: no taskbar button
        };
        if new == ex {
            return;
        }
        // The taskbar only re-reads the style across a hide/show. SHOWNOACTIVATE
        // re-shows without stealing focus from the game.
        ShowWindow(hwnd, SW_HIDE);
        SetWindowLongPtrW(hwnd, GWL_EXSTYLE, new);
        ShowWindow(hwnd, SW_SHOWNOACTIVATE);
    }
}

#[cfg(not(windows))]
pub fn set_taskbar_visible(_title: &str, _visible: bool) {}
