//! Ozara's look: gradient backdrop, dark rounded panels, pill buttons.

use eframe::egui::{
    self, Color32, FontFamily, FontId, Frame, Margin, Response, RichText, Rounding, Ui, Vec2,
};

pub fn violet() -> Color32 {
    Color32::from_rgb(0xA7, 0x8B, 0xFA)
}
pub fn cyan() -> Color32 {
    Color32::from_rgb(0x67, 0xE8, 0xF9)
}
pub fn muted() -> Color32 {
    Color32::from_rgb(0xB9, 0xBA, 0xC8)
}
pub fn ink() -> Color32 {
    Color32::from_rgb(0x10, 0x10, 0x18)
}
pub fn good() -> Color32 {
    Color32::from_rgb(0x86, 0xEF, 0xAC)
}
pub fn warn() -> Color32 {
    Color32::from_rgb(0xFD, 0xE6, 0x8A)
}
pub fn bad() -> Color32 {
    Color32::from_rgb(0xFC, 0xA5, 0xA5)
}

/// The purple-to-pink gradient behind everything.
pub fn paint_backdrop(ctx: &egui::Context) {
    let rect = ctx.screen_rect();
    let painter = ctx.layer_painter(egui::LayerId::background());
    let top = Color32::from_rgb(0x6A, 0x11, 0xFF);
    let bottom = Color32::from_rgb(0xFF, 0x7B, 0xF0);
    let mut mesh = egui::Mesh::default();
    mesh.colored_vertex(rect.left_top(), top);
    mesh.colored_vertex(rect.right_top(), top);
    mesh.colored_vertex(rect.right_bottom(), bottom);
    mesh.colored_vertex(rect.left_bottom(), bottom);
    mesh.add_triangle(0, 1, 2);
    mesh.add_triangle(0, 2, 3);
    painter.add(egui::Shape::mesh(mesh));
}

/// Poppins (free, open-licensed font) for all text; Poppins Bold for headings.
pub fn install_fonts(ctx: &egui::Context) {
    let mut fonts = egui::FontDefinitions::default();
    fonts.font_data.insert(
        "poppins".to_owned(),
        egui::FontData::from_static(include_bytes!("../assets/fonts/Poppins-Regular.ttf")),
    );
    fonts.font_data.insert(
        "poppins-medium".to_owned(),
        egui::FontData::from_static(include_bytes!("../assets/fonts/Poppins-Medium.ttf")),
    );
    fonts.font_data.insert(
        "poppins-bold".to_owned(),
        egui::FontData::from_static(include_bytes!("../assets/fonts/Poppins-Bold.ttf")),
    );
    if let Some(list) = fonts.families.get_mut(&FontFamily::Proportional) {
        list.insert(0, "poppins".to_owned());
    }
    fonts.families.insert(
        FontFamily::Name("bold".into()),
        vec!["poppins-bold".to_owned()],
    );
    fonts.families.insert(
        FontFamily::Name("medium".into()),
        vec!["poppins-medium".to_owned()],
    );
    ctx.set_fonts(fonts);
}

pub fn bold(text: impl Into<String>, size: f32) -> RichText {
    RichText::new(text).font(FontId::new(size, FontFamily::Name("bold".into())))
}

#[allow(dead_code)] // kept for future use; not every weight is used everywhere yet
pub fn medium(text: impl Into<String>, size: f32) -> RichText {
    RichText::new(text).font(FontId::new(size, FontFamily::Name("medium".into())))
}

/// Colour from hue (0-360), saturation and lightness (0-1).
pub fn hsl(h: f32, s: f32, l: f32) -> Color32 {
    let c = (1.0 - (2.0 * l - 1.0).abs()) * s;
    let hp = h.rem_euclid(360.0) / 60.0;
    let x = c * (1.0 - (hp % 2.0 - 1.0).abs());
    let (r, g, b) = match hp as u32 {
        0 => (c, x, 0.0),
        1 => (x, c, 0.0),
        2 => (0.0, c, x),
        3 => (0.0, x, c),
        4 => (x, 0.0, c),
        _ => (c, 0.0, x),
    };
    let m = l - c / 2.0;
    Color32::from_rgb(
        ((r + m) * 255.0) as u8,
        ((g + m) * 255.0) as u8,
        ((b + m) * 255.0) as u8,
    )
}

/// A round avatar. Draws a real photo (cropped to a circle) when one is given,
/// otherwise a colour (from a number, e.g. a user ID) with an initial on it.
pub fn avatar_photo(
    ui: &mut Ui,
    size: f32,
    photo: Option<&egui::TextureHandle>,
    initial: &str,
    seed: u64,
) -> Response {
    let (rect, resp) = ui.allocate_exact_size(Vec2::splat(size), egui::Sense::click());
    if let Some(tex) = photo {
        let sized = egui::load::SizedTexture::new(tex.id(), rect.size());
        egui::Image::from_texture(sized)
            .rounding(Rounding::same(size / 2.0))
            .paint_at(ui, rect);
    } else {
        let hue = 250.0 + (seed % 110) as f32;
        ui.painter()
            .circle_filled(rect.center(), size / 2.0, hsl(hue, 0.72, 0.52));
        ui.painter().text(
            rect.center(),
            egui::Align2::CENTER_CENTER,
            initial,
            FontId::new(size * 0.38, FontFamily::Name("bold".into())),
            Color32::WHITE,
        );
    }
    resp
}

pub fn apply_style(ctx: &egui::Context) {
    let mut v = egui::Visuals::dark();
    v.override_text_color = Some(Color32::WHITE);
    v.widgets.inactive.rounding = Rounding::same(20.0);
    v.widgets.hovered.rounding = Rounding::same(20.0);
    v.widgets.active.rounding = Rounding::same(20.0);
    v.selection.bg_fill = violet();
    ctx.set_visuals(v);
    ctx.style_mut(|s| {
        s.spacing.item_spacing = Vec2::new(10.0, 10.0);
        s.spacing.button_padding = Vec2::new(18.0, 8.0);
    });
}

/// A dark rounded card, like the panels in the design.
pub fn panel<R>(ui: &mut Ui, add: impl FnOnce(&mut Ui) -> R) -> R {
    Frame::none()
        .fill(Color32::from_rgba_unmultiplied(16, 12, 28, 220))
        .rounding(Rounding::same(24.0))
        .inner_margin(Margin::symmetric(24.0, 20.0))
        .show(ui, |ui| {
            ui.set_width(ui.available_width());
            add(ui)
        })
        .inner
}

pub fn heading(ui: &mut Ui, text: &str) {
    ui.label(bold(text, 17.0));
}

pub fn muted_label(ui: &mut Ui, text: &str) {
    ui.label(RichText::new(text).size(12.5).color(muted()));
}

/// Main action button (violet pill).
pub fn primary_button(ui: &mut Ui, text: &str) -> Response {
    ui.add(
        egui::Button::new(bold(text, 13.0).color(ink()))
            .fill(violet())
            .rounding(Rounding::same(20.0))
            .min_size(Vec2::new(0.0, 38.0)),
    )
}

/// Secondary button (translucent pill).
pub fn ghost_button(ui: &mut Ui, text: &str) -> Response {
    ui.add(
        egui::Button::new(bold(text, 13.0))
            .fill(Color32::from_rgba_unmultiplied(255, 255, 255, 36))
            .rounding(Rounding::same(20.0))
            .min_size(Vec2::new(0.0, 38.0)),
    )
}

/// A filter/sort chip. Returns true when clicked.
pub fn chip(ui: &mut Ui, text: &str, on: bool) -> bool {
    let b = if on {
        egui::Button::new(bold(text, 12.5).color(ink())).fill(violet())
    } else {
        egui::Button::new(bold(text, 12.5)).fill(Color32::from_rgba_unmultiplied(255, 255, 255, 30))
    };
    ui.add(
        b.rounding(Rounding::same(19.0))
            .min_size(Vec2::new(0.0, 34.0)),
    )
    .clicked()
}

/// A labelled on/off switch drawn as a pill.
pub fn switch(ui: &mut Ui, on: &mut bool) -> Response {
    let size = Vec2::new(46.0, 26.0);
    let (rect, mut response) = ui.allocate_exact_size(size, egui::Sense::click());
    if response.clicked() {
        *on = !*on;
        response.mark_changed();
    }
    let track = if *on {
        violet()
    } else {
        Color32::from_rgba_unmultiplied(255, 255, 255, 56)
    };
    ui.painter().rect_filled(rect, Rounding::same(13.0), track);
    let knob_x = if *on {
        rect.right() - 13.0
    } else {
        rect.left() + 13.0
    };
    ui.painter()
        .circle_filled(egui::pos2(knob_x, rect.center().y), 10.0, Color32::WHITE);
    response
}
