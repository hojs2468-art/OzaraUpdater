//! Pictures baked into the program.

use eframe::egui::{self, ImageSource};

pub fn icon(name: &str) -> ImageSource<'static> {
    match name {
        "home" => egui::include_image!("../assets/icons/home.png"),
        "friends" => egui::include_image!("../assets/icons/friends.png"),
        "servers" => egui::include_image!("../assets/icons/servers.png"),
        "star" => egui::include_image!("../assets/icons/star.png"),
        "gear" => egui::include_image!("../assets/icons/gear.png"),
        "chart" => egui::include_image!("../assets/icons/chart.png"),
        "note" => egui::include_image!("../assets/icons/note.png"),
        "bell" => egui::include_image!("../assets/icons/bell.png"),
        "refresh" => egui::include_image!("../assets/icons/refresh.png"),
        "search" => egui::include_image!("../assets/icons/search.png"),
        "sliders" => egui::include_image!("../assets/icons/sliders.png"),
        "plus" => egui::include_image!("../assets/icons/plus.png"),
        _ => egui::include_image!("../assets/icons/chev.png"),
    }
}

pub fn wordmark() -> ImageSource<'static> {
    egui::include_image!("../assets/wordmark.png")
}

pub fn mark() -> ImageSource<'static> {
    egui::include_image!("../assets/mark.png")
}
