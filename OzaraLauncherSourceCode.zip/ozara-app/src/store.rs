//! Simple on-disk lists Ozara keeps for the user: favourite games and notes.
//! Both live as small text files in Ozara's data folder. No network, no accounts.

use crate::sys::data_dir;
use std::path::PathBuf;

fn favourites_file() -> PathBuf {
    data_dir().join("favourites.tsv")
}

fn notes_file() -> PathBuf {
    data_dir().join("notes.tsv")
}

/// A favourited game: its place id and a remembered name.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Favourite {
    pub place_id: String,
    pub name: String,
}

pub fn load_favourites() -> Vec<Favourite> {
    let text = std::fs::read_to_string(favourites_file()).unwrap_or_default();
    text.lines()
        .filter_map(|line| {
            let mut p = line.splitn(2, '\t');
            let place_id = p.next()?.trim().to_string();
            let name = p.next().unwrap_or("").trim().to_string();
            if place_id.is_empty() {
                None
            } else {
                Some(Favourite { place_id, name })
            }
        })
        .collect()
}

fn save_favourites(list: &[Favourite]) {
    let text: String = list.iter().map(|f| format!("{}\t{}\n", f.place_id, f.name)).collect();
    let _ = std::fs::write(favourites_file(), text);
}

/// True if the place is now a favourite after toggling.
pub fn toggle_favourite(list: &mut Vec<Favourite>, place_id: &str, name: &str) -> bool {
    if let Some(i) = list.iter().position(|f| f.place_id == place_id) {
        list.remove(i);
        save_favourites(list);
        false
    } else {
        list.push(Favourite { place_id: place_id.to_string(), name: name.to_string() });
        save_favourites(list);
        true
    }
}

pub fn is_favourite(list: &[Favourite], place_id: &str) -> bool {
    list.iter().any(|f| f.place_id == place_id)
}

/// A free-text note the user saved.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Note {
    pub text: String,
}

pub fn load_notes() -> Vec<Note> {
    let text = std::fs::read_to_string(notes_file()).unwrap_or_default();
    text.lines()
        .filter_map(|line| {
            // Tabs and newlines are the record separators, so restore any we escaped.
            let t = line.replace("\\n", "\n").replace("\\t", "\t");
            let t = t.trim();
            if t.is_empty() {
                None
            } else {
                Some(Note { text: t.to_string() })
            }
        })
        .collect()
}

fn save_notes(list: &[Note]) {
    let text: String = list
        .iter()
        .map(|n| format!("{}\n", n.text.replace('\\', "\\\\").replace('\t', "\\t").replace('\n', "\\n")))
        .collect();
    let _ = std::fs::write(notes_file(), text);
}

pub fn add_note(list: &mut Vec<Note>, text: &str) {
    let text = text.trim();
    if !text.is_empty() {
        list.insert(0, Note { text: text.to_string() });
        save_notes(list);
    }
}

pub fn remove_note(list: &mut Vec<Note>, index: usize) {
    if index < list.len() {
        list.remove(index);
        save_notes(list);
    }
}

fn prefs_file() -> PathBuf {
    data_dir().join("prefs.tsv")
}

/// The user's applied graphics selections and FPS cap, so Ozara's Settings screen
/// shows what they last chose (the flags themselves live in Roblox's own file).
pub struct Prefs {
    pub enabled_ids: Vec<String>,
    pub fps_cap: Option<i32>,
}

pub fn load_prefs() -> Prefs {
    let text = std::fs::read_to_string(prefs_file()).unwrap_or_default();
    let mut enabled_ids = Vec::new();
    let mut fps_cap = None;
    for line in text.lines() {
        let mut p = line.splitn(2, '\t');
        match (p.next(), p.next()) {
            (Some("flag"), Some(id)) => enabled_ids.push(id.trim().to_string()),
            (Some("fps"), Some(v)) => fps_cap = v.trim().parse().ok(),
            _ => {}
        }
    }
    Prefs { enabled_ids, fps_cap }
}

pub fn save_prefs(enabled_ids: &[&str], fps_cap: i32) {
    let mut text = format!("fps\t{fps_cap}\n");
    for id in enabled_ids {
        text.push_str(&format!("flag\t{id}\n"));
    }
    let _ = std::fs::write(prefs_file(), text);
}

fn theme_lock_file() -> PathBuf {
    data_dir().join("theme_lock.tsv")
}

/// Whether Ozara guards the applied theme: restores it if changed and sets the
/// files read-only. A deterrent, not unbreakable protection.
pub fn load_theme_lock() -> bool {
    std::fs::read_to_string(theme_lock_file())
        .ok()
        .map(|t| t.contains("lock\t1"))
        .unwrap_or(false)
}

pub fn save_theme_lock(on: bool) {
    let _ = std::fs::write(theme_lock_file(), format!("lock\t{}\n", u8::from(on)));
}

fn standby_file() -> PathBuf {
    data_dir().join("standby.tsv")
}

/// Whether to keep Roblox's client files warm for faster launches. `None` means
/// the user hasn't been asked yet (so Ozara shows the one-time prompt).
pub fn load_standby() -> Option<bool> {
    let text = std::fs::read_to_string(standby_file()).ok()?;
    for line in text.lines() {
        if let Some(v) = line.strip_prefix("standby\t") {
            return Some(v.trim() == "1");
        }
    }
    None
}

pub fn save_standby(on: bool) {
    let _ = std::fs::write(standby_file(), format!("standby\t{}\n", u8::from(on)));
}

fn tex_file() -> PathBuf {
    data_dir().join("tex.tsv")
}

/// Texture-cache downscaler settings: the resolution cap (0 = original/off) and
/// whether to auto-apply while Roblox runs. Kept separate so saving graphics
/// prefs doesn't disturb it.
pub fn load_tex() -> (u32, bool) {
    let text = std::fs::read_to_string(tex_file()).unwrap_or_default();
    let mut cap = 0u32;
    let mut auto = false;
    for line in text.lines() {
        let mut p = line.splitn(2, '\t');
        match (p.next(), p.next()) {
            (Some("cap"), Some(v)) => cap = v.trim().parse().unwrap_or(0),
            (Some("auto"), Some(v)) => auto = v.trim() == "1",
            _ => {}
        }
    }
    (cap, auto)
}

pub fn save_tex(cap: u32, auto: bool) {
    let _ = std::fs::write(tex_file(), format!("cap\t{cap}\nauto\t{}\n", u8::from(auto)));
}

fn custom_flags_file() -> PathBuf {
    data_dir().join("custom_flags.txt")
}

pub fn load_custom_flags() -> String {
    std::fs::read_to_string(custom_flags_file()).unwrap_or_default()
}

pub fn save_custom_flags(text: &str) {
    let _ = std::fs::write(custom_flags_file(), text);
}
