#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod assets;
mod auth;
mod config;
mod hotkey;
mod images;
mod mods;
mod net;
mod store;
mod sys;
mod texcache;
mod theme;
mod tracker;
mod tray;

use eframe::egui::{self, Color32, FontFamily, FontId, RichText};
use ozara_core::flags::{self, Allowlist, Setting, Source};
use ozara_core::servers::{self, Server, Sort};
use ozara_core::{fps, join, paths, playtime};
use std::collections::{BTreeMap, HashMap};
use std::path::PathBuf;
use std::sync::mpsc::{channel, Receiver, Sender};
use std::time::{Duration, Instant};
use theme::*;

const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Where the main window is parked when "in the tray": far off every monitor, so
/// it's invisible but still drawing (a truly hidden window stops the overlay loop).
const OFFSCREEN: egui::Pos2 = egui::pos2(-32000.0, -32000.0);

/// The graphics-setting ids that are lighting-related, so a lighting preset can
/// reset just those without disturbing the performance toggles.
const LIGHTING_IDS: [&str; 5] = ["no_lights", "gray_sky", "no_shadows", "voxel_lighting", "no_postfx"];

/// The corner badge's screen rectangle and visibility, shared with the key/mouse
/// watcher thread. The badge window never takes focus (so it can't interrupt the
/// game), and Windows won't reliably deliver clicks to such a window — so the
/// watcher detects a click landing inside this rectangle by cursor position
/// instead, and opens the wheel. x/y/w/h are screen pixels.
pub(crate) mod badge {
    use std::sync::atomic::{AtomicBool, AtomicI32, Ordering};
    pub static SHOWN: AtomicBool = AtomicBool::new(false);
    pub static X: AtomicI32 = AtomicI32::new(0);
    pub static Y: AtomicI32 = AtomicI32::new(0);
    pub static W: AtomicI32 = AtomicI32::new(0);
    pub static H: AtomicI32 = AtomicI32::new(0);

    pub fn set_rect(x: i32, y: i32, w: i32, h: i32) {
        X.store(x, Ordering::Relaxed);
        Y.store(y, Ordering::Relaxed);
        W.store(w, Ordering::Relaxed);
        H.store(h, Ordering::Relaxed);
    }
    pub fn set_shown(v: bool) {
        SHOWN.store(v, Ordering::Relaxed);
    }
    /// True if the badge is visible and (px, py) is inside its rectangle.
    pub fn hit(px: i32, py: i32) -> bool {
        if !SHOWN.load(Ordering::Relaxed) {
            return false;
        }
        let (x, y, w, h) = (
            X.load(Ordering::Relaxed),
            Y.load(Ordering::Relaxed),
            W.load(Ordering::Relaxed),
            H.load(Ordering::Relaxed),
        );
        w > 0 && h > 0 && px >= x && px < x + w && py >= y && py < y + h
    }
}

/// The Ozara logo as the window/taskbar icon (otherwise Windows shows a generic "e").
fn window_icon() -> Option<egui::IconData> {
    let img = image::load_from_memory(include_bytes!("../assets/window-icon.png"))
        .ok()?
        .into_rgba8();
    let (width, height) = (img.width(), img.height());
    Some(egui::IconData {
        rgba: img.into_raw(),
        width,
        height,
    })
}

fn main() -> eframe::Result<()> {
    let mut viewport = egui::ViewportBuilder::default()
        .with_title("Ozara")
        .with_inner_size([1280.0, 860.0])
        .with_min_inner_size([980.0, 640.0])
        // Needed so the overlay child window gets a surface that supports per-pixel
        // transparency; the main window covers itself with an opaque backdrop.
        .with_transparent(true);
    if let Some(icon) = window_icon() {
        viewport = viewport.with_icon(icon);
    }
    let options = eframe::NativeOptions {
        viewport,
        ..Default::default()
    };
    eframe::run_native(
        "Ozara",
        options,
        Box::new(|cc| {
            egui_extras::install_image_loaders(&cc.egui_ctx);
            theme::install_fonts(&cc.egui_ctx);
            theme::apply_style(&cc.egui_ctx);
            Ok(Box::new(OzaraApp::new()))
        }),
    )
}

/// Which kind of search results to show.
#[derive(Clone, Copy, PartialEq, Eq)]
enum SearchFilter {
    All,
    People,
    Games,
}

impl SearchFilter {
    const ALL: [SearchFilter; 3] = [SearchFilter::All, SearchFilter::People, SearchFilter::Games];
    fn label(self) -> &'static str {
        match self {
            SearchFilter::All => "All",
            SearchFilter::People => "People",
            SearchFilter::Games => "Games",
        }
    }
    fn show_people(self) -> bool {
        matches!(self, SearchFilter::All | SearchFilter::People)
    }
    fn show_games(self) -> bool {
        matches!(self, SearchFilter::All | SearchFilter::Games)
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Page {
    Home,
    Friends,
    Servers,
    Favorites,
    Settings,
    Stats,
    Notes,
    Alerts,
    Updates,
    /// Reached only by searching; not in the sidebar.
    Search,
    /// One game's page; reached by clicking a game card.
    Game,
}

impl Page {
    const ALL: [Page; 9] = [
        Page::Home,
        Page::Friends,
        Page::Servers,
        Page::Favorites,
        Page::Settings,
        Page::Stats,
        Page::Notes,
        Page::Alerts,
        Page::Updates,
    ];
    fn label(self) -> &'static str {
        match self {
            Page::Home => "Home",
            Page::Friends => "Friends",
            Page::Servers => "Servers",
            Page::Favorites => "Favorites",
            Page::Settings => "Settings",
            Page::Stats => "Stats",
            Page::Notes => "Notes",
            Page::Alerts => "Alerts",
            Page::Updates => "Updates",
            Page::Search => "Search",
            Page::Game => "Game",
        }
    }
    fn icon(self) -> &'static str {
        match self {
            Page::Home => "home",
            Page::Friends => "friends",
            Page::Servers => "servers",
            Page::Favorites => "star",
            Page::Settings => "gear",
            Page::Stats => "chart",
            Page::Notes => "note",
            Page::Alerts => "bell",
            Page::Updates => "refresh",
            Page::Search => "search",
            Page::Game => "servers",
        }
    }
}

pub(crate) enum Msg {
    Servers(Result<Vec<Server>, String>),
    Status(String),
    SignedIn(Result<auth::Profile, String>),
    /// Found the account to verify (awaiting the blurb code).
    VerifyFound(Result<auth::Profile, String>),
    /// Whether the verification code was found in the profile blurb.
    VerifyChecked(Result<bool, String>),
    Friends(Result<net::FriendsInfo, String>),
    Names(HashMap<String, String>),
    SearchUsers(Result<Vec<net::UserHit>, String>),
    SearchGames(Result<Vec<net::GameHit>, String>),
    Backfill(Vec<playtime::Session>),
    /// (place id the answer is for, details or an error)
    GameDetails(String, Result<net::GameDetails, String>),
    ToggleOverlay,
    /// Open the overlay without the "is Roblox focused?" check (tray / Test button).
    ShowOverlay,
    /// GitHub's latest version tag, or an error.
    UpdateChecked(Result<String, String>),
    /// The downloaded new build's bytes, ready to install, or an error.
    UpdateDownloaded(Result<Vec<u8>, String>),
    /// A texture-cache downscale pass finished: a status line to show.
    TexDone(String),
}

struct OzaraApp {
    page: Page,
    roblox: Option<PathBuf>,
    tracker: tracker::Tracker,
    last_tick: Instant,
    rx: Receiver<Msg>,
    tx: Sender<Msg>,
    status: String,
    search: String,
    link_input: String,
    demo: bool,
    /// So the one-time log backfill only ever gets kicked off once per run.
    backfill_started: bool,

    // Account
    profile: Option<auth::Profile>,
    signing_in: bool,
    // Ownership verification (paste a code into your Roblox profile blurb).
    verify_profile: Option<auth::Profile>,
    verify_code: Option<String>,
    verify_pending: bool,
    friends: Vec<net::Friend>,
    friends_count: Option<u32>,
    friends_restricted: bool,
    friends_loading: bool,
    friends_loaded: bool,
    avatars: images::ImageCache,
    game_icons: images::ImageCache,

    // Search results (people + games, by name; `search` above holds the query text)
    search_users: Vec<net::UserHit>,
    search_games: Vec<net::GameHit>,
    search_pending: u8,
    search_filter: SearchFilter,
    search_error: Option<String>,
    game_names: HashMap<String, String>,
    names_requested: Vec<String>,

    // Game page
    game_place: String,
    game_hint: Option<String>,
    game_details: Option<net::GameDetails>,
    game_error: Option<String>,
    game_loading: bool,

    // Updates
    update_busy: bool,
    update_latest: Option<String>,
    update_status: String,

    // Favourites & notes
    favourites: Vec<store::Favourite>,
    notes: Vec<store::Note>,
    note_input: String,
    custom_flags: String,

    // Anti-spam, quick settings, tray
    cooldowns: HashMap<&'static str, Instant>,
    quick_open: bool,
    quick_anchor: egui::Pos2,
    quick_btn_rect: egui::Rect,
    tray: Option<tray::Tray>,
    tray_tried: bool,
    hotkey_tried: bool,
    overlay_open: bool,
    overlay_enabled: bool,
    /// Reset each time the overlay opens, so it's re-centred once per opening
    /// without fighting anything on every frame.
    overlay_centered: bool,
    /// Cached every few seconds (checking costs a process spawn), so the floating
    /// corner button can show only while Roblox is actually open.
    roblox_running: bool,
    /// So the corner button is placed in its corner once per appearance.
    corner_placed: bool,
    /// Last badge show/hide decision, to log only when it changes.
    corner_last_show: bool,
    /// Last time Roblox was the focused window — used to keep the badge steady
    /// through the brief focus flicker when the wheel opens or closes.
    roblox_focus_seen: Option<Instant>,
    /// When the wheel is showing its radial FPS picker instead of the main page.
    fps_page: bool,
    /// When the wheel is showing its graphics/FastFlag toggles page.
    flags_page: bool,
    /// Whether the wheel / badge windows have had their circular clip applied yet
    /// (apply once, not every frame — re-clipping flickers).
    overlay_shaped: bool,
    badge_shaped: bool,

    // Settings page
    allow: Allowlist,
    catalog: Vec<Setting>,
    enabled: BTreeMap<&'static str, bool>,
    fps_cap: i32,
    /// Texture-cache downscaler: resolution cap (0 = original/off), whether to
    /// auto-apply while Roblox runs, and the plumbing to run passes off-thread.
    tex_cap: u32,
    tex_auto: bool,
    tex_running: bool,
    last_tex_auto: Instant,
    /// Keep Roblox's client files warm for faster launches. None = not yet asked
    /// (shows the one-time prompt); Some(true/false) = the user's choice.
    standby: Option<bool>,
    /// So the startup prewarm only runs once per launch.
    standby_warmed: bool,
    /// Guard the applied theme: restore it if changed, and lock it read-only.
    theme_lock: bool,
    last_theme_heal: Instant,

    // Servers page
    place_input: String,
    servers: Vec<Server>,
    loading: bool,
    sort: Sort,
    hide_full: bool,
    low_ping: bool,
    server_error: Option<String>,
}

impl OzaraApp {
    fn new() -> Self {
        let roblox = sys::local_app_data()
            .map(|d| paths::roblox_dir(&d))
            .filter(|d| d.is_dir());
        let (tx, rx) = channel();
        let catalog = flags::settings_catalog();
        // Start every toggle off, then switch on the ones the user last applied.
        let prefs = store::load_prefs();
        let tex_settings = store::load_tex();
        let enabled: BTreeMap<&'static str, bool> = catalog
            .iter()
            .map(|s| (s.id, prefs.enabled_ids.iter().any(|id| id == s.id)))
            .collect();
        // OZARA_DEMO=1 fills the app with sample people and games, for screenshots.
        let demo = std::env::var_os("OZARA_DEMO").is_some();
        let mut app = OzaraApp {
            page: Page::Home,
            tracker: tracker::Tracker::new(roblox.clone(), &sys::data_dir()),
            roblox,
            last_tick: Instant::now() - Duration::from_secs(60),
            rx,
            tx,
            status: String::new(),
            search: String::new(),
            link_input: String::new(),
            demo,
            backfill_started: false,
            profile: auth::load_profile(&sys::data_dir()),
            signing_in: false,
            verify_profile: None,
            verify_code: None,
            verify_pending: false,
            friends: Vec::new(),
            friends_count: None,
            friends_restricted: false,
            friends_loading: false,
            friends_loaded: false,
            avatars: images::ImageCache::new("avatar", net::fetch_avatar_urls),
            game_icons: images::ImageCache::new("game", net::fetch_game_icon_urls),
            search_users: Vec::new(),
            search_games: Vec::new(),
            search_pending: 0,
            search_filter: SearchFilter::All,
            search_error: None,
            game_names: HashMap::new(),
            names_requested: Vec::new(),
            game_place: String::new(),
            game_hint: None,
            game_details: None,
            game_error: None,
            game_loading: false,
            update_busy: false,
            update_latest: None,
            update_status: String::new(),
            favourites: store::load_favourites(),
            notes: store::load_notes(),
            note_input: String::new(),
            custom_flags: store::load_custom_flags(),
            cooldowns: HashMap::new(),
            quick_open: false,
            quick_anchor: egui::Pos2::ZERO,
            quick_btn_rect: egui::Rect::NOTHING,
            tray: None,
            tray_tried: false,
            hotkey_tried: false,
            overlay_open: false,
            overlay_enabled: load_overlay_enabled(),
            overlay_centered: false,
            roblox_running: false,
            corner_placed: false,
            corner_last_show: false,
            roblox_focus_seen: None,
            fps_page: false,
            flags_page: false,
            overlay_shaped: false,
            badge_shaped: false,
            allow: Allowlist::builtin(),
            catalog,
            enabled,
            fps_cap: prefs.fps_cap.unwrap_or(240),
            tex_cap: tex_settings.0,
            tex_auto: tex_settings.1,
            tex_running: false,
            last_tex_auto: Instant::now(),
            standby: store::load_standby(),
            standby_warmed: false,
            theme_lock: store::load_theme_lock(),
            last_theme_heal: Instant::now(),
            place_input: String::new(),
            servers: Vec::new(),
            loading: false,
            sort: Sort::FewestPlayers,
            hide_full: true,
            low_ping: false,
            server_error: None,
        };
        if demo {
            app.profile = Some(auth::Profile {
                user_id: "1".into(),
                name: "[Username]".into(),
                username: "username".into(),
                verified: Some(true),
            });
            let names = [
                "Nova",
                "pixel_fox",
                "Mika",
                "bluejay",
                "Rowan",
                "kit_kat",
                "Orion",
                "lumen",
                "Sage",
            ];
            app.friends = names
                .iter()
                .enumerate()
                .map(|(i, n)| net::Friend {
                    id: 100 + i as u64,
                    name: n.to_string(),
                    display_name: n.to_string(),
                })
                .collect();
            app.friends_loaded = true;
        }
        app
    }

    // ------------------------------------------------------------ background work

    fn poll(&mut self, ctx: &egui::Context) {
        while let Ok(msg) = self.rx.try_recv() {
            match msg {
                Msg::Servers(Ok(list)) => {
                    self.servers = list;
                    self.server_error = None;
                    self.loading = false;
                }
                Msg::Servers(Err(e)) => {
                    self.server_error = Some(e);
                    self.loading = false;
                }
                Msg::Status(s) => self.status = s,
                Msg::TexDone(s) => {
                    self.tex_running = false;
                    if !s.is_empty() {
                        self.status = s;
                    }
                }
                Msg::SignedIn(Ok(p)) => {
                    self.status = format!("Linked to {}.", p.name);
                    self.profile = Some(p);
                    self.signing_in = false;
                    self.friends_loaded = false;
                }
                Msg::SignedIn(Err(e)) => {
                    self.status = e;
                    self.signing_in = false;
                }
                Msg::VerifyFound(Ok(p)) => {
                    let code = verify_code();
                    self.status = format!(
                        "Paste this into your Roblox profile's About, save it, then click Verify: {code}"
                    );
                    self.verify_profile = Some(p);
                    self.verify_code = Some(code);
                    self.verify_pending = false;
                }
                Msg::VerifyFound(Err(e)) => {
                    self.status = e;
                    self.verify_pending = false;
                }
                Msg::VerifyChecked(Ok(true)) => {
                    self.verify_pending = false;
                    if let Some(p) = self.verify_profile.take() {
                        self.status = format!("Verified — linked {} as yours.", p.name);
                        auth::save_profile(&sys::data_dir(), &p);
                        self.profile = Some(p);
                        self.friends_loaded = false;
                    }
                    self.verify_code = None;
                }
                Msg::VerifyChecked(Ok(false)) => {
                    self.verify_pending = false;
                    self.status =
                        "Didn't find the code in your profile yet. Save your About text, wait a moment, then Verify again.".into();
                }
                Msg::VerifyChecked(Err(e)) => {
                    self.verify_pending = false;
                    self.status = e;
                }
                Msg::Friends(Ok(info)) => {
                    self.friends = info.list;
                    self.friends_count = info.count;
                    self.friends_restricted = info.list_restricted;
                    self.friends_loading = false;
                    if info.list_restricted {
                        self.status = "Roblox has restricted this account's friends list, so only a count is shown.".into();
                    }
                }
                Msg::Friends(Err(e)) => {
                    self.status = e;
                    self.friends_loading = false;
                }
                Msg::Names(map) => self.game_names.extend(map),
                Msg::SearchUsers(Ok(list)) => {
                    self.search_users = list;
                    self.search_pending = self.search_pending.saturating_sub(1);
                }
                Msg::SearchGames(Ok(list)) => {
                    self.search_games = list;
                    self.search_pending = self.search_pending.saturating_sub(1);
                }
                Msg::SearchUsers(Err(e)) | Msg::SearchGames(Err(e)) => {
                    self.search_error = Some(e);
                    self.search_pending = self.search_pending.saturating_sub(1);
                }
                Msg::GameDetails(place, result) => {
                    if place == self.game_place {
                        self.game_loading = false;
                        match result {
                            Ok(d) => {
                                self.game_details = Some(d);
                                self.game_error = None;
                            }
                            Err(e) => self.game_error = Some(e),
                        }
                    }
                }
                Msg::Backfill(extra) => {
                    if self.tracker.merge_backfill(extra) {
                        self.status = "Found your past games from Roblox's own logs.".into();
                    }
                }
                Msg::ShowOverlay => {
                    if self.overlay_enabled {
                        self.overlay_open = true;
                        self.fps_page = false;
                        self.flags_page = false;
                        self.overlay_centered = false;
                        self.overlay_shaped = false;
                        sys::debug_log("overlay opened (tray/test, no focus check)");
                    }
                }
                Msg::UpdateChecked(result) => {
                    self.update_busy = false;
                    match result {
                        Ok(latest) => {
                            let newer = ozara_core::version::is_newer(VERSION, &latest);
                            self.update_latest = Some(latest.clone());
                            self.update_status = if newer {
                                format!("Update available: {latest}. You have {VERSION}.")
                            } else {
                                format!("You're up to date ({VERSION}).")
                            };
                        }
                        Err(e) => self.update_status = e,
                    }
                }
                Msg::UpdateDownloaded(result) => {
                    self.update_busy = false;
                    match result {
                        Ok(bytes) => match sys::apply_update(&bytes) {
                            Ok(()) => {
                                self.update_status = "Installing update — Ozara will restart…".into();
                                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                            }
                            Err(e) => self.update_status = e,
                        },
                        Err(e) => self.update_status = e,
                    }
                }
                Msg::ToggleOverlay => {
                    if self.overlay_enabled {
                        if self.overlay_open {
                            // Always allowed to close, however you got here.
                            self.overlay_open = false;
                            sys::debug_log("overlay closed by hotkey");
                        } else if sys::roblox_focused() {
                            self.overlay_open = true;
                            self.fps_page = false;
                            self.flags_page = false;
                            self.overlay_centered = false;
                            self.overlay_shaped = false;
                            sys::debug_log("overlay opened");
                        } else {
                            let (exe, title) = sys::foreground_window();
                            sys::debug_log(&format!(
                                "not opened: focused window is {exe:?} titled {title:?}"
                            ));
                            self.status = format!("{} opens over Roblox — focus the game first, or use the tray / Test button.", hotkey::TRIGGER_LABEL);
                        }
                    }
                }
            }
        }
        if self.last_tick.elapsed() >= Duration::from_secs(5) {
            let prev_running = self.roblox_running;
            let prev_in_game = self.tracker.current.is_some();
            self.tracker.tick();
            self.roblox_running = sys::roblox_running();
            let now_in_game = self.tracker.current.is_some();
            // You left a game to the Roblox menu → close Roblox and bring Ozara back,
            // so leaving a game returns you to Ozara (as requested).
            if self.tray.is_some() && prev_in_game && !now_in_game && self.roblox_running {
                sys::close_roblox();
                self.roblox_running = false;
            }
            // Roblox just opened → tuck Ozara into the tray so it's out of the way.
            // Roblox just closed (or we just closed it) → bring Ozara back.
            if self.tray.is_some() {
                if !prev_running && self.roblox_running {
                    // Tuck Ozara off-screen rather than hiding it: a fully hidden
                    // window stops drawing, which would also freeze the overlay and
                    // badge (they're drawn by this same loop). Off-screen keeps the
                    // loop alive while getting Ozara out of your way — and remove it
                    // from the taskbar so it lives only in the tray while you play.
                    ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(OFFSCREEN));
                    sys::set_taskbar_visible("Ozara", false);
                } else if prev_running && !self.roblox_running {
                    sys::set_taskbar_visible("Ozara", true);
                    ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(egui::pos2(100.0, 80.0)));
                    ctx.send_viewport_cmd(egui::ViewportCommand::Minimized(false));
                    ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
                }
            }
            self.last_tick = Instant::now();
            self.request_game_names(ctx);
        }
        // Auto texture-cap: while Roblox runs, keep newly-cached textures shrunk
        // to the chosen cap. Passes are cheap (already-capped files are skipped
        // from their header) and run off-thread, every 20s at most.
        if self.tex_auto
            && self.tex_cap > 0
            && self.roblox_running
            && !self.tex_running
            && self.last_tex_auto.elapsed() >= Duration::from_secs(20)
        {
            self.last_tex_auto = Instant::now();
            self.run_tex_pass(ctx, false);
        }
        if !self.backfill_started {
            self.backfill_started = true;
            self.start_backfill(ctx);
        }
        // One-time standby prewarm when the user has opted in.
        if self.standby == Some(true) && !self.standby_warmed {
            self.standby_warmed = true;
            self.prewarm_standby();
        }
        // Theme guard: while on, restore any changed theme file and re-lock it.
        if self.theme_lock && self.last_theme_heal.elapsed() >= Duration::from_secs(8) {
            self.last_theme_heal = Instant::now();
            if let Some(roblox) = self.roblox.clone() {
                let versions = paths::all_player_version_dirs(&roblox);
                let healed = mods::heal(&versions);
                mods::set_locked(&versions, true);
                if healed > 0 {
                    self.status = format!("Theme guard restored {healed} file(s).");
                }
            }
        }
        if self.profile.is_some() && !self.friends_loaded && !self.friends_loading {
            self.friends_loaded = true;
            self.load_friends(ctx);
        }
        self.avatars.poll(ctx);
        self.game_icons.poll(ctx);
        let mut places: Vec<u64> = self
            .recent_places()
            .iter()
            .filter_map(|p| p.parse().ok())
            .collect();
        places.extend(self.search_games.iter().map(|g| g.place_id));
        if let Ok(id) = self.game_place.parse::<u64>() {
            places.push(id);
        }
        if !places.is_empty() {
            self.game_icons.ensure(ctx, &places);
        }
        let mut wanted: Vec<u64> = self.friends.iter().map(|f| f.id).collect();
        wanted.extend(self.search_users.iter().map(|u| u.id));
        if let Some(p) = &self.profile {
            if let Ok(id) = p.user_id.parse::<u64>() {
                wanted.push(id);
            }
        }
        if !wanted.is_empty() {
            self.avatars.ensure(ctx, &wanted);
        }
    }

    /// Anti-spam: lets an action through at most once per `secs`. Roblox answers
    /// rapid repeats with "too many requests", so this protects the person too.
    fn cooldown(&mut self, key: &'static str, secs: u64) -> bool {
        let now = Instant::now();
        if let Some(last) = self.cooldowns.get(key) {
            if now.duration_since(*last) < Duration::from_secs(secs) {
                self.status = "Easy there. Give it a few seconds before trying that again.".into();
                return false;
            }
        }
        self.cooldowns.insert(key, now);
        true
    }

    /// Opens a game's page and fetches its details (unless they're already loaded).
    fn open_game(&mut self, ctx: &egui::Context, place: String, name_hint: Option<String>) {
        let same = self.game_place == place;
        self.page = Page::Game;
        self.game_place = place.clone();
        self.game_hint = name_hint;
        if same && self.game_details.is_some() {
            return;
        }
        self.game_details = None;
        self.game_error = None;
        self.game_loading = true;
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let result = net::fetch_game_details(&place);
            let _ = tx.send(Msg::GameDetails(place, result));
            ctx.request_repaint();
        });
    }

    fn check_for_update(&mut self, ctx: &egui::Context) {
        if self.update_busy {
            return;
        }
        self.update_busy = true;
        self.update_status = "Checking GitHub for the latest version…".into();
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let _ = tx.send(Msg::UpdateChecked(net::fetch_latest_version()));
            ctx.request_repaint();
        });
    }

    fn download_update(&mut self, ctx: &egui::Context) {
        if self.update_busy {
            return;
        }
        self.update_busy = true;
        self.update_status = "Downloading the update…".into();
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let _ = tx.send(Msg::UpdateDownloaded(net::download_latest_exe()));
            ctx.request_repaint();
        });
    }

    fn load_servers(&mut self, ctx: &egui::Context) {
        if !self.cooldown("servers", 3) {
            return;
        }
        let place = self.place_input.trim().to_string();
        self.loading = true;
        self.server_error = None;
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let _ = tx.send(Msg::Servers(net::fetch_servers(&place)));
            ctx.request_repaint();
        });
    }

    fn load_friends(&mut self, ctx: &egui::Context) {
        let Some(p) = self.profile.clone() else {
            return;
        };
        self.friends_loading = true;
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let _ = tx.send(Msg::Friends(net::fetch_friends(&p.user_id)));
            ctx.request_repaint();
        });
    }

    /// One-time, automatic: reads every Roblox Player log Ozara can find so
    /// Continue/Stats already has history from before Ozara was ever opened —
    /// nothing to replay, nothing for the person to do. Marks itself done
    /// right away (before the scan even runs) so a slow or failed scan is
    /// never retried on a later launch.
    fn start_backfill(&mut self, ctx: &egui::Context) {
        let Some(roblox) = self.roblox.clone() else {
            return;
        };
        let marker = sys::data_dir().join(".backfilled");
        if marker.exists() {
            return;
        }
        let _ = std::fs::write(&marker, b"1");
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let extra = tracker::scan_backfill(&roblox);
            let _ = tx.send(Msg::Backfill(extra));
            ctx.request_repaint();
        });
    }

    /// Looks up people and games by name at once, Roblox's own public search.
    fn run_search(&mut self, ctx: &egui::Context) {
        if !self.cooldown("search", 2) {
            return;
        }
        let q = self.search.trim().to_string();
        if q.is_empty() {
            return;
        }
        self.page = Page::Search;
        self.search_users.clear();
        self.search_games.clear();
        self.search_error = None;
        self.search_pending = 2;

        let (q1, tx1, ctx1) = (q.clone(), self.tx.clone(), ctx.clone());
        std::thread::spawn(move || {
            let _ = tx1.send(Msg::SearchUsers(net::search_users(&q1)));
            ctx1.request_repaint();
        });

        let (q2, tx2, ctx2) = (q, self.tx.clone(), ctx.clone());
        std::thread::spawn(move || {
            let _ = tx2.send(Msg::SearchGames(net::search_games(&q2)));
            ctx2.request_repaint();
        });
    }

    // Kept for later (OAuth sign-in); the account link now uses blurb verification.
    #[allow(dead_code)]
    fn start_sign_in(&mut self, ctx: &egui::Context) {
        let Some(client_id) = config::client_id() else {
            self.status =
                "Sign-in needs a Roblox app ID first. See the steps on the Home page.".into();
            return;
        };
        self.signing_in = true;
        self.status = "Finish signing in in your browser…".into();
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        let dir = sys::data_dir();
        std::thread::spawn(move || {
            let result = auth::sign_in(&client_id);
            if let Ok(p) = &result {
                auth::save_profile(&dir, p);
            }
            let _ = tx.send(Msg::SignedIn(result));
            ctx.request_repaint();
        });
    }

    /// Step 1 of verification: look up the username to get its user id.
    fn start_verify_lookup(&mut self, ctx: &egui::Context) {
        let name = self.link_input.trim().to_string();
        if name.is_empty() {
            self.status = "Type your Roblox username first.".into();
            return;
        }
        self.verify_pending = true;
        self.status = "Looking you up…".into();
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let _ = tx.send(Msg::VerifyFound(net::lookup_user(&name)));
            ctx.request_repaint();
        });
    }

    /// Step 2: read the profile blurb and check the code is in it.
    fn start_verify_check(&mut self, ctx: &egui::Context) {
        let (Some(p), Some(code)) = (self.verify_profile.clone(), self.verify_code.clone()) else {
            return;
        };
        self.verify_pending = true;
        self.status = "Checking your profile…".into();
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let result = net::fetch_user_description(&p.user_id)
                .map(|about| about.contains(&code));
            let _ = tx.send(Msg::VerifyChecked(result));
            ctx.request_repaint();
        });
    }

    fn cancel_verify(&mut self) {
        self.verify_profile = None;
        self.verify_code = None;
        self.verify_pending = false;
        self.status.clear();
    }

    /// Account linking by ownership verification: you prove the account is yours by
    /// pasting a one-time code into its profile blurb. No password, no ID, no cookies
    /// — and typing someone else's username gets you nowhere, since you can't edit
    /// their profile.
    fn link_ui(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        match (self.verify_profile.clone(), self.verify_code.clone()) {
            (Some(p), Some(code)) => {
                // Step 2 — waiting for the blurb.
                ui.label(bold(format!("Verifying @{}", p.username), 13.0));
                ui.add_space(4.0);
                ui.label("1. Open your Roblox profile and edit your About.");
                ui.label("2. Paste this code in, and save:");
                ui.add_space(4.0);
                ui.horizontal(|ui| {
                    ui.add(egui::TextEdit::singleline(&mut code.clone()).desired_width(220.0));
                    if ghost_button(ui, "Open my profile").clicked() {
                        let _ = sys::open_link(&format!(
                            "https://www.roblox.com/users/{}/profile",
                            p.user_id
                        ));
                    }
                });
                ui.add_space(6.0);
                ui.horizontal(|ui| {
                    let label = if self.verify_pending { "Checking…" } else { "Verify" };
                    if primary_button(ui, label).clicked() && !self.verify_pending {
                        self.start_verify_check(ctx);
                    }
                    if ghost_button(ui, "Cancel").clicked() {
                        self.cancel_verify();
                    }
                });
                muted_label(ui, "Once verified you can delete the code from your profile.");
            }
            _ => {
                // Step 1 — enter username.
                ui.label("Link your account by verifying you own it — no password, no ID.");
                ui.horizontal(|ui| {
                    let edit = ui.add(
                        egui::TextEdit::singleline(&mut self.link_input)
                            .hint_text("Roblox username")
                            .desired_width(240.0),
                    );
                    let enter =
                        edit.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
                    let label = if self.verify_pending { "…" } else { "Verify ownership" };
                    if (primary_button(ui, label).clicked() || enter) && !self.verify_pending {
                        self.start_verify_lookup(ctx);
                    }
                });
                muted_label(
                    ui,
                    "You'll paste a one-time code into your Roblox profile to prove it's yours.",
                );
            }
        }
    }

    fn sign_out(&mut self) {
        auth::clear_profile(&sys::data_dir());
        self.profile = None;
        self.friends.clear();
        self.friends_loaded = false;
        self.status = "Account unlinked.".into();
    }

    /// Places played recently, newest first.
    fn recent_places(&self) -> Vec<String> {
        let mut sessions: Vec<&playtime::Session> = self.tracker.sessions.iter().collect();
        sessions.sort_by_key(|s| std::cmp::Reverse(s.end));
        let mut out: Vec<String> = Vec::new();
        for s in sessions {
            if !out.contains(&s.place_id) {
                out.push(s.place_id.clone());
            }
            if out.len() == 7 {
                break;
            }
        }
        out
    }

    fn request_game_names(&mut self, ctx: &egui::Context) {
        let wanted: Vec<String> = self
            .recent_places()
            .into_iter()
            .filter(|p| !self.game_names.contains_key(p) && !self.names_requested.contains(p))
            .collect();
        if wanted.is_empty() {
            return;
        }
        self.names_requested.extend(wanted.iter().cloned());
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let _ = tx.send(Msg::Names(net::fetch_game_names(&wanted)));
            ctx.request_repaint();
        });
    }

    fn join_server(&mut self, place: &str, job: Option<&str>) {
        if !self.cooldown("launch", 6) {
            return;
        }
        match join::join_link(place, job) {
            Some(link) => match sys::open_link(&link) {
                Ok(()) => self.status = "Opening Roblox…".into(),
                Err(e) => self.status = format!("Could not open Roblox: {e}"),
            },
            None => self.status = "That game or server ID looks wrong.".into(),
        }
    }

    fn chosen(&self) -> (BTreeMap<String, flags::FlagValue>, Vec<String>) {
        let ids: Vec<&str> = self
            .catalog
            .iter()
            .filter(|s| self.enabled[s.id])
            .map(|s| s.id)
            .collect();
        let (mut map, skipped) = flags::resolve(&ids, &self.allow);
        // The user's own custom flags are written as-is (Roblox ignores any it
        // doesn't allow, harmlessly). They override a preset flag of the same name.
        for (name, value) in flags::parse_custom_flags(&self.custom_flags) {
            map.insert(name, value);
        }
        (map, skipped)
    }

    fn write_all(
        roblox: &PathBuf,
        flag_map: &BTreeMap<String, flags::FlagValue>,
        cap: i32,
    ) -> Result<usize, String> {
        // Write to EVERY installed version folder, not just the newest — Roblox may
        // launch an older one, and FastFlags only apply to the version that runs.
        let versions = paths::all_player_version_dirs(roblox);
        if versions.is_empty() {
            return Err("Could not find an installed Roblox version.".into());
        }
        for version in &versions {
            flags::write_settings(version, flag_map)
                .map_err(|e| format!("Could not write graphics settings: {e}"))?;
        }
        let file = paths::global_settings_file(roblox);
        if file.is_file() {
            fps::write_framerate_cap(&file, cap)
                .map_err(|e| format!("Could not set the FPS cap: {e}"))?;
        }
        Ok(versions.len())
    }

    /// Undoes every change Ozara has ever made to Roblox's shared framerate/graphics
    /// file (`GlobalBasicSettings_13.xml`) by copying back the untouched copy Ozara
    /// saved the first time it ever wrote to it. Unlike the "Default" preset (which
    /// only clears the per-version `ClientAppSettings.json`), this file lives in
    /// Roblox's shared root folder and survives a Roblox version update, so it needs
    /// its own undo.
    fn restore_fps_backup(&mut self) {
        let Some(roblox) = self.roblox.clone() else {
            self.status = "Roblox was not found on this PC.".into();
            return;
        };
        if sys::roblox_running() {
            self.status = "Close Roblox first, then try Restore again.".into();
            return;
        }
        let file = paths::global_settings_file(&roblox);
        self.status = match fps::restore_backup(&file) {
            Ok(true) => "Restored Roblox's framerate settings to how they were before Ozara ever touched them.".into(),
            Ok(false) => "Nothing to restore — Ozara hasn't changed this file yet.".into(),
            Err(e) => format!("Could not restore the backup: {e}"),
        };
    }

    /// Closes Roblox and rejoins the exact server you were in, without changing
    /// any settings — the "soft restart" for when a game is lagging or glitched.
    fn soft_restart(&mut self, ctx: &egui::Context) {
        let Some(cur) = self.tracker.current.clone() else {
            self.status = "You're not in a game right now, so there's nothing to restart.".into();
            return;
        };
        let Some(link) = join::join_link(&cur.place_id, Some(&cur.job_id)) else {
            self.status = "Couldn't work out which server to rejoin.".into();
            return;
        };
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        self.status = "Restarting Roblox…".into();
        std::thread::spawn(move || {
            let result = (|| -> Result<String, String> {
                if sys::roblox_running() {
                    sys::close_roblox();
                    if !sys::wait_roblox_closed(15) {
                        return Err("Roblox didn't close in time. Try again in a moment.".into());
                    }
                }
                sys::open_link(&link)?;
                Ok("Rejoining your server…".into())
            })();
            let _ = tx.send(Msg::Status(result.unwrap_or_else(|e| e)));
            ctx.request_repaint();
        });
    }

    /// Closes Roblox and joins a *different* public server of the same game —
    /// the emptiest one found — for a quick server hop without leaving the game.
    fn join_new_server(&mut self, ctx: &egui::Context) {
        let Some(cur) = self.tracker.current.clone() else {
            self.status = "You're not in a game right now.".into();
            return;
        };
        let place = cur.place_id.clone();
        let current_job = cur.job_id.clone();
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        self.status = "Finding another server…".into();
        std::thread::spawn(move || {
            let result = (|| -> Result<String, String> {
                let servers = net::fetch_servers(&place)?;
                // Emptiest server that isn't the one we're already in.
                let pick = servers
                    .iter()
                    .filter(|s| s.id != current_job && !s.is_full())
                    .min_by_key(|s| s.players)
                    .ok_or("No other servers are open right now.")?;
                let link = join::join_link(&place, Some(&pick.id)).ok_or("Couldn't build the join link.")?;
                if sys::roblox_running() {
                    sys::close_roblox();
                    if !sys::wait_roblox_closed(15) {
                        return Err("Roblox didn't close in time. Try again in a moment.".into());
                    }
                }
                sys::open_link(&link)?;
                Ok("Joining a new server…".into())
            })();
            let _ = tx.send(Msg::Status(result.unwrap_or_else(|e| e)));
            ctx.request_repaint();
        });
    }

    fn apply_mods(&mut self) {
        let Some(roblox) = self.roblox.clone() else {
            self.status = "Roblox was not found on this PC.".into();
            return;
        };
        if sys::roblox_running() {
            self.status = "Close Roblox first, then Apply mods.".into();
            return;
        }
        let versions = paths::all_player_version_dirs(&roblox);
        self.status = match mods::apply(&versions) {
            Ok(n) => format!("Applied {n} mod file(s). Launch Roblox to see them."),
            Err(e) => e,
        };
    }

    fn remove_mods(&mut self) {
        let Some(roblox) = self.roblox.clone() else {
            self.status = "Roblox was not found on this PC.".into();
            return;
        };
        if sys::roblox_running() {
            self.status = "Close Roblox first, then Remove mods.".into();
            return;
        }
        let versions = paths::all_player_version_dirs(&roblox);
        self.status = match mods::remove(&versions) {
            Ok(()) => "Removed mods and restored Roblox's original files.".into(),
            Err(e) => e,
        };
    }

    /// Warm the Roblox client into the OS disk cache on a worker thread, so the
    /// next launch skips the disk read. Only warms cache — starts no process.
    fn prewarm_standby(&mut self) {
        let Some(roblox) = self.roblox.clone() else {
            return;
        };
        let versions = paths::all_player_version_dirs(&roblox);
        if versions.is_empty() {
            return;
        }
        std::thread::spawn(move || {
            let _ = sys::prewarm_roblox(&versions);
        });
    }

    fn tex_cap_label(&self) -> String {
        if self.tex_cap == 0 {
            "Original".into()
        } else {
            format!("{}px", self.tex_cap)
        }
    }

    fn scan_cache(&mut self) {
        let r = texcache::scan(self.tex_cap);
        if r.dirs == 0 {
            self.status = "No Roblox asset cache found yet — load a game once, then scan.".into();
            return;
        }
        self.status = format!(
            "Cache: {} files, {} PNG/JPEG texture(s) over the {} cap (biggest {}px). {} WebP/KTX textures can't be touched.",
            r.files, r.shrinkable, self.tex_cap_label(), r.largest, r.other_imgs
        );
    }

    /// Runs a downscale pass on a worker thread, posting the result as TexDone.
    fn run_tex_pass(&mut self, ctx: &egui::Context, note_when_empty: bool) {
        if self.tex_running {
            return;
        }
        if self.tex_cap == 0 {
            if note_when_empty {
                self.status = "Set a resolution cap first (Original means no downscaling).".into();
            }
            return;
        }
        self.tex_running = true;
        let cap = self.tex_cap;
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let msg = match texcache::apply(cap) {
                Ok(r) if r.shrunk == 0 => {
                    if note_when_empty {
                        "Nothing over the cap right now — load a game so its textures are cached, then try again.".into()
                    } else {
                        String::new() // silent for auto passes with nothing to do
                    }
                }
                Ok(r) => {
                    let saved = r.bytes_before.saturating_sub(r.bytes_after) / (1024 * 1024);
                    format!(
                        "Capped {} texture(s), ~{} MB saved. Applies on the next load/rejoin. Clear Roblox's cache to undo.",
                        r.shrunk, saved
                    )
                }
                Err(e) => e,
            };
            let _ = tx.send(Msg::TexDone(msg));
            ctx.request_repaint();
        });
    }

    fn downscale_cache(&mut self, ctx: &egui::Context) {
        self.run_tex_pass(ctx, true);
    }

    fn apply(&mut self, ctx: &egui::Context, rejoin: bool) {
        let Some(roblox) = self.roblox.clone() else {
            self.status = "Roblox was not found on this PC.".into();
            return;
        };
        let (flag_map, _) = self.chosen();
        let cap = self.fps_cap;
        // Remember the selections so Ozara's Settings screen reflects them next launch.
        let enabled_ids: Vec<&str> =
            self.catalog.iter().filter(|s| self.enabled[s.id]).map(|s| s.id).collect();
        store::save_prefs(&enabled_ids, cap);
        let running = sys::roblox_running();
        if running && !rejoin {
            self.status = "Roblox is running. Close it first, or use \"Apply and rejoin\".".into();
            return;
        }
        if !rejoin {
            self.status = match Self::write_all(&roblox, &flag_map, cap) {
                Ok(n) => format!(
                    "Saved to {n} Roblox version folder(s). The settings apply next time Roblox starts."
                ),
                Err(e) => e,
            };
            return;
        }
        let link = self
            .tracker
            .current
            .as_ref()
            .and_then(|c| join::join_link(&c.place_id, Some(&c.job_id)));
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        self.status = "Closing Roblox…".into();
        std::thread::spawn(move || {
            let result = (|| -> Result<String, String> {
                if running {
                    sys::close_roblox();
                    if !sys::wait_roblox_closed(15) {
                        return Err(
                            "Roblox did not close. Save your progress in the game and try again."
                                .into(),
                        );
                    }
                }
                OzaraApp::write_all(&roblox, &flag_map, cap)?;
                match link {
                    Some(l) => {
                        sys::open_link(&l)?;
                        Ok("Settings applied. Rejoining your server…".into())
                    }
                    None => {
                        Ok("Settings saved. No game was running, so nothing was reopened.".into())
                    }
                }
            })();
            let _ = tx.send(Msg::Status(result.unwrap_or_else(|e| e)));
            ctx.request_repaint();
        });
    }

    fn week_seconds(&self) -> i64 {
        let now = sys::now_unix();
        playtime::seconds_between(&self.tracker.sessions, now - 7 * 86_400, now)
    }

    // ------------------------------------------------------------ shared pieces

    fn nav_item(ui: &mut egui::Ui, icon: &str, label: &str, selected: bool) -> bool {
        let (rect, resp) = ui.allocate_exact_size(egui::vec2(68.0, 58.0), egui::Sense::click());
        if selected || resp.hovered() {
            let alpha = if selected { 52 } else { 24 };
            ui.painter().rect_filled(
                rect,
                egui::Rounding::same(14.0),
                Color32::from_white_alpha(alpha),
            );
        }
        let icon_rect = egui::Rect::from_center_size(
            egui::pos2(rect.center().x, rect.top() + 20.0),
            egui::vec2(22.0, 22.0),
        );
        egui::Image::new(assets::icon(icon))
            .tint(Color32::WHITE)
            .paint_at(ui, icon_rect);
        ui.painter().text(
            egui::pos2(rect.center().x, rect.bottom() - 12.0),
            egui::Align2::CENTER_CENTER,
            label,
            FontId::new(10.5, FontFamily::Name("medium".into())),
            Color32::WHITE,
        );
        resp.clicked()
    }

    fn round_icon_button(ui: &mut egui::Ui, icon: &str, tip: &str) -> egui::Response {
        let (rect, resp) = ui.allocate_exact_size(egui::vec2(48.0, 48.0), egui::Sense::click());
        let fill = if resp.hovered() {
            Color32::from_rgba_unmultiplied(40, 30, 66, 240)
        } else {
            Color32::from_rgba_unmultiplied(18, 14, 30, 215)
        };
        ui.painter().circle_filled(rect.center(), 24.0, fill);
        let icon_rect = egui::Rect::from_center_size(rect.center(), egui::vec2(21.0, 21.0));
        egui::Image::new(assets::icon(icon))
            .tint(Color32::WHITE)
            .paint_at(ui, icon_rect);
        resp.on_hover_text(tip)
    }

    fn top_bar(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        let avail = ui.available_width();
        let center_w = 560.0;
        let wordmark_w = 133.0;
        let space = ((avail - center_w) / 2.0 - wordmark_w).max(8.0);
        ui.horizontal(|ui| {
            ui.add(
                egui::Image::new(assets::wordmark())
                    .fit_to_exact_size(egui::vec2(wordmark_w, 36.0)),
            );
            ui.add_space(space);

            // Search pill
            egui::Frame::none()
                .fill(Color32::from_rgba_unmultiplied(18, 14, 30, 215))
                .rounding(egui::Rounding::same(24.0))
                .inner_margin(egui::Margin::symmetric(18.0, 12.0))
                .show(ui, |ui| {
                    ui.set_width(400.0);
                    ui.horizontal(|ui| {
                        ui.add(
                            egui::Image::new(assets::icon("search"))
                                .tint(muted())
                                .fit_to_exact_size(egui::vec2(20.0, 20.0)),
                        );
                        let edit = ui.add(
                            egui::TextEdit::singleline(&mut self.search)
                                .frame(false)
                                .hint_text("Search games, friends…")
                                .desired_width(f32::INFINITY),
                        );
                        if edit.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                            let q = self.search.trim().to_string();
                            if join::is_numeric_id(&q) {
                                self.place_input = q;
                                self.page = Page::Servers;
                                self.load_servers(ctx);
                            } else if !q.is_empty() {
                                self.run_search(ctx);
                            }
                        }
                    });
                });
            let quick = Self::round_icon_button(ui, "sliders", "Quick settings");
            if quick.clicked() {
                self.quick_open = !self.quick_open;
            }
            self.quick_anchor = quick.rect.left_bottom() + egui::vec2(0.0, 8.0);
            self.quick_btn_rect = quick.rect;
            if Self::round_icon_button(ui, "gear", "Settings").clicked() {
                self.page = Page::Settings;
            }

            ui.with_layout(
                egui::Layout::right_to_left(egui::Align::Center),
                |ui| match self.profile.clone() {
                    Some(p) => {
                        egui::Frame::none()
                            .fill(Color32::from_rgba_unmultiplied(18, 14, 30, 215))
                            .rounding(egui::Rounding::same(24.0))
                            .inner_margin(egui::Margin {
                                left: 6.0,
                                right: 18.0,
                                top: 6.0,
                                bottom: 6.0,
                            })
                            .show(ui, |ui| {
                                ui.horizontal(|ui| {
                                    let id: u64 = p.user_id.parse().unwrap_or(0);
                                    let initial = p
                                        .name
                                        .chars()
                                        .next()
                                        .unwrap_or('?')
                                        .to_uppercase()
                                        .to_string();
                                    avatar_photo(ui, 36.0, self.avatars.get(id), &initial, id);
                                    ui.label(bold(&p.name, 13.0));
                                    if p.verified == Some(true) {
                                        ui.label(RichText::new("✓").color(cyan()).size(13.0))
                                            .on_hover_text("Roblox ID-verified");
                                    }
                                });
                            });
                    }
                    None => {
                        if primary_button(ui, "Link account").clicked() {
                            self.page = Page::Home;
                        }
                    }
                },
            );
        });
    }

    #[allow(dead_code)]
    fn setup_help(ui: &mut egui::Ui) {
        muted_label(
            ui,
            "One-time setup for sign-in (you need to be ID-verified on Roblox):",
        );
        for line in [
            "1. Open create.roblox.com → OAuth 2.0 Apps → Create App.",
            "2. Add the redirect URL:  http://localhost:53682/callback",
            "3. Under scopes choose openid, profile, and (optional) user.advanced:read and user.social:read. Save.",
            "4. Copy the Client ID into a file named client_id.txt in %APPDATA%\\Ozara, then restart Ozara.",
        ] {
            ui.label(RichText::new(line).size(12.5));
        }
    }

    // ------------------------------------------------------------ pages

    /// A clickable game card. Shows the game's real icon when it has loaded, otherwise
    /// a colored placeholder. Lifts slightly and gets a soft glow while hovered.
    fn game_tile(
        ui: &mut egui::Ui,
        name: &str,
        seed: u64,
        icon: Option<&egui::TextureHandle>,
    ) -> egui::Response {
        let (slot, resp) = ui.allocate_exact_size(egui::vec2(92.0, 100.0), egui::Sense::click());
        let resp = resp.on_hover_cursor(egui::CursorIcon::PointingHand);
        let t = ui
            .ctx()
            .animate_bool_with_time(resp.id, resp.hovered(), 0.12);
        let rect = slot.translate(egui::vec2(0.0, -5.0 * t));
        let painter = ui.painter();
        if t > 0.0 {
            painter.rect_filled(
                rect.expand(3.0 * t),
                egui::Rounding::same(15.0),
                Color32::from_rgba_unmultiplied(139, 92, 246, (70.0 * t) as u8),
            );
        }
        let top = egui::Rect::from_min_size(rect.min, egui::vec2(92.0, 68.0));
        let top_round = egui::Rounding {
            nw: 12.0,
            ne: 12.0,
            sw: 0.0,
            se: 0.0,
        };
        match icon {
            Some(tex) => {
                // Icons are square; crop the middle band so they fill the wide top area without stretching.
                let crop = (1.0 - 68.0 / 92.0) / 2.0;
                let uv =
                    egui::Rect::from_min_max(egui::pos2(0.0, crop), egui::pos2(1.0, 1.0 - crop));
                egui::Image::from_texture(egui::load::SizedTexture::new(tex.id(), top.size()))
                    .uv(uv)
                    .rounding(top_round)
                    .paint_at(ui, top);
            }
            None => {
                painter.rect_filled(top, top_round, hsl(200.0 + (seed % 140) as f32, 0.7, 0.5));
            }
        }
        let bottom = egui::Rect::from_min_max(
            egui::pos2(rect.left(), rect.top() + 68.0),
            egui::pos2(rect.right(), rect.top() + 96.0),
        );
        let shade = 24 + (22.0 * t) as u8;
        ui.painter().rect_filled(
            bottom,
            egui::Rounding {
                nw: 0.0,
                ne: 0.0,
                sw: 12.0,
                se: 12.0,
            },
            Color32::from_rgba_unmultiplied(255, 255, 255, shade),
        );
        let shown: String = if name.chars().count() > 12 {
            name.chars().take(11).collect::<String>() + "…"
        } else {
            name.to_string()
        };
        ui.painter().text(
            bottom.center(),
            egui::Align2::CENTER_CENTER,
            shown,
            FontId::new(10.5, FontFamily::Name("bold".into())),
            Color32::WHITE,
        );
        resp
    }

    fn page_home(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        // One-time standby prompt.
        if self.standby.is_none() {
            panel(ui, |ui| {
                heading(ui, "Faster launches?");
                muted_label(ui, "Ozara can keep Roblox's client files warm in memory while it sits in the tray, so games launch quicker from a cold start. It only reads files into cache — nothing is changed, and no Roblox process is started.");
                ui.add_space(6.0);
                ui.horizontal(|ui| {
                    if primary_button(ui, "Keep Roblox on standby").clicked() {
                        self.standby = Some(true);
                        store::save_standby(true);
                        self.standby_warmed = true;
                        self.prewarm_standby();
                        self.status = "Standby on — Roblox will be kept warm for faster launches.".into();
                    }
                    if ghost_button(ui, "No thanks").clicked() {
                        self.standby = Some(false);
                        store::save_standby(false);
                    }
                });
            });
            ui.add_space(6.0);
        }
        // Friends
        panel(ui, |ui| {
            ui.horizontal(|ui| {
                heading(ui, "Friends");
                if self.profile.is_some() {
                    let n = self
                        .friends_count
                        .map(|c| c as usize)
                        .unwrap_or(self.friends.len());
                    ui.label(RichText::new(format!("({n})")).color(muted()));
                }
            });
            match self.profile.clone() {
                None => {
                    self.link_ui(ui, ctx);
                }
                Some(_) => {
                    let friends = self.friends.clone();
                    egui::ScrollArea::horizontal().show(ui, |ui| {
                        ui.horizontal_top(|ui| {
                            ui.vertical(|ui| {
                                ui.set_width(72.0);
                                let (rect, resp) = ui.allocate_exact_size(
                                    egui::vec2(56.0, 56.0),
                                    egui::Sense::click(),
                                );
                                ui.painter().circle_filled(
                                    rect.center(),
                                    28.0,
                                    Color32::from_white_alpha(28),
                                );
                                egui::Image::new(assets::icon("plus"))
                                    .tint(cyan())
                                    .paint_at(
                                        ui,
                                        egui::Rect::from_center_size(
                                            rect.center(),
                                            egui::vec2(24.0, 24.0),
                                        ),
                                    );
                                if resp.clicked() {
                                    let _ = sys::open_link("https://www.roblox.com/users/friends");
                                }
                                muted_label(ui, "Add friends");
                            });
                            for f in friends.iter().take(14) {
                                ui.vertical(|ui| {
                                    ui.set_width(72.0);
                                    let initial = f
                                        .shown_name()
                                        .chars()
                                        .next()
                                        .unwrap_or('?')
                                        .to_uppercase()
                                        .to_string();
                                    if avatar_photo(
                                        ui,
                                        56.0,
                                        self.avatars.get(f.id),
                                        &initial,
                                        f.id,
                                    )
                                    .clicked()
                                    {
                                        let _ = sys::open_link(&format!(
                                            "https://www.roblox.com/users/{}/profile",
                                            f.id
                                        ));
                                    }
                                    let name: String = f.shown_name().chars().take(10).collect();
                                    ui.label(bold(name, 11.0));
                                });
                            }
                            if friends.len() > 14 {
                                ui.vertical(|ui| {
                                    ui.set_width(72.0);
                                    let (rect, resp) = ui.allocate_exact_size(
                                        egui::vec2(56.0, 56.0),
                                        egui::Sense::click(),
                                    );
                                    ui.painter().circle_filled(
                                        rect.center(),
                                        28.0,
                                        Color32::from_white_alpha(28),
                                    );
                                    egui::Image::new(assets::icon("plus"))
                                        .tint(cyan())
                                        .paint_at(
                                            ui,
                                            egui::Rect::from_center_size(
                                                rect.center(),
                                                egui::vec2(24.0, 24.0),
                                            ),
                                        );
                                    if resp.clicked() {
                                        self.page = Page::Friends;
                                    }
                                    muted_label(ui, "More friends");
                                });
                            }
                        });
                    });
                    if self.friends_loading {
                        muted_label(ui, "Loading friends…");
                    } else if self.friends_restricted {
                        muted_label(ui, "Roblox has restricted this account's friends list, so names can't be shown — only the count above.");
                    }
                }
            }
        });
        ui.add_space(4.0);

        // Continue
        let tiles: Vec<(String, String)> = if self.demo {
            [
                "Obby Rush",
                "Tower Defense",
                "Drift Tag",
                "Block Bridge",
                "Hide and Seek",
                "Sky Racers",
                "Cafe Tycoon",
            ]
            .iter()
            .enumerate()
            .map(|(i, n)| (format!("{}", 900 + i), n.to_string()))
            .collect()
        } else {
            // Dedup by game name, so the same game doesn't appear twice; when a
            // duplicate has a loaded icon and the kept one doesn't, prefer the one
            // with the icon (that's what fixes the "duplicate, no image" tiles).
            let mut out: Vec<(String, String)> = Vec::new();
            for p in self.recent_places() {
                let name = self.game_names.get(&p).cloned().unwrap_or_else(|| format!("Game {p}"));
                let pid: u64 = p.parse().unwrap_or(0);
                let has_icon = self.game_icons.get(pid).is_some();
                if let Some(existing) = out.iter_mut().find(|(_, n)| *n == name) {
                    let existing_pid: u64 = existing.0.parse().unwrap_or(0);
                    if has_icon && self.game_icons.get(existing_pid).is_none() {
                        existing.0 = p;
                    }
                } else {
                    out.push((p, name));
                }
            }
            out
        };
        panel(ui, |ui| {
            heading(ui, "Continue");
            if tiles.is_empty() {
                muted_label(ui, "Games you play will show up here. Ozara learns them from Roblox's own log files.");
            } else {
                ui.horizontal_top(|ui| {
                    for (place, name) in &tiles {
                        let pid: u64 = place.parse().unwrap_or(0);
                        if Self::game_tile(ui, name, pid, self.game_icons.get(pid)).clicked() {
                            self.open_game(ctx, place.clone(), Some(name.clone()));
                        }
                    }
                });
            }
        });
        ui.add_space(4.0);

        // Recommended (sample only until it can use real data)
        if self.demo {
            panel(ui, |ui| {
                heading(ui, "Recommended for you");
                ui.horizontal_top(|ui| {
                    for (i, n) in [
                        "Sample game one",
                        "Sample game two",
                        "Sample game three",
                        "Sample game four",
                        "Sample game five",
                    ]
                    .iter()
                    .enumerate()
                    {
                        ui.vertical(|ui| {
                            let (rect, _) = ui
                                .allocate_exact_size(egui::vec2(150.0, 70.0), egui::Sense::hover());
                            ui.painter().rect_filled(
                                rect,
                                egui::Rounding::same(12.0),
                                hsl(170.0 + i as f32 * 38.0, 0.7, 0.5),
                            );
                            ui.label(bold(*n, 11.0));
                        });
                    }
                });
            });
        } else {
            panel(ui, |ui| {
                heading(ui, "This week");
                ui.label(bold(playtime::format_duration(self.week_seconds()), 26.0));
            });
        }
    }

    fn page_friends(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        panel(ui, |ui| {
            heading(ui, "Friends");
            if self.profile.is_none() {
                self.link_ui(ui, ctx);
                return;
            }
            ui.horizontal(|ui| {
                if ghost_button(ui, "Refresh").clicked() {
                    self.friends_loaded = false;
                }
                if ghost_button(ui, "Unlink account").clicked() {
                    self.sign_out();
                }
            });
            muted_label(
                ui,
                "Online status needs extra Roblox permissions and is not available yet.",
            );
            if self.friends_restricted {
                let n = self
                    .friends_count
                    .map(|c| c.to_string())
                    .unwrap_or_else(|| "an unknown number of".into());
                muted_label(ui, &format!("Roblox has restricted this account's friends list. It reports {n} friends, but won't say who they are."));
            }
            for f in self.friends.clone() {
                ui.horizontal(|ui| {
                    let initial = f
                        .shown_name()
                        .chars()
                        .next()
                        .unwrap_or('?')
                        .to_uppercase()
                        .to_string();
                    avatar_photo(ui, 40.0, self.avatars.get(f.id), &initial, f.id);
                    ui.vertical(|ui| {
                        ui.label(bold(f.shown_name(), 13.0));
                        muted_label(ui, &format!("@{}", f.name));
                    });
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ghost_button(ui, "Profile").clicked() {
                            let _ = sys::open_link(&format!(
                                "https://www.roblox.com/users/{}/profile",
                                f.id
                            ));
                        }
                    });
                });
            }
        });
    }

    /// The small popup under the top bar's sliders button.
    fn quick_settings(&mut self, ctx: &egui::Context) {
        if !self.quick_open {
            return;
        }
        let area = egui::Area::new(egui::Id::new("quick_settings"))
            .order(egui::Order::Foreground)
            .fixed_pos(self.quick_anchor)
            .show(ctx, |ui| {
                egui::Frame::popup(ui.style()).show(ui, |ui| {
                    ui.set_width(300.0);
                    ui.label(bold("Quick settings", 14.0));
                    ui.add_space(6.0);
                    muted_label(ui, "FPS cap");
                    ui.horizontal_wrapped(|ui| {
                        for cap in fps::CAP_OPTIONS {
                            if chip(ui, &fps::cap_label(cap), self.fps_cap == cap) {
                                self.fps_cap = cap;
                            }
                        }
                    });
                    ui.add_space(8.0);
                    ui.horizontal(|ui| {
                        if primary_button(ui, "Apply").clicked() {
                            self.apply(ctx, false);
                        }
                        if ghost_button(ui, "Apply and rejoin").clicked() {
                            self.apply(ctx, true);
                        }
                    });
                    ui.add_space(6.0);
                    if ghost_button(ui, "All settings").clicked() {
                        self.page = Page::Settings;
                        self.quick_open = false;
                    }
                });
            });
        // A click anywhere else closes it.
        let rect = area.response.rect;
        if ctx.input(|i| i.pointer.any_pressed()) {
            if let Some(pos) = ctx.input(|i| i.pointer.interact_pos()) {
                if !rect.contains(pos) && !self.quick_btn_rect.contains(pos) {
                    self.quick_open = false;
                }
            }
        }
    }

    fn page_game(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        let place = self.game_place.clone();
        let pid: u64 = place.parse().unwrap_or(0);
        let name = self
            .game_details
            .as_ref()
            .map(|d| d.name.clone())
            .or_else(|| self.game_hint.clone())
            .or_else(|| self.game_names.get(&place).cloned())
            .unwrap_or_else(|| format!("Game {place}"));
        let played: i64 = self
            .tracker
            .sessions
            .iter()
            .filter(|s| s.place_id == place)
            .map(|s| (s.end - s.start).max(0))
            .sum();

        panel(ui, |ui| {
            ui.horizontal_top(|ui| {
                let (rect, _) =
                    ui.allocate_exact_size(egui::vec2(168.0, 168.0), egui::Sense::hover());
                match self.game_icons.get(pid) {
                    Some(tex) => {
                        egui::Image::from_texture(egui::load::SizedTexture::new(
                            tex.id(),
                            rect.size(),
                        ))
                        .rounding(egui::Rounding::same(18.0))
                        .paint_at(ui, rect);
                    }
                    None => {
                        ui.painter().rect_filled(
                            rect,
                            egui::Rounding::same(18.0),
                            hsl(200.0 + (pid % 140) as f32, 0.7, 0.5),
                        );
                    }
                }
                ui.add_space(14.0);
                ui.vertical(|ui| {
                    ui.label(bold(&name, 24.0));
                    if let Some(d) = &self.game_details {
                        if !d.creator.is_empty() {
                            muted_label(ui, &format!("by {}", d.creator));
                        }
                    }
                    ui.add_space(10.0);
                    ui.horizontal(|ui| {
                        if primary_button(ui, "Play").clicked() {
                            self.join_server(&place, None);
                        }
                        if ghost_button(ui, "Servers").clicked() {
                            self.place_input = place.clone();
                            self.page = Page::Servers;
                            self.load_servers(ctx);
                        }
                        if ghost_button(ui, "Open on roblox.com").clicked() {
                            let _ =
                                sys::open_link(&format!("https://www.roblox.com/games/{place}"));
                        }
                        let fav = store::is_favourite(&self.favourites, &place);
                        let label = if fav { "★ Favourited" } else { "☆ Favourite" };
                        if ghost_button(ui, label).clicked() {
                            store::toggle_favourite(&mut self.favourites, &place, &name);
                        }
                    });
                    ui.add_space(8.0);
                    if played > 0 {
                        muted_label(
                            ui,
                            &format!(
                                "You've played this for {}",
                                playtime::format_duration(played)
                            ),
                        );
                    }
                });
            });
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            if self.game_loading {
                muted_label(ui, "Loading details…");
            }
            if let Some(e) = &self.game_error {
                ui.label(RichText::new(e).color(warn()));
            }
            if let Some(d) = &self.game_details {
                ui.horizontal_wrapped(|ui| {
                    ui.label(bold(format!("{} playing", compact(d.playing)), 14.0));
                    ui.label(RichText::new("·").color(muted()));
                    ui.label(bold(format!("{} visits", compact(d.visits)), 14.0));
                    ui.label(RichText::new("·").color(muted()));
                    ui.label(bold(format!("{} favorites", compact(d.favorited)), 14.0));
                    if d.max_players > 0 {
                        ui.label(RichText::new("·").color(muted()));
                        ui.label(bold(format!("up to {} players", d.max_players), 14.0));
                    }
                    if !d.genre.is_empty() && d.genre != "All" {
                        ui.label(RichText::new("·").color(muted()));
                        ui.label(bold(d.genre.clone(), 14.0));
                    }
                });
                if !d.description.trim().is_empty() {
                    ui.add_space(8.0);
                    let text: String = d.description.trim().chars().take(700).collect();
                    ui.label(RichText::new(text).size(13.0));
                }
            }
        });
    }

    fn page_search(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        panel(ui, |ui| {
            ui.horizontal(|ui| {
                heading(ui, "Search");
                ui.label(RichText::new(format!("\u{201c}{}\u{201d}", self.search)).color(muted()));
            });
            muted_label(ui, "People and games, from Roblox's own public search.");
            ui.add_space(4.0);
            ui.horizontal(|ui| {
                for f in SearchFilter::ALL {
                    if chip(ui, f.label(), self.search_filter == f) {
                        self.search_filter = f;
                    }
                }
            });
            if self.search_pending > 0 {
                muted_label(ui, "Searching…");
            }
            if let Some(e) = &self.search_error {
                ui.label(RichText::new(e).color(bad()));
            }
        });
        ui.add_space(6.0);

        if self.search_filter.show_people() && !self.search_users.is_empty() {
            panel(ui, |ui| {
                heading(ui, "People");
                for u in self.search_users.clone() {
                    ui.horizontal(|ui| {
                        let initial = u
                            .shown_name()
                            .chars()
                            .next()
                            .unwrap_or('?')
                            .to_uppercase()
                            .to_string();
                        avatar_photo(ui, 40.0, self.avatars.get(u.id), &initial, u.id);
                        ui.vertical(|ui| {
                            ui.label(bold(u.shown_name(), 13.0));
                            muted_label(ui, &format!("@{}", u.name));
                        });
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ghost_button(ui, "Profile").clicked() {
                                let _ = sys::open_link(&format!(
                                    "https://www.roblox.com/users/{}/profile",
                                    u.id
                                ));
                            }
                        });
                    });
                }
            });
            ui.add_space(6.0);
        }

        if self.search_filter.show_games() && !self.search_games.is_empty() {
            panel(ui, |ui| {
                heading(ui, "Games");
                for g in self.search_games.clone() {
                    ui.horizontal(|ui| {
                        if Self::game_tile(
                            ui,
                            &g.name,
                            g.universe_id,
                            self.game_icons.get(g.place_id),
                        )
                        .clicked()
                        {
                            self.open_game(ctx, g.place_id.to_string(), Some(g.name.clone()));
                        }
                        ui.vertical(|ui| {
                            ui.label(bold(&g.name, 13.0));
                            muted_label(ui, &format!("{} playing now", g.playing));
                        });
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ghost_button(ui, "Servers").clicked() {
                                self.place_input = g.place_id.to_string();
                                self.page = Page::Servers;
                                self.load_servers(ctx);
                            }
                        });
                    });
                }
            });
        }

        if self.search_pending == 0
            && self.search_error.is_none()
            && self.search_users.is_empty()
            && self.search_games.is_empty()
        {
            panel(ui, |ui| {
                muted_label(ui, "Nothing turned up. Try a shorter or more exact name.");
            });
        }
    }

    fn page_servers(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        panel(ui, |ui| {
            heading(ui, "Server browser");
            ui.horizontal(|ui| {
                ui.add(
                    egui::TextEdit::singleline(&mut self.place_input)
                        .hint_text("Game (place) ID")
                        .desired_width(240.0),
                );
                if primary_button(
                    ui,
                    if self.loading {
                        "Loading…"
                    } else {
                        "Load servers"
                    },
                )
                .clicked()
                    && !self.loading
                {
                    self.load_servers(ctx);
                }
            });
            muted_label(
                ui,
                "Public servers only. Joining opens the real Roblox client.",
            );
            if let Some(e) = &self.server_error {
                ui.label(RichText::new(e).color(bad()));
            }
        });
        if self.servers.is_empty() {
            return;
        }
        ui.add_space(6.0);
        panel(ui, |ui| {
            ui.horizontal(|ui| {
                for s in Sort::ALL {
                    if chip(ui, s.label(), self.sort == s) {
                        self.sort = s;
                    }
                }
                ui.add_space(12.0);
                switch(ui, &mut self.hide_full);
                ui.label("Hide full");
                ui.add_space(12.0);
                switch(ui, &mut self.low_ping);
                ui.label("Low ping only");
            });
            let place = self.place_input.trim().to_string();
            ui.horizontal(|ui| {
                // One-click: drop into the best live server (low ping + room).
                if let Some(best) = servers::best_overall(&self.servers).cloned() {
                    if primary_button(ui, "Smart join").clicked() {
                        self.join_server(&place, Some(&best.id));
                    }
                }
                if let Some(best) = servers::best_ping(&self.servers).cloned() {
                    if ghost_button(ui, "Best ping").clicked() {
                        self.join_server(&place, Some(&best.id));
                    }
                }
                if let Some(e) = servers::emptiest(&self.servers).cloned() {
                    if ghost_button(ui, "Emptiest").clicked() {
                        self.join_server(&place, Some(&e.id));
                    }
                }
            });
            let shown =
                servers::visible_filtered(&self.servers, self.sort, self.hide_full, self.low_ping);
            egui::ScrollArea::vertical()
                .max_height(420.0)
                .show(ui, |ui| {
                    for s in shown {
                        ui.horizontal(|ui| {
                            ui.label(bold(&s.id[..8.min(s.id.len())], 13.0));
                            ui.label(
                                RichText::new(format!("{} / {} players", s.players, s.max_players))
                                    .color(muted()),
                            );
                            if let Some(p) = s.ping {
                                let c = if p < 60 {
                                    good()
                                } else if p < 100 {
                                    warn()
                                } else {
                                    bad()
                                };
                                ui.label(RichText::new(format!("{p} ms")).color(c));
                            }
                            ui.with_layout(
                                egui::Layout::right_to_left(egui::Align::Center),
                                |ui| {
                                    if primary_button(ui, "Join").clicked() {
                                        self.join_server(&place, Some(&s.id));
                                    }
                                },
                            );
                        });
                    }
                });
        });
    }

    fn page_settings(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        panel(ui, |ui| {
            heading(ui, "Overlay");
            muted_label(ui, &format!("{} opens a small wheel over any window, including Roblox, with the FPS cap and a Settings shortcut. You can also open it from the tray icon.", hotkey::TRIGGER_LABEL));
            ui.add_space(4.0);
            let mut enabled = self.overlay_enabled;
            if ui
                .checkbox(
                    &mut enabled,
                    format!("Enable the {} overlay", hotkey::TRIGGER_LABEL),
                )
                .changed()
            {
                self.overlay_enabled = enabled;
                save_overlay_enabled(enabled);
                if !enabled {
                    self.overlay_open = false;
                }
            }
            ui.add_space(4.0);
            ui.horizontal(|ui| {
                if ghost_button(ui, "Test overlay").clicked() && self.overlay_enabled {
                    // Skips the "is Roblox focused?" check, to tell apart "the key
                    // isn't being seen" from "the window isn't showing up".
                    self.overlay_open = true;
                    self.fps_page = false;
                    self.flags_page = false;
                    self.overlay_centered = false;
                    self.overlay_shaped = false;
                    sys::debug_log("overlay opened by Test button");
                }
                if ghost_button(ui, "Open overlay log").clicked() {
                    let _ = sys::open_link(&sys::data_dir().join("overlay.log").to_string_lossy());
                }
            });
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Presets");
            ui.horizontal(|ui| {
                for (name, ids) in flags::presets() {
                    if ghost_button(ui, name).clicked() {
                        for (_, on) in self.enabled.iter_mut() {
                            *on = false;
                        }
                        for id in ids {
                            if let Some(on) = self.enabled.get_mut(id) {
                                *on = true;
                            }
                        }
                    }
                }
            });
            ui.add_space(8.0);
            heading(ui, "Lighting presets");
            muted_label(ui, "Experimental — can freeze some systems on a white screen. If so, hit \"Lighting off\" and Apply.");
            ui.horizontal(|ui| {
                for (name, ids) in flags::lighting_presets() {
                    if ghost_button(ui, name).clicked() {
                        // Only touch the lighting toggles, leaving performance ones alone.
                        for id in LIGHTING_IDS {
                            if let Some(on) = self.enabled.get_mut(id) {
                                *on = false;
                            }
                        }
                        for id in ids {
                            if let Some(on) = self.enabled.get_mut(id) {
                                *on = true;
                            }
                        }
                    }
                }
            });
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Graphics");
            let catalog = self.catalog.clone();
            for s in &catalog {
                ui.horizontal(|ui| {
                    let on = self.enabled.get_mut(s.id).unwrap();
                    switch(ui, on);
                    ui.vertical(|ui| {
                        ui.label(bold(s.label, 13.0));
                        muted_label(ui, s.description);
                        let unlisted = s.flags.iter().any(|(n, _)| !self.allow.contains(n));
                        let community = s.flags.iter().any(|(n, _)| self.allow.source(n) == Some(Source::Community));
                        if s.risky {
                            ui.label(
                                RichText::new("Experimental flag: Roblox may ignore it, and on some systems it freezes the game on a white screen at launch. If that happens, come back here, turn it off, and hit Apply with Roblox closed.")
                                    .size(11.5)
                                    .color(warn()),
                            );
                        } else if unlisted {
                            ui.label(RichText::new("Roblox currently ignores part of this setting.").size(11.5).color(warn()));
                        } else if community {
                            ui.label(RichText::new("Community-reported: may stop working after a Roblox update.").size(11.5).color(warn()));
                        }
                    });
                });
            }
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Custom flags");
            muted_label(ui, "One per line, e.g.  FFlagName=True  or  FIntName=0. Roblox ignores any flag it doesn't allow (no ban). These are written when you hit Apply.");
            ui.add_space(4.0);
            let edit = ui.add(
                egui::TextEdit::multiline(&mut self.custom_flags)
                    .hint_text("FFlagExample=True\nFIntExample=0")
                    .desired_width(f32::INFINITY)
                    .desired_rows(4)
                    .font(egui::TextStyle::Monospace),
            );
            if edit.changed() {
                store::save_custom_flags(&self.custom_flags);
            }
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Mods (custom sky & textures)");
            muted_label(ui, "Drop files into the Mods folder mirroring Roblox's content folder (e.g. content\\sky\\...), then Apply. This modifies Roblox's files — low risk, but it's against Roblox's rules, so it's opt-in.");
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                if ghost_button(ui, "Open Mods folder").clicked() {
                    let _ = sys::open_link(&mods::mods_dir().to_string_lossy());
                }
                if primary_button(ui, "Apply mods").clicked() {
                    self.apply_mods();
                }
                if ghost_button(ui, "Remove mods").clicked() {
                    self.remove_mods();
                }
            });
            ui.add_space(4.0);
            let mut lock = self.theme_lock;
            if ui
                .checkbox(&mut lock, "Lock theme — restore it if changed, keep it read-only")
                .changed()
            {
                self.theme_lock = lock;
                store::save_theme_lock(lock);
                if let Some(roblox) = self.roblox.clone() {
                    let versions = paths::all_player_version_dirs(&roblox);
                    if lock {
                        mods::heal(&versions);
                        mods::set_locked(&versions, true);
                        self.status = "Theme locked — branding will be restored if changed.".into();
                    } else {
                        mods::set_locked(&versions, false);
                        self.status = "Theme unlocked.".into();
                    }
                }
            }
            muted_label(ui, "A deterrent, not unbreakable: it keeps the theme in place while Ozara is running. Someone who closes Ozara can still edit the files.");
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Texture cache downscale");
            muted_label(ui, "Caps cached game textures at a chosen resolution to save VRAM and lift frames. It rewrites local PNG/JPEG cache files only — no injection — and applies on the next load or rejoin, not to textures already on screen. WebP/KTX textures are left alone. Undo anytime by clearing Roblox's cache.");
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                muted_label(ui, "Cap textures at");
                let mut chosen = self.tex_cap;
                for cap in [0u32, 128, 256, 512, 1024] {
                    let label = if cap == 0 {
                        "Original".to_string()
                    } else {
                        format!("{cap}px")
                    };
                    if chip(ui, &label, self.tex_cap == cap) {
                        chosen = cap;
                    }
                }
                if chosen != self.tex_cap {
                    self.tex_cap = chosen;
                    store::save_tex(self.tex_cap, self.tex_auto);
                }
            });
            ui.add_space(2.0);
            let mut auto = self.tex_auto;
            if ui
                .checkbox(&mut auto, "Auto: keep the cache capped while Roblox runs")
                .changed()
            {
                self.tex_auto = auto;
                store::save_tex(self.tex_cap, self.tex_auto);
            }
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                if ghost_button(ui, "Scan cache").clicked() {
                    self.scan_cache();
                }
                let label = if self.tex_running {
                    "Working…"
                } else {
                    "Downscale now"
                };
                if primary_button(ui, label).clicked() {
                    self.downscale_cache(ctx);
                }
            });
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Standby (faster launches)");
            muted_label(ui, "Keeps Roblox's client files warm in the OS cache while Ozara sits in the tray, so a cold launch doesn't wait on disk. It only reads files into memory — no process is started and nothing is changed.");
            ui.add_space(4.0);
            let mut on = self.standby == Some(true);
            if ui
                .checkbox(&mut on, "Keep Roblox on standby for faster launches")
                .changed()
            {
                self.standby = Some(on);
                store::save_standby(on);
                if on {
                    self.standby_warmed = true;
                    self.prewarm_standby();
                }
            }
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "FPS cap");
            ui.horizontal(|ui| {
                for cap in fps::CAP_OPTIONS {
                    if chip(ui, &fps::cap_label(cap), self.fps_cap == cap) {
                        self.fps_cap = cap;
                    }
                }
            });
            muted_label(ui, "Roblox only officially supports up to 240. Higher values may be reset by a Roblox update.");
            if self.fps_cap > 240 || self.fps_cap == fps::UNCAPPED {
                ui.label(
                    RichText::new("Unsupported value: on some systems this freezes Roblox on a white screen at launch.")
                        .size(11.5)
                        .color(warn()),
                );
            }
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                if primary_button(ui, "Apply").clicked() {
                    self.apply(ctx, false);
                }
                if ghost_button(ui, "Apply and rejoin").clicked() {
                    self.apply(ctx, true);
                }
                if ghost_button(ui, "Restore original FPS settings").clicked() {
                    self.restore_fps_backup();
                }
            });
            muted_label(ui, "\"Restore\" undoes every FPS change Ozara has made, back to how Roblox had it before Ozara touched it — use it if Roblox ever freezes white on launch.");
        });
    }

    fn page_stats(&mut self, ui: &mut egui::Ui) {
        let now = sys::now_unix();
        let today_start = now - now.rem_euclid(86_400);
        let sessions = self.tracker.sessions.clone();
        panel(ui, |ui| {
            heading(ui, "Playtime");
            ui.horizontal(|ui| {
                ui.label(format!(
                    "Today: {}",
                    playtime::format_duration(playtime::seconds_between(
                        &sessions,
                        today_start,
                        now + 1
                    ))
                ));
                ui.label(format!(
                    "This week: {}",
                    playtime::format_duration(self.week_seconds())
                ));
                ui.label(format!(
                    "All time: {}",
                    playtime::format_duration(playtime::seconds_between(&sessions, 0, now + 1))
                ));
            });
            let days = playtime::daily_seconds(&sessions, today_start - 6 * 86_400, 7);
            let max = days.iter().copied().max().unwrap_or(1).max(1) as f32;
            ui.add_space(8.0);
            ui.horizontal_top(|ui| {
                for secs in &days {
                    ui.vertical(|ui| {
                        let h = 140.0 * (*secs as f32 / max);
                        let (rect, _) =
                            ui.allocate_exact_size(egui::vec2(48.0, 140.0), egui::Sense::hover());
                        let bar = egui::Rect::from_min_max(
                            egui::pos2(rect.left(), rect.bottom() - h),
                            rect.right_bottom(),
                        );
                        ui.painter()
                            .rect_filled(bar, egui::Rounding::same(8.0), cyan());
                        muted_label(ui, &playtime::format_duration(*secs));
                    });
                }
            });
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Most played");
            for (place, secs) in playtime::per_game(&sessions).into_iter().take(5) {
                let name = self
                    .game_names
                    .get(&place)
                    .cloned()
                    .unwrap_or_else(|| format!("Game {place}"));
                ui.label(format!("{name}   {}", playtime::format_duration(secs)));
            }
            muted_label(
                ui,
                "Playtime is read from Roblox's own log files and stays on this PC.",
            );
        });
    }

    fn page_updates(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        panel(ui, |ui| {
            heading(ui, "Ozara");
            ui.label(format!("You have Ozara {VERSION}."));
            if !ozara_core::release::UPDATES_ENABLED {
                muted_label(ui, "Online updates aren't set up yet — Ozara won't contact the internet to update.");
                return;
            }
            let newer = self
                .update_latest
                .as_ref()
                .map(|l| ozara_core::version::is_newer(VERSION, l))
                .unwrap_or(false);
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                if self.update_busy {
                    ui.add(egui::Spinner::new());
                    ui.label("Working…");
                } else {
                    if primary_button(ui, "Check for updates").clicked() {
                        self.check_for_update(ctx);
                    }
                    if newer && ghost_button(ui, "Download & install").clicked() {
                        self.download_update(ctx);
                    }
                }
            });
            if !self.update_status.is_empty() {
                ui.add_space(4.0);
                ui.label(RichText::new(&self.update_status).color(if newer { warn() } else { muted() }));
            }
            muted_label(ui, "Updates are downloaded from Ozara's GitHub releases.");
        });
        ui.add_space(6.0);
        panel(ui, |ui| {
            heading(ui, "Roblox");
            match &self.roblox {
                Some(r) => match paths::find_player_version_dir(r) {
                    Some(v) => ui.label(format!(
                        "Roblox installed: {}",
                        v.file_name().unwrap_or_default().to_string_lossy()
                    )),
                    None => ui.label("Roblox folder found, but no player installed."),
                },
                None => ui.label("Roblox was not found on this PC."),
            };
        });
    }

    fn page_favorites(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        panel(ui, |ui| {
            heading(ui, "Favorites");
            if self.favourites.is_empty() {
                muted_label(ui, "No favourites yet. Open a game and tap ☆ Favourite to save it here.");
                return;
            }
            let favs = self.favourites.clone();
            let mut open: Option<(String, String)> = None;
            let mut remove: Option<String> = None;
            egui::ScrollArea::vertical().max_height(460.0).show(ui, |ui| {
                for f in &favs {
                    ui.horizontal(|ui| {
                        let pid: u64 = f.place_id.parse().unwrap_or(0);
                        if Self::game_tile(ui, &f.name, pid, self.game_icons.get(pid)).clicked() {
                            open = Some((f.place_id.clone(), f.name.clone()));
                        }
                        ui.vertical(|ui| {
                            ui.label(bold(&f.name, 13.0));
                            ui.horizontal(|ui| {
                                if ghost_button(ui, "Play").clicked() {
                                    self.join_server(&f.place_id, None);
                                }
                                if ghost_button(ui, "Remove").clicked() {
                                    remove = Some(f.place_id.clone());
                                }
                            });
                        });
                    });
                    ui.add_space(4.0);
                }
            });
            if let Some((place, name)) = open {
                self.open_game(ctx, place, Some(name));
            }
            if let Some(place) = remove {
                store::toggle_favourite(&mut self.favourites, &place, "");
            }
        });
    }

    fn page_notes(&mut self, ui: &mut egui::Ui) {
        panel(ui, |ui| {
            heading(ui, "Notes");
            muted_label(ui, "Jot down server IDs, builds, or anything worth keeping.");
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                let edit = ui.add(
                    egui::TextEdit::singleline(&mut self.note_input)
                        .hint_text("Write a note…")
                        .desired_width(360.0),
                );
                let enter = edit.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
                if primary_button(ui, "Add").clicked() || enter {
                    let text = self.note_input.trim().to_string();
                    if !text.is_empty() {
                        store::add_note(&mut self.notes, &text);
                        self.note_input.clear();
                    }
                }
            });
        });
        ui.add_space(6.0);
        if self.notes.is_empty() {
            return;
        }
        let notes = self.notes.clone();
        let mut remove: Option<usize> = None;
        panel(ui, |ui| {
            for (i, note) in notes.iter().enumerate() {
                ui.horizontal(|ui| {
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ghost_button(ui, "Delete").clicked() {
                            remove = Some(i);
                        }
                        ui.with_layout(egui::Layout::left_to_right(egui::Align::Center), |ui| {
                            ui.label(RichText::new(&note.text).size(13.0));
                        });
                    });
                });
                ui.separator();
            }
        });
        if let Some(i) = remove {
            store::remove_note(&mut self.notes, i);
        }
    }

    fn page_soon(ui: &mut egui::Ui, title: &str, text: &str) {
        panel(ui, |ui| {
            heading(ui, title);
            muted_label(ui, text);
        });
    }

    /// The Ctrl+; wheel: a small always-on-top window, separate from the main
    /// one, so it can appear over Roblox too. It only shows the FPS cap Ozara
    /// is configured to apply and a shortcut into Settings — Ozara has no way
    /// to read the game's actual live frame rate without hooking into the
    /// Roblox process, which is exactly what this project avoids doing.
    fn overlay(&mut self, ctx: &egui::Context) {
        if !self.overlay_open || !self.overlay_enabled {
            return;
        }
        let viewport_id = egui::ViewportId::from_hash_of("ozara_overlay");
        let close = std::cell::Cell::new(false);
        let fps_label = fps::cap_label(self.fps_cap);
        let fps_page = self.fps_page;
        let flags_page = self.flags_page;
        let current_cap = self.fps_cap;
        let in_game = self.tracker.current.is_some();
        let open_fps = std::cell::Cell::new(false); // main → FPS picker
        let open_flags = std::cell::Cell::new(false); // main → flags page
        let back_to_main = std::cell::Cell::new(false); // sub-page → main
        let picked_cap = std::cell::Cell::new(None::<i32>); // a value chosen in the picker
        // A graphics-setting id the user toggled on the flags page, if any.
        let toggled: std::cell::Cell<Option<&'static str>> = std::cell::Cell::new(None);
        // The catalog, snapshotted so the closure can read labels + on/off state.
        let catalog: Vec<(&'static str, &'static str, bool)> = self
            .catalog
            .iter()
            .map(|s| (s.id, s.label, *self.enabled.get(s.id).unwrap_or(&false)))
            .collect();
        let do_apply = std::cell::Cell::new(false);
        let do_restart = std::cell::Cell::new(false);
        let do_newserver = std::cell::Cell::new(false);
        let size = egui::vec2(320.0, 320.0);
        let needs_center = !self.overlay_centered;
        let centered = std::cell::Cell::new(false);
        let overlay_shaped = self.overlay_shaped;
        let shaped = std::cell::Cell::new(false);
        ctx.show_viewport_immediate(
            viewport_id,
            egui::ViewportBuilder::default()
                .with_title("Ozara Overlay")
                .with_decorations(false)
                .with_transparent(true)
                .with_always_on_top()
                .with_taskbar(false)
                .with_visible(true)
                .with_active(true)
                .with_inner_size(size),
            |octx, _class| {
                // Send the window-setup commands only on the first frame of this
                // opening. Re-sending Focus/WindowLevel every frame was resetting the
                // input state before clicks could land — which is why the buttons
                // didn't respond. Once is enough to show it on top and centred.
                if needs_center {
                    octx.send_viewport_cmd(egui::ViewportCommand::WindowLevel(
                        egui::viewport::WindowLevel::AlwaysOnTop,
                    ));
                    octx.send_viewport_cmd(egui::ViewportCommand::Decorations(false));
                    octx.send_viewport_cmd(egui::ViewportCommand::Focus);
                    if let Some(monitor) = octx.input(|i| i.viewport().monitor_size) {
                        let pos = ((monitor - size) / 2.0).to_pos2();
                        octx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(pos));
                        centered.set(true);
                    }
                }
                // Strip the OS title bar and clip the window to a circle — both
                // through Windows, because the framework's own "no decorations" and
                // transparency don't take on every system. Do it ONCE (re-clipping
                // every frame flashes the square corners = flicker); Windows keeps
                // the shape for every later repaint.
                if !overlay_shaped {
                    crate::sys::make_borderless("Ozara Overlay");
                    if crate::sys::make_circular("Ozara Overlay") {
                        shaped.set(true);
                    }
                }
                if octx.input(|i| i.viewport().close_requested())
                    || octx.input(|i| i.key_pressed(egui::Key::Escape))
                {
                    close.set(true);
                }
                egui::CentralPanel::default()
                    .frame(egui::Frame::none())
                    .show(octx, |ui| {
                        let center = ui.max_rect().center();
                        let painter = ui.painter();
                        // Fill the whole window with the circle so it meets the Windows
                        // circular clip with no dark ring left over.
                        let radius = ui.max_rect().width().min(ui.max_rect().height()) / 2.0;
                        painter.circle_filled(
                            center,
                            radius,
                            Color32::from_rgba_unmultiplied(16, 12, 28, 255),
                        );
                        painter.circle_stroke(
                            center,
                            radius - 2.0,
                            egui::Stroke::new(2.0_f32, violet()),
                        );

                        // Draws an infinity mark (sideways 8) for the "uncapped" option,
                        // since the ∞ glyph isn't in the font.
                        let draw_infinity = |ui: &egui::Ui, at: egui::Pos2| {
                            let s = egui::Stroke::new(2.0_f32, Color32::WHITE);
                            let r = 5.0;
                            ui.painter().circle_stroke(at + egui::vec2(-r, 0.0), r, s);
                            ui.painter().circle_stroke(at + egui::vec2(r, 0.0), r, s);
                        };

                        if fps_page {
                            // ---- FPS picker: all options around a ring, Ozara logo
                            //      in the middle as the back button. ----
                            let opts = fps::CAP_OPTIONS;
                            let n = opts.len() as f32;
                            for (i, cap) in opts.iter().enumerate() {
                                let ang = (-90.0 + i as f32 * 360.0 / n).to_radians();
                                let pos = center + egui::vec2(ang.cos(), ang.sin()) * 104.0;
                                let rect = egui::Rect::from_center_size(pos, egui::vec2(66.0, 42.0));
                                let selected = *cap == current_cap;
                                let fill = if selected {
                                    violet()
                                } else {
                                    Color32::from_rgba_unmultiplied(40, 30, 66, 240)
                                };
                                let label = if *cap == fps::UNCAPPED {
                                    String::new() // drawn as ∞ below
                                } else {
                                    fps::cap_label(*cap)
                                };
                                let clicked = ui
                                    .put(
                                        rect,
                                        egui::Button::new(bold(label, 13.0))
                                            .rounding(21.0)
                                            .fill(fill)
                                            .wrap_mode(egui::TextWrapMode::Extend),
                                    )
                                    .clicked();
                                if *cap == fps::UNCAPPED {
                                    draw_infinity(ui, rect.center());
                                }
                                if clicked {
                                    picked_cap.set(Some(*cap));
                                }
                            }
                            // Centre: Ozara logo = back to the main wheel.
                            let back = ui.interact(
                                egui::Rect::from_center_size(center, egui::vec2(64.0, 64.0)),
                                egui::Id::new("ozara_fps_back"),
                                egui::Sense::click(),
                            );
                            let bfill = if back.hovered() {
                                violet()
                            } else {
                                Color32::from_rgba_unmultiplied(40, 30, 66, 240)
                            };
                            ui.painter().circle_filled(center, 32.0, bfill);
                            ui.painter().circle_stroke(center, 32.0, egui::Stroke::new(2.0_f32, violet()));
                            egui::Image::new(assets::mark()).paint_at(
                                ui,
                                egui::Rect::from_center_size(center, egui::vec2(34.0, 34.0)),
                            );
                            if back.clicked() {
                                back_to_main.set(true);
                            }
                            return;
                        }

                        if flags_page {
                            // ---- Graphics / FastFlag toggles around a ring. ----
                            let n = catalog.len().max(1) as f32;
                            for (i, (id, _label, on)) in catalog.iter().enumerate() {
                                let ang = (-90.0 + i as f32 * 360.0 / n).to_radians();
                                let pos = center + egui::vec2(ang.cos(), ang.sin()) * 108.0;
                                let rect = egui::Rect::from_center_size(pos, egui::vec2(72.0, 40.0));
                                let fill = if *on {
                                    violet()
                                } else {
                                    Color32::from_rgba_unmultiplied(40, 30, 66, 240)
                                };
                                let btn = egui::Button::new(bold(short_flag_label(id), 11.0))
                                    .rounding(14.0)
                                    .fill(fill)
                                    .wrap_mode(egui::TextWrapMode::Truncate);
                                if ui.put(rect, btn).on_hover_text(*_label).clicked() {
                                    toggled.set(Some(id));
                                }
                            }
                            // Centre: Ozara logo = back.
                            let back = ui.interact(
                                egui::Rect::from_center_size(center, egui::vec2(64.0, 64.0)),
                                egui::Id::new("ozara_flags_back"),
                                egui::Sense::click(),
                            );
                            let bfill = if back.hovered() {
                                violet()
                            } else {
                                Color32::from_rgba_unmultiplied(40, 30, 66, 240)
                            };
                            ui.painter().circle_filled(center, 32.0, bfill);
                            ui.painter().circle_stroke(center, 32.0, egui::Stroke::new(2.0_f32, violet()));
                            egui::Image::new(assets::mark()).paint_at(
                                ui,
                                egui::Rect::from_center_size(center, egui::vec2(34.0, 34.0)),
                            );
                            ui.painter().text(
                                center + egui::vec2(0.0, 44.0),
                                egui::Align2::CENTER_CENTER,
                                "back · then Apply",
                                FontId::new(9.5, FontFamily::Proportional),
                                muted(),
                            );
                            if back.clicked() {
                                back_to_main.set(true);
                            }
                            return;
                        }

                        // ---- Main wheel: options around a ring, close X in the middle ----
                        let items: [(&str, &std::cell::Cell<bool>); 5] = [
                            ("FPS cap", &open_fps),
                            (if in_game { "Apply & restart" } else { "Apply" }, &do_apply),
                            ("Soft restart", &do_restart),
                            ("New server", &do_newserver),
                            ("Flags", &open_flags),
                        ];
                        let n = items.len() as f32;
                        for (i, (label, flag)) in items.iter().enumerate() {
                            let ang = (-90.0 + i as f32 * 360.0 / n).to_radians();
                            let pos = center + egui::vec2(ang.cos(), ang.sin()) * 100.0;
                            let rect = egui::Rect::from_center_size(pos, egui::vec2(114.0, 42.0));
                            if ui
                                .put(
                                    rect,
                                    egui::Button::new(bold(*label, 12.0))
                                        .rounding(21.0)
                                        .wrap_mode(egui::TextWrapMode::Extend),
                                )
                                .clicked()
                            {
                                flag.set(true);
                            }
                        }
                        // Centre: close (X drawn by hand).
                        let cresp = ui.interact(
                            egui::Rect::from_center_size(center, egui::vec2(56.0, 56.0)),
                            egui::Id::new("ozara_wheel_close"),
                            egui::Sense::click(),
                        );
                        let cfill = if cresp.hovered() {
                            violet()
                        } else {
                            Color32::from_rgba_unmultiplied(40, 30, 66, 240)
                        };
                        ui.painter().circle_filled(center, 28.0, cfill);
                        ui.painter().circle_stroke(center, 28.0, egui::Stroke::new(2.0_f32, violet()));
                        let d = 7.0;
                        let x_stroke = egui::Stroke::new(2.5_f32, Color32::WHITE);
                        ui.painter().line_segment(
                            [center + egui::vec2(-d, -d), center + egui::vec2(d, d)],
                            x_stroke,
                        );
                        ui.painter().line_segment(
                            [center + egui::vec2(-d, d), center + egui::vec2(d, -d)],
                            x_stroke,
                        );
                        if cresp.clicked() {
                            close.set(true);
                        }
                        let _ = fps_label;
                    });
            },
        );
        if centered.get() {
            self.overlay_centered = true;
        }
        if shaped.get() {
            self.overlay_shaped = true;
        }
        if open_fps.get() {
            self.fps_page = true;
        }
        if open_flags.get() {
            self.flags_page = true;
        }
        if back_to_main.get() {
            self.fps_page = false;
            self.flags_page = false;
        }
        if let Some(id) = toggled.get() {
            if let Some(on) = self.enabled.get_mut(id) {
                *on = !*on;
            }
        }
        if let Some(cap) = picked_cap.get() {
            self.fps_cap = cap;
            self.fps_page = false; // back to the main wheel after choosing
        }
        if do_apply.get() {
            // If Roblox is open, applying means restarting it so the cap takes effect.
            self.apply(ctx, sys::roblox_running());
        }
        if do_restart.get() {
            self.soft_restart(ctx);
        }
        if do_newserver.get() {
            self.join_new_server(ctx);
        }
        if close.get() {
            self.overlay_open = false;
            self.fps_page = false;
            self.flags_page = false;
        }
    }

    /// A small always-on-top button that floats in the bottom-right corner while
    /// Roblox is open. Clicking it opens the wheel. It's its own tiny overlay
    /// window — it reads nothing from Roblox, and it never takes keyboard focus
    /// from the game (so it won't interrupt your movement).
    fn corner_button(&mut self, ctx: &egui::Context) {
        // Round Ozara logo in the bottom-right — the menu button. Shows whenever
        // Roblox is open and is the window you're looking at. A short grace period
        // smooths over the one-frame focus flicker when the wheel opens/closes, so
        // the badge doesn't rapidly destroy and recreate itself (which made it jump
        // around the screen).
        if sys::roblox_focused() {
            self.roblox_focus_seen = Some(Instant::now());
        }
        let focused_recently = self
            .roblox_focus_seen
            .map_or(false, |t| t.elapsed() < Duration::from_millis(900));
        let show =
            self.overlay_enabled && self.roblox_running && focused_recently && !self.overlay_open;
        if show != self.corner_last_show {
            self.corner_last_show = show;
            sys::debug_log(&format!(
                "logo show={show} (enabled={}, running={}, focused_recently={})",
                self.overlay_enabled, self.roblox_running, focused_recently
            ));
        }
        if !show {
            self.corner_placed = false;
            self.badge_shaped = false;
            badge::set_shown(false);
            return;
        }
        badge::set_shown(true);
        let viewport_id = egui::ViewportId::from_hash_of("ozara_corner");
        let size = egui::vec2(64.0, 64.0);
        let needs_place = !self.corner_placed;
        let badge_shaped = self.badge_shaped;
        let badge_shaped_now = std::cell::Cell::new(false);
        let placed = std::cell::Cell::new(false);
        let clicked = std::cell::Cell::new(false);
        ctx.show_viewport_immediate(
            viewport_id,
            egui::ViewportBuilder::default()
                .with_title("Ozara Badge")
                .with_decorations(false)
                .with_transparent(true)
                .with_always_on_top()
                .with_taskbar(false)
                .with_visible(true)
                .with_active(false) // never steal focus from the game
                .with_inner_size(size),
            |octx, _class| {
                if !badge_shaped {
                    crate::sys::make_borderless("Ozara Badge");
                    if crate::sys::make_circular("Ozara Badge") {
                        badge_shaped_now.set(true);
                    }
                }
                // Setup commands once, not every frame (per-frame spam was eating clicks).
                if needs_place {
                    octx.send_viewport_cmd(egui::ViewportCommand::WindowLevel(
                        egui::viewport::WindowLevel::AlwaysOnTop,
                    ));
                    octx.send_viewport_cmd(egui::ViewportCommand::Decorations(false));
                    if let Some(monitor) = octx.input(|i| i.viewport().monitor_size) {
                        // Bottom-right, a little in from the edges.
                        let pos = egui::pos2(monitor.x - size.x - 28.0, monitor.y - size.y - 70.0);
                        octx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(pos));
                        // Publish the screen rect in PHYSICAL pixels, so the mouse
                        // watcher (which reads the cursor in physical pixels) matches
                        // even when Windows display scaling isn't 100%.
                        let ppp = octx.pixels_per_point();
                        badge::set_rect(
                            (pos.x * ppp) as i32,
                            (pos.y * ppp) as i32,
                            (size.x * ppp) as i32,
                            (size.y * ppp) as i32,
                        );
                        placed.set(true);
                    }
                }
                egui::CentralPanel::default().frame(egui::Frame::none()).show(octx, |ui| {
                    let center = ui.max_rect().center();
                    // Make the WHOLE window clickable (not just the inner circle), so a
                    // click anywhere on the badge opens the wheel.
                    let resp = ui.interact(
                        ui.max_rect(),
                        egui::Id::new("ozara_corner_btn"),
                        egui::Sense::click(),
                    );
                    let fill = if resp.hovered() {
                        violet()
                    } else {
                        Color32::from_rgba_unmultiplied(22, 16, 38, 240)
                    };
                    // Just the Ozara mark in a circle — the escape-menu branding.
                    ui.painter().circle_filled(center, 30.0, fill);
                    ui.painter().circle_stroke(center, 30.0, egui::Stroke::new(2.0_f32, violet()));
                    let logo = egui::Rect::from_center_size(center, egui::vec2(34.0, 34.0));
                    egui::Image::new(assets::mark()).paint_at(ui, logo);
                    if resp.clicked() {
                        clicked.set(true);
                    }
                });
            },
        );
        if placed.get() {
            self.corner_placed = true;
        }
        if badge_shaped_now.get() {
            self.badge_shaped = true;
        }
        if clicked.get() {
            self.overlay_open = true;
            self.fps_page = false;
            self.flags_page = false;
            self.overlay_centered = false;
            self.overlay_shaped = false;
            sys::debug_log("overlay opened by corner logo");
        }
    }
}

impl eframe::App for OzaraApp {
    /// Clear to fully transparent. The main window paints its own opaque
    /// gradient backdrop over its whole area, so it still looks solid; the
    /// overlay window paints only the wheel, so its corners show through as
    /// transparent instead of a black square.
    fn clear_color(&self, _visuals: &egui::Visuals) -> [f32; 4] {
        [0.0, 0.0, 0.0, 0.0]
    }

    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.poll(ctx);
        if self.tray.is_none() && !self.tray_tried {
            self.tray_tried = true;
            self.tray = tray::start(self.tx.clone(), ctx);
        }
        if !self.hotkey_tried {
            self.hotkey_tried = true;
            hotkey::start(self.tx.clone(), ctx.clone());
        }
        // Closing behaviour:
        //  - While Roblox is running, Ozara is needed for the overlay, so the close
        //    button can't quit it — it just tucks off-screen (kept alive; a hidden
        //    window would freeze the overlay loop).
        //  - In standby (no Roblox), the close button quits Ozara like a normal app.
        if self.tray.is_some() && !tray::quitting() && ctx.input(|i| i.viewport().close_requested())
        {
            if self.roblox_running {
                ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
                ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(OFFSCREEN));
                sys::set_taskbar_visible("Ozara", false);
            } else {
                // Let the close go through → Ozara exits. The tray thread is a
                // background thread, so the process ends when the window closes.
                std::process::exit(0);
            }
        }
        // While the overlay is up, repaint fast so it keeps re-asserting itself on
        // top of whatever game stole focus back; otherwise once a second is plenty.
        if self.overlay_open {
            // Immediate, not timed: keep the loop running at full speed so the
            // separate overlay window keeps drawing and re-asserting itself on top
            // even while Ozara's main window is hidden in the tray.
            ctx.request_repaint();
        } else if self.overlay_enabled && self.roblox_running {
            // Corner button is visible: a steady modest tick keeps its hover and
            // click responsive without spinning the CPU.
            ctx.request_repaint_after(Duration::from_millis(200));
        } else {
            ctx.request_repaint_after(Duration::from_secs(1));
        }
        theme::paint_backdrop(ctx);
        self.overlay(ctx);
        self.corner_button(ctx);

        egui::SidePanel::left("nav")
            .exact_width(92.0)
            .resizable(false)
            .frame(
                egui::Frame::none()
                    .fill(Color32::from_rgba_unmultiplied(12, 9, 22, 150))
                    .inner_margin(egui::Margin::same(12.0)),
            )
            .show(ctx, |ui| {
                ui.vertical_centered(|ui| {
                    ui.add_space(6.0);
                    ui.add(
                        egui::Image::new(assets::mark()).fit_to_exact_size(egui::vec2(40.0, 40.0)),
                    );
                    ui.add_space(10.0);
                    for p in Page::ALL {
                        if Self::nav_item(ui, p.icon(), p.label(), self.page == p) {
                            self.page = p;
                        }
                    }
                });
            });

        egui::CentralPanel::default()
            .frame(egui::Frame::none().inner_margin(egui::Margin::symmetric(24.0, 18.0)))
            .show(ctx, |ui| {
                self.top_bar(ui, ctx);
                ui.add_space(8.0);
                egui::ScrollArea::vertical().show(ui, |ui| {
                    match self.page {
                        Page::Home => self.page_home(ui, ctx),
                        Page::Friends => self.page_friends(ui, ctx),
                        Page::Servers => self.page_servers(ui, ctx),
                        Page::Settings => self.page_settings(ui, ctx),
                        Page::Stats => self.page_stats(ui),
                        Page::Updates => self.page_updates(ui, ctx),
                        Page::Favorites => self.page_favorites(ui, ctx),
                        Page::Notes => self.page_notes(ui),
                        Page::Alerts => Self::page_soon(
                            ui,
                            "Game alerts",
                            "Get told when a favourite game updates. Coming soon.",
                        ),
                        Page::Search => self.page_search(ui, ctx),
                        Page::Game => self.page_game(ui, ctx),
                    }
                    if !self.status.is_empty() {
                        ui.add_space(8.0);
                        ui.label(RichText::new(&self.status).color(warn()));
                    }
                });
            });
        self.quick_settings(ctx);
    }
}

/// 1234 -> "1.2K", 3_400_000 -> "3.4M".
/// Short labels for the wheel's flags page (the full labels are too long for the
/// small ring buttons; the full one shows on hover).
fn short_flag_label(id: &str) -> &'static str {
    match id {
        "lod" => "LOD",
        "textures" => "Low tex",
        "msaa_off" => "No AA",
        "no_lights" => "No light",
        "no_grass" => "No grass",
        "gray_sky" => "Gray sky",
        "no_shadows" => "No shadow",
        "voxel_lighting" => "Voxel",
        "no_postfx" => "No FX",
        "force_dx11" => "DX11",
        "lowest_quality" => "Low Q",
        _ => "Flag",
    }
}

/// A short one-time verification code like "OZARA-7F3A9C".
fn verify_code() -> String {
    use rand::Rng;
    const CHARS: &[u8] = b"ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let mut rng = rand::thread_rng();
    let tail: String = (0..6).map(|_| CHARS[rng.gen_range(0..CHARS.len())] as char).collect();
    format!("OZARA-{tail}")
}

fn compact(n: u64) -> String {
    match n {
        0..=999 => n.to_string(),
        1_000..=999_999 => format!("{:.1}K", n as f64 / 1_000.0),
        1_000_000..=999_999_999 => format!("{:.1}M", n as f64 / 1_000_000.0),
        _ => format!("{:.1}B", n as f64 / 1_000_000_000.0),
    }
}

/// Whether the Ctrl+; overlay should respond at all (Settings can turn it off).
/// Stored as a one-byte file next to the other small Ozara settings; missing
/// means "never turned off", so the overlay is on by default.
fn load_overlay_enabled() -> bool {
    std::fs::read_to_string(sys::data_dir().join("overlay_enabled.txt"))
        .map(|s| s.trim() != "0")
        .unwrap_or(true)
}

fn save_overlay_enabled(enabled: bool) {
    let _ = std::fs::write(
        sys::data_dir().join("overlay_enabled.txt"),
        if enabled { "1" } else { "0" },
    );
}
