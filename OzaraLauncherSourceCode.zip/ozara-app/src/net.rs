//! Network calls to Roblox's public web API (no sign-in needed).

use ozara_core::servers::Server;
use rand::RngCore;
use serde::Deserialize;
use std::collections::HashMap;
use std::io::Read;

#[derive(Deserialize)]
struct Page {
    #[serde(default)]
    data: Vec<Item>,
}

#[derive(Deserialize)]
struct Item {
    id: String,
    #[serde(default)]
    playing: u32,
    #[serde(default, rename = "maxPlayers")]
    max_players: u32,
    #[serde(default)]
    ping: Option<u32>,
}

/// Public servers of one place, up to 100 (Roblox's page limit).
pub fn fetch_servers(place_id: &str) -> Result<Vec<Server>, String> {
    if !ozara_core::join::is_numeric_id(place_id) {
        return Err("Place ID must be a number.".into());
    }
    let url = format!(
        "https://games.roblox.com/v1/games/{place_id}/servers/Public?sortOrder=Asc&limit=100"
    );
    let page: Page = ureq::get(&url)
        .call()
        .map_err(|e| match e {
            ureq::Error::Status(429, _) => {
                "Roblox is rate-limiting requests. Wait a minute and refresh.".to_string()
            }
            ureq::Error::Status(code, _) => format!("Roblox answered with error {code}."),
            other => format!("Could not reach Roblox: {other}"),
        })?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;
    Ok(page
        .data
        .into_iter()
        .map(|i| Server {
            id: i.id,
            players: i.playing,
            max_players: i.max_players,
            ping: i.ping,
        })
        .collect())
}

#[derive(Deserialize, Clone, Debug)]
pub struct Friend {
    pub id: u64,
    #[serde(default)]
    pub name: String,
    #[serde(default, rename = "displayName")]
    pub display_name: String,
}

impl Friend {
    pub fn shown_name(&self) -> &str {
        if self.display_name.is_empty() {
            &self.name
        } else {
            &self.display_name
        }
    }
}

#[derive(Deserialize, Default)]
struct FriendsPage {
    #[serde(default)]
    data: Vec<Friend>,
}

/// What we know about someone's friends: either the list itself, or just a count
/// when Roblox won't hand out the list (some accounts have it restricted).
#[derive(Clone, Debug, Default)]
pub struct FriendsInfo {
    pub list: Vec<Friend>,
    pub count: Option<u32>,
    pub list_restricted: bool,
}

#[derive(Deserialize, Default)]
struct CountResp {
    #[serde(default)]
    count: u32,
}

/// A user's friends. Tries the public list first; if Roblox refuses it (403,
/// which happens for some accounts regardless of sign-in), falls back to the
/// public friend-count endpoint so we can still show a number.
pub fn fetch_friends(user_id: &str) -> Result<FriendsInfo, String> {
    if !ozara_core::join::is_numeric_id(user_id) {
        return Err("Bad user ID.".into());
    }
    let url = format!("https://friends.roblox.com/v1/users/{user_id}/friends");
    match ureq::get(&url).call() {
        Ok(resp) => {
            let page: FriendsPage = resp
                .into_json()
                .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;
            Ok(FriendsInfo {
                count: Some(page.data.len() as u32),
                list: page.data,
                list_restricted: false,
            })
        }
        Err(ureq::Error::Status(403, _)) => {
            // Roblox blocks the list itself for some accounts. The count endpoint
            // is sometimes still open, so try it before giving up entirely.
            let count_url = format!("https://friends.roblox.com/v1/users/{user_id}/friends/count");
            let count = ureq::get(&count_url)
                .call()
                .ok()
                .and_then(|r| r.into_json::<CountResp>().ok())
                .map(|c| c.count);
            Ok(FriendsInfo {
                list: Vec::new(),
                count,
                list_restricted: true,
            })
        }
        Err(ureq::Error::Status(429, _)) => {
            Err("Roblox is rate-limiting requests. Try again in a minute.".to_string())
        }
        Err(ureq::Error::Status(code, _)) => Err(format!("Roblox answered with error {code}.")),
        Err(other) => Err(format!("Could not reach Roblox: {other}")),
    }
}

#[derive(Deserialize)]
struct ThumbItem {
    #[serde(rename = "targetId")]
    target_id: u64,
    #[serde(default, rename = "imageUrl")]
    image_url: Option<String>,
    #[serde(default)]
    state: String,
}

#[derive(Deserialize, Default)]
struct ThumbPage {
    #[serde(default)]
    data: Vec<ThumbItem>,
}

/// Public avatar-headshot image URLs for a batch of user IDs (no sign-in needed).
/// IDs Roblox has nothing to show for (moderated, not yet generated) are left out.
pub fn fetch_avatar_urls(user_ids: &[u64]) -> HashMap<u64, String> {
    let mut out = HashMap::new();
    if user_ids.is_empty() {
        return out;
    }
    // Roblox's thumbnail batch endpoint takes up to 100 IDs at a time.
    for chunk in user_ids.chunks(100) {
        let ids: Vec<String> = chunk.iter().map(|id| id.to_string()).collect();
        let url = format!(
            "https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={}&size=150x150&format=Png&isCircular=false",
            ids.join(",")
        );
        if let Ok(resp) = ureq::get(&url).call() {
            if let Ok(page) = resp.into_json::<ThumbPage>() {
                for item in page.data {
                    if item.state == "Completed" {
                        if let Some(url) = item.image_url {
                            out.insert(item.target_id, url);
                        }
                    }
                }
            }
        }
    }
    out
}

/// Public game-icon image URLs for a batch of place IDs (no sign-in needed).
/// Places with no icon yet are left out, so the caller keeps its colored fallback.
pub fn fetch_game_icon_urls(place_ids: &[u64]) -> HashMap<u64, String> {
    let mut out = HashMap::new();
    for chunk in place_ids.chunks(100) {
        let ids: Vec<String> = chunk.iter().map(|id| id.to_string()).collect();
        let url = format!(
            "https://thumbnails.roblox.com/v1/places/gameicons?placeIds={}&size=150x150&format=Png&isCircular=false",
            ids.join(",")
        );
        if let Ok(resp) = ureq::get(&url).call() {
            if let Ok(page) = resp.into_json::<ThumbPage>() {
                for item in page.data {
                    if item.state == "Completed" {
                        if let Some(url) = item.image_url {
                            out.insert(item.target_id, url);
                        }
                    }
                }
            }
        }
    }
    out
}

/// Downloads one avatar image's raw bytes (PNG) from a URL fetch_avatar_urls returned.
pub fn fetch_image_bytes(url: &str) -> Result<Vec<u8>, String> {
    let resp = ureq::get(url)
        .call()
        .map_err(|e| format!("Could not fetch image: {e}"))?;
    let mut buf = Vec::new();
    resp.into_reader()
        .read_to_end(&mut buf)
        .map_err(|e| format!("Could not read image: {e}"))?;
    Ok(buf)
}

#[derive(Deserialize, Clone, Debug)]
pub struct UserHit {
    pub id: u64,
    #[serde(default)]
    pub name: String,
    #[serde(default, rename = "displayName")]
    pub display_name: String,
}

impl UserHit {
    pub fn shown_name(&self) -> &str {
        if self.display_name.is_empty() {
            &self.name
        } else {
            &self.display_name
        }
    }
}

#[derive(Deserialize, Default)]
struct UserSearchPage {
    #[serde(default)]
    data: Vec<UserHit>,
}

/// Finds Roblox users by (partial) username. Public, no sign-in needed — but
/// Roblox rate-limits this one hard without a signed-in session.
pub fn search_users(keyword: &str) -> Result<Vec<UserHit>, String> {
    let keyword = keyword.trim();
    if keyword.is_empty() {
        return Ok(Vec::new());
    }
    let url = format!(
        "https://users.roblox.com/v1/users/search?keyword={}&limit=10",
        ozara_core::oauth::percent_encode(keyword)
    );
    let page: UserSearchPage = ureq::get(&url)
        .set("Accept", "application/json")
        .call()
        .map_err(|e| match e {
            ureq::Error::Status(429, _) => {
                "Roblox is rate-limiting requests. Try again in a minute.".to_string()
            }
            ureq::Error::Status(code, _) => format!("Roblox answered with error {code}."),
            other => format!("Could not reach Roblox: {other}"),
        })?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;
    Ok(page.data)
}

#[derive(Clone, Debug)]
pub struct GameHit {
    pub universe_id: u64,
    pub place_id: u64,
    pub name: String,
    pub playing: u32,
}

#[derive(Deserialize)]
struct GameDetailItem {
    id: u64,
    #[serde(default, rename = "rootPlaceId")]
    root_place_id: Option<u64>,
    #[serde(default)]
    name: String,
    #[serde(default)]
    playing: u32,
}

#[derive(Deserialize, Default)]
struct GameDetailPage {
    #[serde(default)]
    data: Vec<GameDetailItem>,
}

fn random_guid() -> String {
    let mut buf = [0u8; 16];
    rand::thread_rng().fill_bytes(&mut buf);
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7], buf[8], buf[9], buf[10], buf[11], buf[12], buf[13], buf[14], buf[15]
    )
}

/// Walks a JSON value of any shape and collects every `universeId` number it finds.
fn collect_universe_ids(value: &serde_json::Value, out: &mut Vec<u64>) {
    match value {
        serde_json::Value::Object(map) => {
            if let Some(id) = map.get("universeId").and_then(|v| v.as_u64()) {
                if !out.contains(&id) {
                    out.push(id);
                }
            }
            for v in map.values() {
                collect_universe_ids(v, out);
            }
        }
        serde_json::Value::Array(items) => {
            for v in items {
                collect_universe_ids(v, out);
            }
        }
        _ => {}
    }
}

/// Finds games by name. Roblox's keyword search ("omni-search") is the same
/// internal endpoint roblox.com's own search box uses; it's not in Roblox's
/// official docs and its exact shape can change, so this only trusts it for a
/// list of game IDs. The name, player count and joinable place ID shown in
/// Ozara always come from Roblox's official, documented Games API instead.
pub fn search_games(keyword: &str) -> Result<Vec<GameHit>, String> {
    let keyword = keyword.trim();
    if keyword.is_empty() {
        return Ok(Vec::new());
    }
    let url = format!(
        "https://apis.roblox.com/search-api/omni-search?searchQuery={}&sessionId={}&pageType=all",
        ozara_core::oauth::percent_encode(keyword),
        random_guid()
    );
    let value: serde_json::Value = ureq::get(&url)
        .set("Accept", "application/json")
        .call()
        .map_err(|e| match e {
            ureq::Error::Status(429, _) => "Roblox is rate-limiting requests. Try again in a minute.".to_string(),
            ureq::Error::Status(code, _) => format!("Roblox answered with error {code}."),
            other => format!("Could not reach Roblox: {other}"),
        })?
        .into_json()
        .map_err(|e| format!("Roblox's search didn't return what Ozara expected ({e}). This search endpoint is unofficial and can change without notice."))?;
    let mut universe_ids = Vec::new();
    collect_universe_ids(&value, &mut universe_ids);
    universe_ids.truncate(20);
    if universe_ids.is_empty() {
        return Ok(Vec::new());
    }
    let ids: Vec<String> = universe_ids.iter().map(|id| id.to_string()).collect();
    let games_url = format!(
        "https://games.roblox.com/v1/games?universeIds={}",
        ids.join(",")
    );
    let page: GameDetailPage = ureq::get(&games_url)
        .call()
        .map_err(|e| format!("Could not reach Roblox: {e}"))?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;
    // Keep the order the search gave us, not whatever order the details came back in.
    let mut by_id: HashMap<u64, GameDetailItem> =
        page.data.into_iter().map(|g| (g.id, g)).collect();
    Ok(universe_ids
        .into_iter()
        .filter_map(|uid| by_id.remove(&uid))
        .filter_map(|g| {
            let place_id = g.root_place_id?;
            Some(GameHit {
                universe_id: g.id,
                place_id,
                name: g.name,
                playing: g.playing,
            })
        })
        .collect())
}

#[derive(Deserialize)]
struct UniverseResp {
    #[serde(default, rename = "universeId")]
    universe_id: Option<u64>,
}

#[derive(Deserialize)]
struct GameItem {
    id: u64,
    #[serde(default)]
    name: String,
}

#[derive(Deserialize, Default)]
struct GamesPage {
    #[serde(default)]
    data: Vec<GameItem>,
}

/// Game names for place IDs. Places that cannot be looked up are simply left out.
pub fn fetch_game_names(place_ids: &[String]) -> HashMap<String, String> {
    let mut pairs: Vec<(String, u64)> = Vec::new();
    for pid in place_ids {
        if !ozara_core::join::is_numeric_id(pid) {
            continue;
        }
        let url = format!("https://apis.roblox.com/universes/v1/places/{pid}/universe");
        if let Ok(resp) = ureq::get(&url).call() {
            if let Ok(u) = resp.into_json::<UniverseResp>() {
                if let Some(id) = u.universe_id {
                    pairs.push((pid.clone(), id));
                }
            }
        }
    }
    let mut out = HashMap::new();
    if pairs.is_empty() {
        return out;
    }
    let ids: Vec<String> = pairs.iter().map(|(_, u)| u.to_string()).collect();
    let url = format!(
        "https://games.roblox.com/v1/games?universeIds={}",
        ids.join(",")
    );
    let page: GamesPage = ureq::get(&url)
        .call()
        .ok()
        .and_then(|r| r.into_json().ok())
        .unwrap_or_default();
    for (pid, uid) in pairs {
        if let Some(g) = page.data.iter().find(|g| g.id == uid) {
            out.insert(pid, g.name.clone());
        }
    }
    out
}

#[derive(Deserialize)]
struct LookupItem {
    id: u64,
    #[serde(default)]
    name: String,
    #[serde(default, rename = "displayName")]
    display_name: String,
}

#[derive(Deserialize, Default)]
struct LookupPage {
    #[serde(default)]
    data: Vec<LookupItem>,
}

/// Find a Roblox user by username (public information, no sign-in).
pub fn lookup_user(username: &str) -> Result<crate::auth::Profile, String> {
    let username = username.trim().trim_start_matches('@');
    if username.is_empty() || username.len() > 40 {
        return Err("Type your Roblox username.".into());
    }
    let page: LookupPage = ureq::post("https://users.roblox.com/v1/usernames/users")
        .send_json(serde_json::json!({ "usernames": [username], "excludeBannedUsers": true }))
        .map_err(|e| match e {
            ureq::Error::Status(429, _) => {
                "Roblox is rate-limiting requests. Try again in a minute.".to_string()
            }
            ureq::Error::Status(code, _) => format!("Roblox answered with error {code}."),
            other => format!("Could not reach Roblox: {other}"),
        })?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;
    match page.data.into_iter().next() {
        Some(u) => Ok(crate::auth::Profile {
            user_id: u.id.to_string(),
            name: if u.display_name.is_empty() {
                u.name.clone()
            } else {
                u.display_name
            },
            username: u.name,
            // Username-link never signs in, so Roblox never tells us this.
            verified: None,
        }),
        None => Err(format!("No Roblox user named \"{username}\" was found.")),
    }
}

#[derive(Deserialize, Default)]
struct CreatorInfo {
    #[serde(default)]
    name: String,
}

#[derive(Deserialize)]
struct FullGameItem {
    #[serde(default)]
    name: String,
    #[serde(default)]
    description: Option<String>,
    #[serde(default)]
    creator: CreatorInfo,
    #[serde(default)]
    playing: u64,
    #[serde(default)]
    visits: u64,
    #[serde(default, rename = "maxPlayers")]
    max_players: u32,
    #[serde(default, rename = "favoritedCount")]
    favorited: u64,
    #[serde(default)]
    genre: String,
}

#[derive(Deserialize, Default)]
struct FullGamesPage {
    #[serde(default)]
    data: Vec<FullGameItem>,
}

/// What the game page shows. Everything comes from Roblox's public Games API.
#[derive(Clone, Debug)]
pub struct GameDetails {
    pub name: String,
    pub description: String,
    pub creator: String,
    pub playing: u64,
    pub visits: u64,
    pub max_players: u32,
    pub favorited: u64,
    pub genre: String,
}

/// Looks a game up by its place ID (the number in the game's URL).
pub fn fetch_game_details(place_id: &str) -> Result<GameDetails, String> {
    if !ozara_core::join::is_numeric_id(place_id) {
        return Err("That game ID looks wrong.".into());
    }
    let url = format!("https://apis.roblox.com/universes/v1/places/{place_id}/universe");
    let universe = ureq::get(&url)
        .call()
        .map_err(|e| format!("Could not look that game up: {e}"))?
        .into_json::<UniverseResp>()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?
        .universe_id
        .ok_or("Roblox has no game for that ID.")?;
    let url = format!("https://games.roblox.com/v1/games?universeIds={universe}");
    let page: FullGamesPage = ureq::get(&url)
        .call()
        .map_err(|e| format!("Could not load the game's details: {e}"))?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;
    let g = page
        .data
        .into_iter()
        .next()
        .ok_or("Roblox returned no details for that game.")?;
    Ok(GameDetails {
        name: g.name,
        description: g.description.unwrap_or_default(),
        creator: g.creator.name,
        playing: g.playing,
        visits: g.visits,
        max_players: g.max_players,
        favorited: g.favorited,
        genre: g.genre,
    })
}

/// Asks GitHub which Ozara release is newest and returns its version tag.
pub fn fetch_latest_version() -> Result<String, String> {
    let resp = ureq::get(&ozara_core::release::latest_release_api())
        .set("User-Agent", "Ozara")
        .set("Accept", "application/vnd.github+json")
        .call()
        .map_err(|e| format!("Could not reach GitHub: {e}"))?;
    let body = resp.into_string().map_err(|e| format!("Could not read GitHub's answer: {e}"))?;
    ozara_core::release::tag_from_release_json(&body)
        .ok_or_else(|| "GitHub didn't return a version — is there a published release yet?".to_string())
}

/// Downloads the newest `ozara.exe` from GitHub Releases.
pub fn download_latest_exe() -> Result<Vec<u8>, String> {
    let resp = ureq::get(&ozara_core::release::latest_exe_url())
        .set("User-Agent", "Ozara")
        .call()
        .map_err(|e| format!("Download failed: {e}"))?;
    let mut buf = Vec::new();
    resp.into_reader().read_to_end(&mut buf).map_err(|e| format!("Could not read the download: {e}"))?;
    if buf.len() < 4 || &buf[..2] != b"MZ" {
        return Err("The download didn't look like an Ozara program.".into());
    }
    Ok(buf)
}

#[derive(Deserialize, Default)]
struct UserAbout {
    #[serde(default)]
    description: String,
}

/// Reads a user's public profile "About" text (their blurb). Used for ownership
/// verification: Ozara has the person paste a one-time code into their own blurb,
/// then checks it here — proof they control the account, with no login or cookies.
pub fn fetch_user_description(user_id: &str) -> Result<String, String> {
    if !ozara_core::join::is_numeric_id(user_id) {
        return Err("That user ID looks wrong.".into());
    }
    let url = format!("https://users.roblox.com/v1/users/{user_id}");
    let about: UserAbout = ureq::get(&url)
        .call()
        .map_err(|e| match e {
            ureq::Error::Status(429, _) => {
                "Roblox is rate-limiting requests. Try again in a minute.".to_string()
            }
            other => format!("Could not reach Roblox: {other}"),
        })?
        .into_json()
        .map_err(|e| format!("Unexpected answer from Roblox: {e}"))?;
    Ok(about.description)
}
