//! Small cache that turns Roblox image URLs (avatars, game icons) into textures egui can draw.
//! Downloads happen on background threads; this struct only holds results.

use eframe::egui;
use std::collections::HashMap;
use std::sync::mpsc::{channel, Receiver, Sender};

enum Loaded {
    Ok(u64, egui::ColorImage),
    Err(u64),
}

pub struct ImageCache {
    textures: HashMap<u64, egui::TextureHandle>,
    requested: HashMap<u64, String>, // user id -> url already asked for
    failed: std::collections::HashSet<u64>,
    label: &'static str,
    fetch_urls: fn(&[u64]) -> HashMap<u64, String>,
    tx: Sender<Loaded>,
    rx: Receiver<Loaded>,
}

impl ImageCache {
    /// `label` names the textures; `fetch_urls` turns IDs into image URLs (batched).
    pub fn new(label: &'static str, fetch_urls: fn(&[u64]) -> HashMap<u64, String>) -> Self {
        let (tx, rx) = channel();
        Self {
            textures: HashMap::new(),
            requested: HashMap::new(),
            failed: std::collections::HashSet::new(),
            label,
            fetch_urls,
            tx,
            rx,
        }
    }

    /// Call once a frame. Picks up any images that finished downloading.
    pub fn poll(&mut self, ctx: &egui::Context) {
        while let Ok(msg) = self.rx.try_recv() {
            match msg {
                Loaded::Ok(id, color_image) => {
                    let handle = ctx.load_texture(
                        format!("{}-{id}", self.label),
                        color_image,
                        egui::TextureOptions::LINEAR,
                    );
                    self.textures.insert(id, handle);
                }
                Loaded::Err(id) => {
                    self.failed.insert(id);
                }
            }
        }
    }

    /// The texture for this ID, if it's already loaded.
    pub fn get(&self, user_id: u64) -> Option<&egui::TextureHandle> {
        self.textures.get(&user_id)
    }

    /// Fetches avatar URLs for any of these IDs we haven't asked about yet, then
    /// downloads and decodes each image on its own thread.
    pub fn ensure(&mut self, ctx: &egui::Context, user_ids: &[u64]) {
        let missing: Vec<u64> = user_ids
            .iter()
            .copied()
            .filter(|id| !self.requested.contains_key(id) && !self.failed.contains(id))
            .collect();
        if missing.is_empty() {
            return;
        }
        for &id in &missing {
            self.requested.insert(id, String::new());
        }
        let tx = self.tx.clone();
        let ctx = ctx.clone();
        let fetch_urls = self.fetch_urls;
        std::thread::spawn(move || {
            let urls = fetch_urls(&missing);
            for &id in &missing {
                let Some(url) = urls.get(&id) else {
                    let _ = tx.send(Loaded::Err(id));
                    continue;
                };
                match crate::net::fetch_image_bytes(url).and_then(|bytes| decode(&bytes)) {
                    Ok(color_image) => {
                        let _ = tx.send(Loaded::Ok(id, color_image));
                    }
                    Err(_) => {
                        let _ = tx.send(Loaded::Err(id));
                    }
                }
            }
            ctx.request_repaint();
        });
    }
}

fn decode(bytes: &[u8]) -> Result<egui::ColorImage, String> {
    let img = image::load_from_memory(bytes)
        .map_err(|e| e.to_string())?
        .into_rgba8();
    let size = [img.width() as usize, img.height() as usize];
    Ok(egui::ColorImage::from_rgba_unmultiplied(
        size,
        img.as_flat_samples().as_slice(),
    ))
}
