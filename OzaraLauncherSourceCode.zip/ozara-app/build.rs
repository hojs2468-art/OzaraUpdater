// Embeds Ozara's own icon (assets/ozara.ico) into ozara.exe as a Windows resource,
// so File Explorer, pinned taskbar shortcuts, and Alt+Tab show the real logo
// instead of a generic icon. Only runs when building for Windows.
fn main() {
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows") {
        let mut res = winres::WindowsResource::new();
        res.set_icon("assets/ozara.ico");
        if let Err(e) = res.compile() {
            // Don't fail the whole build over a missing icon; just say so.
            println!("cargo:warning=Could not embed the app icon: {e}");
        }
    }
}
