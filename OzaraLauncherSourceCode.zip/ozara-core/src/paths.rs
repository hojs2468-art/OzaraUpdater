//! Finding Roblox's folders. Every function takes a base path, so it can be tested.

use std::fs;
use std::path::{Path, PathBuf};
use std::time::SystemTime;

pub fn roblox_dir(local_app_data: &Path) -> PathBuf {
    local_app_data.join("Roblox")
}

pub fn global_settings_file(roblox: &Path) -> PathBuf {
    roblox.join("GlobalBasicSettings_13.xml")
}

pub fn logs_dir(roblox: &Path) -> PathBuf {
    roblox.join("logs")
}

/// Newest `Versions/<name>` folder that contains the player executable.
pub fn find_player_version_dir(roblox: &Path) -> Option<PathBuf> {
    let versions = roblox.join("Versions");
    let mut best: Option<(SystemTime, PathBuf)> = None;
    for entry in fs::read_dir(versions).ok()?.flatten() {
        let path = entry.path();
        if !path.join("RobloxPlayerBeta.exe").is_file() {
            continue;
        }
        let modified = entry.metadata().and_then(|m| m.modified()).unwrap_or(SystemTime::UNIX_EPOCH);
        if best.as_ref().map_or(true, |(t, _)| modified > *t) {
            best = Some((modified, path));
        }
    }
    best.map(|(_, p)| p)
}

/// Every `Versions/<name>` folder that contains the player executable. Ozara
/// writes FastFlags to all of them, because Roblox may launch a different version
/// than the newest one, and flags only apply to the version that actually runs.
pub fn all_player_version_dirs(roblox: &Path) -> Vec<PathBuf> {
    let versions = roblox.join("Versions");
    let mut out = Vec::new();
    if let Ok(entries) = fs::read_dir(versions) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.join("RobloxPlayerBeta.exe").is_file() {
                out.push(path);
            }
        }
    }
    out
}

fn is_player_log(path: &Path) -> bool {
    let Some(name) = path.file_name() else { return false };
    let name = name.to_string_lossy();
    name.ends_with(".log") && name.contains("Player")
}

/// The most recently modified player log file.
pub fn latest_player_log(logs: &Path) -> Option<PathBuf> {
    let mut best: Option<(SystemTime, PathBuf)> = None;
    for entry in fs::read_dir(logs).ok()?.flatten() {
        let path = entry.path();
        if !is_player_log(&path) {
            continue;
        }
        let modified = entry.metadata().and_then(|m| m.modified()).unwrap_or(SystemTime::UNIX_EPOCH);
        if best.as_ref().map_or(true, |(t, _)| modified > *t) {
            best = Some((modified, path));
        }
    }
    best.map(|(_, p)| p)
}

/// Up to `limit` player log files, newest first. Unlike `latest_player_log`,
/// this looks at every log Roblox has kept, not just the current one — used
/// once to learn what was played before Ozara was ever opened.
pub fn recent_player_logs(logs: &Path, limit: usize) -> Vec<PathBuf> {
    let mut found: Vec<(SystemTime, PathBuf)> = fs::read_dir(logs)
        .map(|entries| {
            entries
                .flatten()
                .filter(|e| is_player_log(&e.path()))
                .map(|e| {
                    let modified = e.metadata().and_then(|m| m.modified()).unwrap_or(SystemTime::UNIX_EPOCH);
                    (modified, e.path())
                })
                .collect()
        })
        .unwrap_or_default();
    found.sort_by(|a, b| b.0.cmp(&a.0));
    found.truncate(limit);
    found.into_iter().map(|(_, p)| p).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finds_version_dir_with_player_exe() {
        let base = std::env::temp_dir().join(format!("ozara-paths-test-{}", std::process::id()));
        let roblox = roblox_dir(&base);
        fs::create_dir_all(roblox.join("Versions/version-empty")).unwrap();
        fs::create_dir_all(roblox.join("Versions/version-good")).unwrap();
        fs::write(roblox.join("Versions/version-good/RobloxPlayerBeta.exe"), b"x").unwrap();
        let found = find_player_version_dir(&roblox).unwrap();
        assert!(found.ends_with("version-good"));
        fs::create_dir_all(logs_dir(&roblox)).unwrap();
        fs::write(logs_dir(&roblox).join("0.1_Player_ABC_last.log"), b"x").unwrap();
        fs::write(logs_dir(&roblox).join("other.txt"), b"x").unwrap();
        assert!(latest_player_log(&logs_dir(&roblox)).unwrap().ends_with("0.1_Player_ABC_last.log"));
        fs::write(logs_dir(&roblox).join("0.1_Player_DEF_last.log"), b"x").unwrap();
        let recent = recent_player_logs(&logs_dir(&roblox), 10);
        assert_eq!(recent.len(), 2); // the two .log/Player files, not other.txt
        assert_eq!(recent_player_logs(&logs_dir(&roblox), 1).len(), 1); // limit is respected
        fs::remove_dir_all(&base).unwrap();
    }

    #[test]
    fn missing_dirs_give_none() {
        let nowhere = Path::new("/definitely/not/here");
        assert!(find_player_version_dir(nowhere).is_none());
        assert!(latest_player_log(nowhere).is_none());
        assert!(recent_player_logs(nowhere, 10).is_empty());
    }
}
