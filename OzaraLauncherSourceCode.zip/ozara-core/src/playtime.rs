//! Playtime sessions, stored in a small tab-separated file on the player's own PC.

use std::collections::BTreeMap;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Session {
    pub place_id: String,
    /// Unix seconds, UTC.
    pub start: i64,
    pub end: i64,
}

impl Session {
    pub fn seconds(&self) -> i64 {
        (self.end - self.start).max(0)
    }
}

pub fn format_session(s: &Session) -> String {
    format!("{}\t{}\t{}", s.place_id, s.start, s.end)
}

/// Lines that cannot be read are skipped, so one bad line never loses the rest.
pub fn parse_sessions(text: &str) -> Vec<Session> {
    text.lines()
        .filter_map(|line| {
            let mut p = line.split('\t');
            let place_id = p.next()?.to_string();
            let start = p.next()?.parse().ok()?;
            let end = p.next()?.parse().ok()?;
            if !crate::join::is_numeric_id(&place_id) || end < start {
                return None;
            }
            Some(Session { place_id, start, end })
        })
        .collect()
}

/// Seconds of play inside [from, to), with sessions clipped to the window.
pub fn seconds_between(sessions: &[Session], from: i64, to: i64) -> i64 {
    sessions
        .iter()
        .map(|s| (s.end.min(to) - s.start.max(from)).max(0))
        .sum()
}

/// Seconds played on each of `days` consecutive UTC days starting at `first_day_start`.
pub fn daily_seconds(sessions: &[Session], first_day_start: i64, days: usize) -> Vec<i64> {
    (0..days as i64)
        .map(|d| {
            let from = first_day_start + d * 86_400;
            seconds_between(sessions, from, from + 86_400)
        })
        .collect()
}

/// Total seconds per game, most played first.
pub fn per_game(sessions: &[Session]) -> Vec<(String, i64)> {
    let mut totals: BTreeMap<String, i64> = BTreeMap::new();
    for s in sessions {
        *totals.entry(s.place_id.clone()).or_default() += s.seconds();
    }
    let mut v: Vec<_> = totals.into_iter().collect();
    v.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
    v
}

pub fn format_duration(secs: i64) -> String {
    let secs = secs.max(0);
    let (h, m) = (secs / 3600, (secs % 3600) / 60);
    if h > 0 {
        format!("{h} h {m} m")
    } else {
        format!("{m} m")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn s(place: &str, a: i64, b: i64) -> Session {
        Session { place_id: place.into(), start: a, end: b }
    }

    #[test]
    fn roundtrip_and_skips_bad_lines() {
        let text = format!("{}\nnot a line\n1\t5\t3\n{}\n", format_session(&s("10", 0, 100)), format_session(&s("20", 50, 80)));
        let parsed = parse_sessions(&text);
        assert_eq!(parsed, vec![s("10", 0, 100), s("20", 50, 80)]);
    }

    #[test]
    fn clips_to_the_window() {
        let v = vec![s("1", 0, 100), s("1", 150, 400)];
        assert_eq!(seconds_between(&v, 50, 200), 50 + 50);
        assert_eq!(seconds_between(&v, 500, 600), 0);
    }

    #[test]
    fn daily_split_across_midnight() {
        let v = vec![s("1", 86_400 - 600, 86_400 + 900)];
        assert_eq!(daily_seconds(&v, 0, 2), vec![600, 900]);
    }

    #[test]
    fn per_game_sorted_most_first() {
        let v = vec![s("1", 0, 10), s("2", 0, 50), s("1", 20, 40)];
        assert_eq!(per_game(&v), vec![("2".to_string(), 50), ("1".to_string(), 30)]);
    }

    #[test]
    fn durations() {
        assert_eq!(format_duration(3 * 3600 + 24 * 60), "3 h 24 m");
        assert_eq!(format_duration(125), "2 m");
    }
}
