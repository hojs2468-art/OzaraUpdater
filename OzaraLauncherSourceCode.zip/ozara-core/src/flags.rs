//! Performance settings engine.
//!
//! Roblox only honours a small allowlist of FastFlags in `ClientAppSettings.json`
//! (anything else is silently ignored). Ozara therefore never writes a flag that
//! is not in its allowlist, and the allowlist is data that can be refreshed
//! without touching the rest of the code.

use std::collections::BTreeMap;
use std::fmt;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};

/// A FastFlag value. Roblox accepts booleans and integers in this file.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum FlagValue {
    Bool(bool),
    Int(i64),
    /// For custom flags whose value isn't a bool or number (e.g. FString flags).
    Str(String),
}

impl fmt::Display for FlagValue {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            // Roblox's own tooling writes values as strings ("True", "0").
            FlagValue::Bool(true) => write!(f, "True"),
            FlagValue::Bool(false) => write!(f, "False"),
            FlagValue::Int(n) => write!(f, "{n}"),
            FlagValue::Str(s) => write!(f, "{s}"),
        }
    }
}

/// Where an allowlist entry came from, so the UI can be honest about certainty.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Source {
    /// Listed in Roblox's official allowlist announcement.
    Official,
    /// Reported by the community as accepted; verify against the live allowlist.
    Community,
}

/// A user-facing setting that maps to one or more FastFlags.
#[derive(Clone, Debug)]
pub struct Setting {
    pub id: &'static str,
    pub label: &'static str,
    pub description: &'static str,
    pub flags: Vec<(&'static str, FlagValue)>,
    /// True when this setting writes a FastFlag named `Debug*` — one Roblox
    /// only half-supports outside its own internal builds. These are the ones
    /// most likely to freeze Roblox on a white screen at launch, so Ozara
    /// warns about them and never bundles them into a one-click preset.
    pub risky: bool,
}

/// The set of flag names Ozara is allowed to write.
#[derive(Clone, Debug, Default)]
pub struct Allowlist {
    entries: BTreeMap<String, Source>,
}

impl Allowlist {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, name: &str, source: Source) {
        self.entries.insert(name.to_string(), source);
    }

    pub fn contains(&self, name: &str) -> bool {
        self.entries.contains_key(name)
    }

    pub fn source(&self, name: &str) -> Option<Source> {
        self.entries.get(name).copied()
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Loads one flag name per line (`#` starts a comment). Lines are marked
    /// `Community` unless suffixed with ` official`.
    pub fn parse(text: &str) -> Self {
        let mut list = Self::new();
        for line in text.lines() {
            let line = line.split('#').next().unwrap_or("").trim();
            if line.is_empty() {
                continue;
            }
            let mut parts = line.split_whitespace();
            let name = parts.next().unwrap();
            let source = match parts.next() {
                Some("official") => Source::Official,
                _ => Source::Community,
            };
            list.insert(name, source);
        }
        list
    }

    /// Seed list. Only the four CSG level-of-detail flags were in Roblox's
    /// announced allowlist when this was written; the rest are community-reported.
    /// The allowlist changes without notice, so refresh it before trusting it.
    pub fn builtin() -> Self {
        Self::parse(include_str!("../allowlist.txt"))
    }
}

/// Everything the user can toggle, as one list the UI can render directly.
pub fn settings_catalog() -> Vec<Setting> {
    use FlagValue::{Bool, Int};
    vec![
        Setting {
            id: "lod",
            label: "Aggressive level of detail",
            description: "Objects switch to lower-detail models sooner. Big FPS gain in busy maps.",
            flags: vec![
                ("DFIntCSGLevelOfDetailSwitchingDistance", Int(0)),
                ("DFIntCSGLevelOfDetailSwitchingDistanceL12", Int(0)),
                ("DFIntCSGLevelOfDetailSwitchingDistanceL23", Int(0)),
                ("DFIntCSGLevelOfDetailSwitchingDistanceL34", Int(0)),
            ],
            risky: false,
        },
        Setting {
            id: "textures",
            label: "Lowest texture quality",
            description: "Uses the smallest textures. Saves video memory on weak GPUs.",
            flags: vec![
                ("DFFlagTextureQualityOverrideEnabled", Bool(true)),
                ("DFIntTextureQualityOverride", Int(0)),
            ],
            risky: false,
        },
        Setting {
            id: "msaa_off",
            label: "Anti-aliasing off",
            description: "Disables MSAA smoothing for a faster, sharper-edged picture.",
            flags: vec![("FIntDebugForceMSAASamples", Int(1))],
            risky: true,
        },
        Setting {
            id: "no_lights",
            label: "Pause lighting updates",
            description: "Stops dynamic lighting from being recalculated (no light flicker).",
            flags: vec![("DFFlagDebugPauseVoxelizer", Bool(true))],
            risky: true,
        },
        Setting {
            id: "no_grass",
            label: "Remove grass",
            description: "Hides terrain grass to cut draw calls.",
            flags: vec![
                ("FIntFRMMinGrassDistance", Int(0)),
                ("FIntFRMMaxGrassDistance", Int(0)),
            ],
            risky: false,
        },
        Setting {
            id: "gray_sky",
            label: "Plain gray sky",
            description: "Replaces the skybox with a flat color.",
            flags: vec![("FFlagDebugSkyGray", Bool(true))],
            risky: true,
        },
        // ---- Lighting ----
        Setting {
            id: "no_shadows",
            label: "No shadows (aggressive)",
            description: "Stacks every shadow-killing flag at once — player shadows, baked shadows, and shadow-map culling — so nothing casts a shadow. Big win in heavy maps.",
            flags: vec![
                ("FIntRenderShadowIntensity", Int(0)),
                ("FFlagDisablePlayerShadows", Bool(true)),
                ("DFFlagDebugPauseVoxelizer", Bool(true)),
                ("FFlagNewLightAttenuation", Bool(false)),
                ("FIntCSGVoxelizerFadeRadius", Int(0)),
                ("DFIntCullFactorPixelThresholdShadowMapHighQuality", Int(2_147_483_647)),
                ("DFIntCullFactorPixelThresholdShadowMapLowQuality", Int(2_147_483_647)),
            ],
            risky: true,
        },
        Setting {
            id: "voxel_lighting",
            label: "Retro (voxel) lighting",
            description: "Forces Roblox's old Phase-1 voxel lighting instead of modern shadow-mapped lighting — flat, bright and fast, with no real-time global shadows. The most visible of the lighting tweaks.",
            flags: vec![("DFFlagDebugRenderForceTechnologyVoxel", Bool(true))],
            risky: true,
        },
        Setting {
            id: "no_postfx",
            label: "No post-processing",
            description: "Turns off post effects like bloom, blur and colour correction for a cleaner, cheaper picture.",
            flags: vec![("FFlagDisablePostFx", Bool(true))],
            risky: true,
        },
        // ---- Advanced ----
        Setting {
            id: "force_dx11",
            label: "Force DirectX 11",
            description: "Makes Roblox render with DirectX 11, which runs faster than Vulkan on many Windows PCs. If Roblox crashes or shows a black screen, turn this back off.",
            flags: vec![
                ("FFlagDebugGraphicsPreferD3D11", Bool(true)),
                ("FFlagDebugGraphicsDisableMetal", Bool(true)),
            ],
            risky: true,
        },
        Setting {
            id: "lowest_quality",
            label: "Lowest quality level",
            description: "Forces Roblox's internal render quality to its lowest level — the strongest single performance lever, at the cost of looks.",
            flags: vec![
                ("FIntRomarkStartWithGraphicQualityLevel", Int(1)),
                ("DFIntDebugFRMQualityLevelOverride", Int(1)),
            ],
            risky: true,
        },
    ]
}

/// One-click bundles of setting ids.
pub fn presets() -> Vec<(&'static str, Vec<&'static str>)> {
    // The performance presets stay safe — they don't bundle any `risky` flag.
    vec![
        ("Max FPS", vec!["lod", "textures", "no_grass"]),
        ("Balanced", vec!["lod", "no_grass"]),
        ("Potato PC", vec!["lod", "textures", "no_grass"]),
        ("Default", vec![]),
    ]
}

/// Lighting presets. These DO include experimental lighting flags (the ones that
/// can freeze some systems on a white screen), because that's the whole point of
/// them — the user is choosing a lighting look on purpose.
pub fn lighting_presets() -> Vec<(&'static str, Vec<&'static str>)> {
    vec![
        ("Flat & bright", vec!["voxel_lighting"]),
        ("No shadows", vec!["no_shadows", "no_postfx"]),
        ("Retro", vec!["voxel_lighting", "no_shadows", "no_postfx", "gray_sky"]),
        ("Lighting off", vec![]),
    ]
}

/// Turns chosen setting ids into the flags to write, dropping anything not on
/// the allowlist. Returns `(flags, skipped_names)` so the UI can tell the user
/// which options are currently ignored by Roblox.
/// Parses the user's own custom flags, one per line. Accepts flexible formats:
/// `FlagName=True`, `FlagName: 0`, or JSON-style `"FlagName": "True"`. `#` or `//`
/// starts a comment. Values of true/false become booleans, whole numbers become
/// ints, anything else is kept as a string. Custom flags are NOT checked against
/// Ozara's allowlist — Roblox simply ignores any it doesn't honor, with no penalty.
pub fn parse_custom_flags(text: &str) -> BTreeMap<String, FlagValue> {
    let mut out = BTreeMap::new();
    for line in text.lines() {
        let l = line.trim().trim_end_matches(',');
        if l.is_empty() || l.starts_with('#') || l.starts_with("//") || l == "{" || l == "}" {
            continue;
        }
        let Some(i) = l.find('=').or_else(|| l.find(':')) else { continue };
        let name = l[..i].trim().trim_matches('"').trim();
        let val = l[i + 1..].trim().trim_matches('"').trim();
        if name.is_empty() {
            continue;
        }
        let fv = match val.to_ascii_lowercase().as_str() {
            "true" => FlagValue::Bool(true),
            "false" => FlagValue::Bool(false),
            _ => match val.parse::<i64>() {
                Ok(n) => FlagValue::Int(n),
                Err(_) => FlagValue::Str(val.to_string()),
            },
        };
        out.insert(name.to_string(), fv);
    }
    out
}

pub fn resolve(
    enabled_ids: &[&str],
    allowlist: &Allowlist,
) -> (BTreeMap<String, FlagValue>, Vec<String>) {
    let catalog = settings_catalog();
    let mut out = BTreeMap::new();
    let mut skipped = Vec::new();
    for id in enabled_ids {
        if let Some(setting) = catalog.iter().find(|s| s.id == *id) {
            for (name, value) in &setting.flags {
                if allowlist.contains(name) {
                    out.insert((*name).to_string(), value.clone());
                } else if !skipped.iter().any(|s| s == name) {
                    skipped.push((*name).to_string());
                }
            }
        }
    }
    (out, skipped)
}

fn escape_json(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

/// Serialises flags as the JSON object Roblox reads (values as strings).
pub fn to_json(flags: &BTreeMap<String, FlagValue>) -> String {
    if flags.is_empty() {
        return "{}\n".to_string();
    }
    let body: Vec<String> = flags
        .iter()
        .map(|(k, v)| format!("  \"{}\": \"{}\"", escape_json(k), escape_json(&v.to_string())))
        .collect();
    format!("{{\n{}\n}}\n", body.join(",\n"))
}

/// `<version dir>/ClientSettings/ClientAppSettings.json`
pub fn settings_path(version_dir: &Path) -> PathBuf {
    version_dir.join("ClientSettings").join("ClientAppSettings.json")
}

/// Writes (or, for an empty map, removes) the settings file for one Roblox version.
pub fn write_settings(version_dir: &Path, flags: &BTreeMap<String, FlagValue>) -> io::Result<()> {
    let path = settings_path(version_dir);
    if flags.is_empty() {
        return match fs::remove_file(&path) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(e),
        };
    }
    fs::create_dir_all(path.parent().unwrap())?;
    fs::write(path, to_json(flags))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn official_only() -> Allowlist {
        let mut a = Allowlist::new();
        for n in [
            "DFIntCSGLevelOfDetailSwitchingDistance",
            "DFIntCSGLevelOfDetailSwitchingDistanceL12",
            "DFIntCSGLevelOfDetailSwitchingDistanceL23",
            "DFIntCSGLevelOfDetailSwitchingDistanceL34",
        ] {
            a.insert(n, Source::Official);
        }
        a
    }

    #[test]
    fn unlisted_flags_are_never_written() {
        let (flags, skipped) = resolve(&["lod", "no_lights"], &official_only());
        assert_eq!(flags.len(), 4);
        assert!(!flags.contains_key("DFFlagDebugPauseVoxelizer"));
        assert_eq!(skipped, vec!["DFFlagDebugPauseVoxelizer".to_string()]);
    }

    #[test]
    fn json_is_sorted_stringly_typed_and_valid_looking() {
        let (flags, _) = resolve(&["lod"], &official_only());
        let json = to_json(&flags);
        assert!(json.starts_with("{\n  \"DFIntCSGLevelOfDetailSwitchingDistance\": \"0\""));
        assert!(json.trim_end().ends_with('}'));
        assert_eq!(json.matches(',').count(), 3); // 4 entries -> 3 separators
    }

    #[test]
    fn bools_use_roblox_casing() {
        let mut m = BTreeMap::new();
        m.insert("FFlagDebugSkyGray".to_string(), FlagValue::Bool(true));
        m.insert("X".to_string(), FlagValue::Bool(false));
        let json = to_json(&m);
        assert!(json.contains("\"FFlagDebugSkyGray\": \"True\""));
        assert!(json.contains("\"X\": \"False\""));
    }

    #[test]
    fn json_escapes_quotes() {
        let mut m = BTreeMap::new();
        m.insert("a\"b".to_string(), FlagValue::Int(1));
        assert!(to_json(&m).contains("\"a\\\"b\""));
    }

    #[test]
    fn default_preset_writes_nothing_and_removes_file() {
        let dir = std::env::temp_dir().join(format!("ozara-test-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        let (flags, _) = resolve(&["lod"], &official_only());
        write_settings(&dir, &flags).unwrap();
        assert!(settings_path(&dir).exists());
        write_settings(&dir, &BTreeMap::new()).unwrap();
        assert!(!settings_path(&dir).exists());
        // removing again must not error
        write_settings(&dir, &BTreeMap::new()).unwrap();
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn presets_reference_real_settings() {
        let ids: Vec<&str> = settings_catalog().iter().map(|s| s.id).collect();
        for (name, members) in presets() {
            for m in members {
                assert!(ids.contains(&m), "preset {name} references unknown setting {m}");
            }
        }
    }

    #[test]
    fn custom_flags_parse_mixed_formats() {
        let text = "# comment\nFFlagFoo=True\nFIntBar: 7\n\"DFStringBaz\": \"hello\"\nFFlagOff = false\n";
        let m = parse_custom_flags(text);
        assert_eq!(m.get("FFlagFoo"), Some(&FlagValue::Bool(true)));
        assert_eq!(m.get("FIntBar"), Some(&FlagValue::Int(7)));
        assert_eq!(m.get("DFStringBaz"), Some(&FlagValue::Str("hello".into())));
        assert_eq!(m.get("FFlagOff"), Some(&FlagValue::Bool(false)));
        assert_eq!(m.len(), 4);
    }

    #[test]
    fn allowlist_parse_handles_comments_and_source() {
        let a = Allowlist::parse("# hi\nFoo official\nBar # trailing\n\n");
        assert_eq!(a.source("Foo"), Some(Source::Official));
        assert_eq!(a.source("Bar"), Some(Source::Community));
        assert_eq!(a.len(), 2);
    }

    #[test]
    fn builtin_allowlist_contains_the_official_lod_flags() {
        let a = Allowlist::builtin();
        assert_eq!(a.source("DFIntCSGLevelOfDetailSwitchingDistance"), Some(Source::Official));
        assert_eq!(a.source("DFIntCSGLevelOfDetailSwitchingDistanceL12"), Some(Source::Official));
        assert!(!a.is_empty());
    }
}
