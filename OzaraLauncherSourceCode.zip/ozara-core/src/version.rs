//! Comparing Ozara versions like `0.1.0` or `v0.2.3`.

pub fn parse(v: &str) -> Option<(u32, u32, u32)> {
    let v = v.trim().trim_start_matches('v');
    let core = v.split(['-', '+']).next()?;
    let mut p = core.split('.');
    let a = p.next()?.parse().ok()?;
    let b = p.next().unwrap_or("0").parse().ok()?;
    let c = p.next().unwrap_or("0").parse().ok()?;
    if p.next().is_some() {
        return None;
    }
    Some((a, b, c))
}

/// True only when both versions parse and `latest` is strictly newer.
pub fn is_newer(current: &str, latest: &str) -> bool {
    match (parse(current), parse(latest)) {
        (Some(c), Some(l)) => l > c,
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn compares() {
        assert!(is_newer("0.1.0", "0.1.1"));
        assert!(is_newer("0.9.0", "v0.10.0"));
        assert!(!is_newer("1.0.0", "1.0.0"));
        assert!(!is_newer("1.2.0", "1.1.9"));
        assert!(!is_newer("1.0.0", "garbage"));
        assert!(is_newer("0.1", "0.1.1"));
    }
}
