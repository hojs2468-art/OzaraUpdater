//! Reading Roblox's own log files to learn which game and server is running.
//! Read-only. The line formats are what Roblox writes today; they can change in an update,
//! so every parser returns None instead of guessing.

/// A "joining game" event from the log.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct JoinEvent {
    pub job_id: String,
    pub place_id: String,
    /// Unix seconds (UTC) from the line's timestamp, if it could be read.
    pub at: Option<i64>,
}

/// Expected shape: `2026-11-13T18:00:00.123Z,... [FLog::Output] ! Joining game 'JOBID' place PLACEID at IP`
pub fn parse_join(line: &str) -> Option<JoinEvent> {
    let marker = "Joining game '";
    let i = line.find(marker)? + marker.len();
    let rest = &line[i..];
    let job_end = rest.find('\'')?;
    let job_id = &rest[..job_end];
    let after = &rest[job_end + 1..];
    let place_marker = " place ";
    let p = after.find(place_marker)? + place_marker.len();
    let digits: String = after[p..].chars().take_while(|c| c.is_ascii_digit()).collect();
    if !crate::join::is_job_id(job_id) || !crate::join::is_numeric_id(&digits) {
        return None;
    }
    let at = line.split(',').next().and_then(parse_iso_utc);
    Some(JoinEvent { job_id: job_id.to_string(), place_id: digits, at })
}

/// True for the line Roblox writes when the connection to a server ends.
pub fn is_disconnect(line: &str) -> bool {
    line.contains("Time to disconnect replication data")
}

/// Every play session found in one whole log file, as (which game, when it ended).
/// The join's own timestamp is the start (`JoinEvent.at`); a join with no
/// timestamp is useless for history, so callers should skip those. A session
/// with no disconnect line before the log ends (Roblox crashed, the PC slept,
/// or this is the log still being written) is closed at the last timestamp
/// seen in the file, so it still counts rather than being lost.
pub fn sessions_from_log(log_text: &str) -> Vec<(JoinEvent, i64)> {
    let mut out = Vec::new();
    let mut open: Option<JoinEvent> = None;
    let mut last_at: Option<i64> = None;
    for line in log_text.lines() {
        let line_at = line.split(',').next().and_then(parse_iso_utc);
        if let Some(ev) = parse_join(line) {
            // A new join means the previous session ended right here, not at
            // whatever `last_at` happened to be before it started (which, for two
            // joins with nothing between them, would be the previous session's own
            // start and wrongly give it zero duration).
            let closes_at = ev.at.or(line_at).or(last_at);
            if let (Some(prev), Some(end)) = (open.take(), closes_at) {
                out.push((prev, end));
            }
            last_at = closes_at;
            open = Some(ev);
            continue;
        }
        if is_disconnect(line) {
            if let (Some(prev), Some(end)) = (open.take(), line_at.or(last_at)) {
                out.push((prev, end));
            }
        }
        if let Some(at) = line_at {
            last_at = Some(at);
        }
    }
    if let (Some(prev), Some(end)) = (open, last_at) {
        out.push((prev, end));
    }
    out
}

/// The server the player is in right now: the last join with no disconnect after it.
pub fn current_join(log_text: &str) -> Option<JoinEvent> {
    let mut current = None;
    for line in log_text.lines() {
        if let Some(ev) = parse_join(line) {
            current = Some(ev);
        } else if is_disconnect(line) {
            current = None;
        }
    }
    current
}

/// Parse `YYYY-MM-DDTHH:MM:SS(.fff)Z` into unix seconds.
pub fn parse_iso_utc(s: &str) -> Option<i64> {
    let s = s.trim();
    let (date, time) = s.split_once('T')?;
    let mut d = date.split('-');
    let y: i64 = d.next()?.parse().ok()?;
    let m: i64 = d.next()?.parse().ok()?;
    let day: i64 = d.next()?.parse().ok()?;
    let time = time.trim_end_matches('Z');
    let time = time.split('.').next()?;
    let mut t = time.split(':');
    let hh: i64 = t.next()?.parse().ok()?;
    let mm: i64 = t.next()?.parse().ok()?;
    let ss: i64 = t.next()?.parse().ok()?;
    if !(1..=12).contains(&m) || !(1..=31).contains(&day) || hh > 23 || mm > 59 || ss > 60 {
        return None;
    }
    Some(days_from_civil(y, m, day) * 86_400 + hh * 3600 + mm * 60 + ss)
}

/// Days since 1970-01-01 for a civil date (Howard Hinnant's algorithm).
pub fn days_from_civil(y: i64, m: i64, d: i64) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = y - era * 400;
    let doy = (153 * (if m > 2 { m - 3 } else { m + 9 }) + 2) / 5 + d - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146_097 + doe - 719_468
}

#[cfg(test)]
mod tests {
    use super::*;

    const JOIN: &str = "2026-11-13T18:00:00.123Z,12.5,abcd,6 [FLog::Output] ! Joining game 'a41f9c2e-0b7d-4c11-9a52-0c3d4e5f6a7b' place 1818 at 128.116.1.1";

    #[test]
    fn parses_a_join_line() {
        let ev = parse_join(JOIN).unwrap();
        assert_eq!(ev.job_id, "a41f9c2e-0b7d-4c11-9a52-0c3d4e5f6a7b");
        assert_eq!(ev.place_id, "1818");
        assert_eq!(ev.at, Some(1_794_592_800));
    }

    #[test]
    fn ignores_other_lines_and_bad_ids() {
        assert!(parse_join("something else").is_none());
        assert!(parse_join("! Joining game 'not a job' place 12 at x").is_none());
        assert!(parse_join("! Joining game 'abc' place xx at x").is_none());
    }

    #[test]
    fn current_join_clears_after_disconnect() {
        let text = format!("{JOIN}\nnoise\n");
        assert_eq!(current_join(&text).unwrap().place_id, "1818");
        let text = format!("{JOIN}\n[FLog::Network] Time to disconnect replication data: 0.1\n");
        assert!(current_join(&text).is_none());
    }

    #[test]
    fn sessions_from_log_reads_a_closed_session() {
        let disconnect = "2026-11-13T18:05:00.000Z,1,a,b [FLog::Network] Time to disconnect replication data: 0.1";
        let text = format!("{JOIN}\n{disconnect}\n");
        let sessions = sessions_from_log(&text);
        assert_eq!(sessions.len(), 1);
        assert_eq!(sessions[0].0.place_id, "1818");
        assert_eq!(sessions[0].1, 1_794_593_100);
    }

    #[test]
    fn sessions_from_log_closes_an_unfinished_session_at_the_last_timestamp() {
        let later = "2026-11-13T18:10:00.000Z,1,a,b some other line";
        let text = format!("{JOIN}\n{later}\n");
        let sessions = sessions_from_log(&text);
        assert_eq!(sessions.len(), 1);
        assert_eq!(sessions[0].1, 1_794_593_400);
    }

    #[test]
    fn sessions_from_log_closes_the_previous_session_when_a_new_join_starts() {
        let second_join = "2026-11-13T18:20:00.000Z,1,a,b [FLog::Output] ! Joining game 'b41f9c2e-0b7d-4c11-9a52-0c3d4e5f6a7c' place 2020 at 128.116.1.1";
        // A third line, after the second join, gives the second session a real end
        // time and isolates what this test is actually about: that the first
        // session got closed (at the second join's start) rather than dropped.
        let later = "2026-11-13T18:25:00.000Z,1,a,b some other line";
        let text = format!("{JOIN}\n{second_join}\n{later}\n");
        let sessions = sessions_from_log(&text);
        assert_eq!(sessions.len(), 2);
        assert_eq!(sessions[0].0.place_id, "1818");
        assert_eq!(sessions[0].1, 1_794_594_000); // second join's own timestamp (18:20:00)
        assert_eq!(sessions[1].0.place_id, "2020");
        assert_eq!(sessions[1].1, 1_794_594_300); // the line after it, at 18:25:00
    }

    #[test]
    fn iso_parsing() {
        assert_eq!(parse_iso_utc("1970-01-01T00:00:00Z"), Some(0));
        assert_eq!(parse_iso_utc("2000-03-01T00:00:00.5Z"), Some(951_868_800));
        assert!(parse_iso_utc("garbage").is_none());
    }
}
