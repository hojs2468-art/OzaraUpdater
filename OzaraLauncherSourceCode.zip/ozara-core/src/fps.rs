//! Maximum framerate, via Roblox's own `GlobalBasicSettings_13.xml`.
//!
//! This is the same file Roblox's in-game "Maximum Framerate" setting writes to.
//! Roblox must be closed while it is edited, or it will overwrite the change.
//! Values above 240 are not officially supported, and a Roblox update may reset them.

use std::fs;
use std::io;
use std::path::Path;

/// Roblox's FramerateCap value that means "no cap" (unverified on every build; see UI note).
pub const UNCAPPED: i32 = 0;

/// Options shown in the UI. 0 = uncapped.
pub const CAP_OPTIONS: [i32; 8] = [30, 60, 120, 144, 165, 240, 360, UNCAPPED];

pub fn cap_label(cap: i32) -> String {
    if cap == UNCAPPED {
        "Uncapped".to_string()
    } else {
        format!("{cap}")
    }
}

/// Read the integer value of `<int name="NAME">N</int>`.
pub fn get_int_property(xml: &str, name: &str) -> Option<i32> {
    let (start, end) = find_property(xml, name)?;
    xml[start..end].trim().parse().ok()
}

/// Set `<int name="NAME">` to `value`. If the property is missing it is inserted
/// just before the closing `</Properties>` tag. Returns None if the file has no
/// `</Properties>` tag to insert into (so a damaged file is never made worse).
pub fn set_int_property(xml: &str, name: &str, value: i32) -> Option<String> {
    if let Some((start, end)) = find_property(xml, name) {
        let mut out = String::with_capacity(xml.len());
        out.push_str(&xml[..start]);
        out.push_str(&value.to_string());
        out.push_str(&xml[end..]);
        return Some(out);
    }
    let close = xml.find("</Properties>")?;
    let mut out = String::with_capacity(xml.len() + 64);
    out.push_str(&xml[..close]);
    out.push_str(&format!("\t\t<int name=\"{name}\">{value}</int>\n\t"));
    out.push_str(&xml[close..]);
    Some(out)
}

/// Byte range of the text inside `<int name="NAME">...</int>`.
fn find_property(xml: &str, name: &str) -> Option<(usize, usize)> {
    let open = format!("<int name=\"{name}\">");
    let start = xml.find(&open)? + open.len();
    let end = start + xml[start..].find("</int>")?;
    Some((start, end))
}

/// Write the framerate cap into the settings file, keeping a one-time backup.
pub fn write_framerate_cap(settings_file: &Path, cap: i32) -> io::Result<()> {
    let xml = fs::read_to_string(settings_file)?;
    let backup = backup_path(settings_file);
    if !backup.exists() {
        fs::write(&backup, &xml)?;
    }
    let updated = set_int_property(&xml, "FramerateCap", cap).ok_or_else(|| {
        io::Error::new(io::ErrorKind::InvalidData, "settings file has no </Properties> tag")
    })?;
    fs::write(settings_file, updated)
}

pub fn read_framerate_cap(settings_file: &Path) -> Option<i32> {
    get_int_property(&fs::read_to_string(settings_file).ok()?, "FramerateCap")
}

/// Where `write_framerate_cap` keeps its one-time backup of the untouched file.
pub fn backup_path(settings_file: &Path) -> std::path::PathBuf {
    settings_file.with_extension("xml.ozara-backup")
}

/// Copies the untouched backup back over the live settings file, undoing every
/// change Ozara has ever made to it (FPS cap included). `Ok(false)` means there
/// was no backup to restore from — Ozara never touched this file to begin with.
pub fn restore_backup(settings_file: &Path) -> io::Result<bool> {
    let backup = backup_path(settings_file);
    if !backup.is_file() {
        return Ok(false);
    }
    fs::copy(&backup, settings_file)?;
    Ok(true)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "<roblox>\n\t<Item class=\"UserGameSettings\">\n\t<Properties>\n\t\t<int name=\"FramerateCap\">60</int>\n\t\t<bool name=\"Fullscreen\">true</bool>\n\t</Properties>\n\t</Item>\n</roblox>";

    #[test]
    fn reads_existing_value() {
        assert_eq!(get_int_property(SAMPLE, "FramerateCap"), Some(60));
        assert_eq!(get_int_property(SAMPLE, "Missing"), None);
    }

    #[test]
    fn replaces_existing_value_and_keeps_the_rest() {
        let out = set_int_property(SAMPLE, "FramerateCap", 240).unwrap();
        assert_eq!(get_int_property(&out, "FramerateCap"), Some(240));
        assert!(out.contains("<bool name=\"Fullscreen\">true</bool>"));
        assert_eq!(out.matches("FramerateCap").count(), 1);
    }

    #[test]
    fn inserts_when_missing() {
        let xml = SAMPLE.replace("\t\t<int name=\"FramerateCap\">60</int>\n", "");
        let out = set_int_property(&xml, "FramerateCap", 144).unwrap();
        assert_eq!(get_int_property(&out, "FramerateCap"), Some(144));
        assert!(out.contains("</Properties>"));
    }

    #[test]
    fn refuses_to_edit_a_file_with_no_properties_tag() {
        assert!(set_int_property("<roblox></roblox>", "FramerateCap", 60).is_none());
    }

    #[test]
    fn restore_with_no_backup_does_nothing() {
        let dir = std::env::temp_dir().join(format!("ozara-fps-restore-none-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let f = dir.join("GlobalBasicSettings_13.xml");
        fs::write(&f, SAMPLE).unwrap();
        assert_eq!(restore_backup(&f).unwrap(), false);
        assert_eq!(read_framerate_cap(&f), Some(60)); // untouched
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn restore_brings_back_the_original_value() {
        let dir = std::env::temp_dir().join(format!("ozara-fps-restore-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let f = dir.join("GlobalBasicSettings_13.xml");
        fs::write(&f, SAMPLE).unwrap(); // original cap: 60
        write_framerate_cap(&f, 360).unwrap(); // Ozara changes it
        assert_eq!(read_framerate_cap(&f), Some(360));
        assert_eq!(restore_backup(&f).unwrap(), true);
        assert_eq!(read_framerate_cap(&f), Some(60)); // back to the original
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn file_roundtrip_makes_backup_once() {
        let dir = std::env::temp_dir().join(format!("ozara-fps-test-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let f = dir.join("GlobalBasicSettings_13.xml");
        fs::write(&f, SAMPLE).unwrap();
        write_framerate_cap(&f, 240).unwrap();
        write_framerate_cap(&f, 120).unwrap();
        assert_eq!(read_framerate_cap(&f), Some(120));
        let backup = fs::read_to_string(f.with_extension("xml.ozara-backup")).unwrap();
        assert_eq!(get_int_property(&backup, "FramerateCap"), Some(60));
        fs::remove_dir_all(&dir).unwrap();
    }
}
