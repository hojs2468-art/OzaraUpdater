//! Sorting and filtering for the server browser. Pure logic, no network.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Server {
    pub id: String,
    pub players: u32,
    pub max_players: u32,
    /// Ping in ms as reported by Roblox, when it reports one.
    pub ping: Option<u32>,
}

impl Server {
    pub fn is_full(&self) -> bool {
        self.players >= self.max_players
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Sort {
    FewestPlayers,
    MostPlayers,
    BestPing,
}

impl Sort {
    pub const ALL: [Sort; 3] = [Sort::FewestPlayers, Sort::MostPlayers, Sort::BestPing];

    pub fn label(self) -> &'static str {
        match self {
            Sort::FewestPlayers => "Fewest players",
            Sort::MostPlayers => "Most players",
            Sort::BestPing => "Best ping",
        }
    }
}

/// Servers to show, filtered and sorted. Servers without a ping sort last for ping.
pub fn visible(servers: &[Server], sort: Sort, hide_full: bool) -> Vec<Server> {
    let mut v: Vec<Server> = servers.iter().filter(|s| !(hide_full && s.is_full())).cloned().collect();
    match sort {
        Sort::FewestPlayers => v.sort_by_key(|s| s.players),
        Sort::MostPlayers => v.sort_by_key(|s| std::cmp::Reverse(s.players)),
        Sort::BestPing => v.sort_by_key(|s| s.ping.unwrap_or(u32::MAX)),
    }
    v
}

/// Lowest-ping server that still has room.
pub fn best_ping(servers: &[Server]) -> Option<&Server> {
    servers.iter().filter(|s| !s.is_full() && s.ping.is_some()).min_by_key(|s| s.ping)
}

/// Server with the fewest players that is not empty of room (and not a ghost with 0 players).
pub fn emptiest(servers: &[Server]) -> Option<&Server> {
    servers.iter().filter(|s| !s.is_full() && s.players > 0).min_by_key(|s| s.players)
}

/// The best server to drop into: lowest ping among servers that have room and at
/// least one player (so it's a live game), falling back to the emptiest if none of
/// them report a ping.
pub fn best_overall(servers: &[Server]) -> Option<&Server> {
    servers
        .iter()
        .filter(|s| !s.is_full() && s.players > 0 && s.ping.is_some())
        .min_by_key(|s| s.ping)
        .or_else(|| emptiest(servers))
}

/// Like `visible`, but can also drop high-ping and unknown-ping servers.
pub fn visible_filtered(
    servers: &[Server],
    sort: Sort,
    hide_full: bool,
    low_ping_only: bool,
) -> Vec<Server> {
    const LOW_PING_MS: u32 = 120;
    let shown = visible(servers, sort, hide_full);
    if low_ping_only {
        shown.into_iter().filter(|s| s.ping.map_or(false, |p| p <= LOW_PING_MS)).collect()
    } else {
        shown
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sv(id: &str, p: u32, ping: Option<u32>) -> Server {
        Server { id: id.into(), players: p, max_players: 20, ping }
    }

    fn sample() -> Vec<Server> {
        vec![sv("a", 3, Some(38)), sv("b", 20, Some(10)), sv("c", 9, None), sv("d", 1, Some(95))]
    }

    #[test]
    fn hides_full_and_sorts() {
        let ids = |v: Vec<Server>| v.into_iter().map(|s| s.id).collect::<Vec<_>>();
        assert_eq!(ids(visible(&sample(), Sort::FewestPlayers, true)), ["d", "a", "c"]);
        assert_eq!(ids(visible(&sample(), Sort::MostPlayers, false)), ["b", "c", "a", "d"]);
        assert_eq!(ids(visible(&sample(), Sort::BestPing, true)), ["a", "d", "c"]);
    }

    #[test]
    fn quick_join_picks() {
        let s = sample();
        assert_eq!(best_ping(&s).unwrap().id, "a");
        assert_eq!(emptiest(&s).unwrap().id, "d");
        assert!(best_ping(&[]).is_none());
    }

    #[test]
    fn best_overall_prefers_low_ping_with_room() {
        let s = sample();
        assert_eq!(best_overall(&s).unwrap().id, "a"); // lowest ping, has room + players
        assert!(best_overall(&[]).is_none());
    }

    #[test]
    fn low_ping_filter_drops_unknown_and_high_ping() {
        let s = sample();
        let shown = visible_filtered(&s, Sort::BestPing, false, true);
        // c has no ping → dropped; a(38) and d(95) stay (both ≤ 120); b is full but
        // hide_full is false so it stays only if it had a ping — b has none? b has 10.
        assert!(shown.iter().all(|sv| sv.ping.map_or(false, |p| p <= 120)));
        assert!(!shown.iter().any(|sv| sv.id == "c"));
    }
}
