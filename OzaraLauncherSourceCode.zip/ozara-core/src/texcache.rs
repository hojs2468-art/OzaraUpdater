//! Pure helpers for the Roblox texture-cache downscaler.
//!
//! Roblox streams a game's assets (textures, decals, meshes) into a local HTTP
//! cache the first time you load the game. The files there are named by a
//! content hash, not by asset id, so you can't pick one out by id — but you
//! *can* shrink the image blobs in place to cut texture detail and VRAM. This
//! module holds only the decision logic (which files are PNGs, what size to
//! shrink to); the actual decode/resize/encode lives in `ozara-app`, which has
//! the `image` crate. No cheats, no injection — just rewriting local files.
//!
//! It's reversible: clearing the Roblox cache makes Roblox re-download the
//! originals at full resolution.

use std::path::PathBuf;

/// The 8-byte PNG file signature.
pub const PNG_SIG: [u8; 8] = [0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A];

/// The 3-byte JPEG start-of-image + marker prefix.
pub const JPEG_SIG: [u8; 3] = [0xFF, 0xD8, 0xFF];

/// Modern Roblox wraps each cached asset in an "RBXH" container: a fixed 37-byte
/// header, then the raw asset body (PNG/JPEG/WebP/KTX/mesh/audio). For an inline
/// entry the body length is a little-endian u32 at offset 25 and the body starts
/// at offset 37. (Some entries are "link" files whose body is a CDN URL — those
/// carry a non-zero length at offset 8 and we leave them alone.)
pub const RBXH_HEADER: usize = 37;
pub const RBXH_CLEN_OFFSET: usize = 25;

fn u32_le(b: &[u8], o: usize) -> u32 {
    u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]])
}

/// If `file` (whose full length on disk is `file_len`) is an inline RBXH v2
/// container, returns the body's start offset. `None` for raw files, link
/// files, or anything whose declared body length doesn't match — so a structure
/// we don't understand is never rewritten.
pub fn rbxh_inline_body(file: &[u8], file_len: usize) -> Option<usize> {
    if file.len() < RBXH_HEADER || &file[0..4] != b"RBXH" {
        return None;
    }
    if u32_le(file, 4) != 2 || u32_le(file, 8) != 0 {
        return None; // not version 2, or a link entry
    }
    let clen = u32_le(file, RBXH_CLEN_OFFSET) as usize;
    if clen != file_len - RBXH_HEADER {
        return None; // structure doesn't line up — don't touch it
    }
    Some(RBXH_HEADER)
}

/// Rebuilds an RBXH container around a new (smaller) body, keeping the header
/// byte-for-byte except the content-length field at offset 25.
pub fn rbxh_rewrap(original: &[u8], new_body: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(RBXH_HEADER + new_body.len());
    out.extend_from_slice(&original[..RBXH_CLEN_OFFSET]); // 0..25
    out.extend_from_slice(&(new_body.len() as u32).to_le_bytes()); // 25..29
    out.extend_from_slice(&original[RBXH_CLEN_OFFSET + 4..RBXH_HEADER]); // 29..37
    out.extend_from_slice(new_body);
    out
}

/// Which raw image format a cache entry is, when its signature is at byte 0.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum RawFmt {
    Png,
    Jpeg,
}

/// Classifies a file by its leading bytes: a raw PNG/JPEG we can rewrite, or
/// `None` for anything else (wrapped entries, meshes, audio, …).
pub fn raw_fmt(head: &[u8]) -> Option<RawFmt> {
    if head.len() >= 8 && head[..8] == PNG_SIG {
        Some(RawFmt::Png)
    } else if head.len() >= 3 && head[..3] == JPEG_SIG {
        Some(RawFmt::Jpeg)
    } else {
        None
    }
}

/// Candidate Roblox asset-cache directories, newest layout first. Pass
/// `%LOCALAPPDATA%` and `%TEMP%` (either may be empty). The caller keeps only
/// the ones that actually exist.
pub fn cache_dirs(local_appdata: &str, temp: &str) -> Vec<PathBuf> {
    let mut v = Vec::new();
    if !local_appdata.is_empty() {
        v.push(
            PathBuf::from(local_appdata)
                .join("Roblox")
                .join("rbx-storage"),
        );
    }
    if !temp.is_empty() {
        v.push(PathBuf::from(temp).join("Roblox").join("http"));
    }
    v
}

/// Byte offset of the PNG signature within `buf`, scanning only the first
/// `window` bytes (a cache entry may carry a short wrapper before the image).
/// Returns `None` if the signature isn't in that window.
pub fn png_offset(buf: &[u8], window: usize) -> Option<usize> {
    if buf.len() < PNG_SIG.len() {
        return None;
    }
    let last = buf.len() - PNG_SIG.len();
    let stop = window.min(last);
    (0..=stop).find(|&i| buf[i..i + PNG_SIG.len()] == PNG_SIG)
}

/// Reads `(width, height)` straight out of a PNG's IHDR chunk, given a slice
/// that starts at the PNG signature. Cheap — no decoding, just the header.
pub fn png_dims(png: &[u8]) -> Option<(u32, u32)> {
    // signature(8) + chunk-length(4) + "IHDR"(4) + width(4) + height(4) = 24
    if png.len() < 24 || png[..8] != PNG_SIG || &png[12..16] != b"IHDR" {
        return None;
    }
    let w = u32::from_be_bytes([png[16], png[17], png[18], png[19]]);
    let h = u32::from_be_bytes([png[20], png[21], png[22], png[23]]);
    Some((w, h))
}

/// Reads `(width, height)` from a JPEG by walking its segment markers to the
/// start-of-frame (SOF). Needs enough of the file to reach the SOF — large
/// EXIF blocks can push it past a short header. `None` if not found in `buf`.
pub fn jpeg_dims(buf: &[u8]) -> Option<(u32, u32)> {
    if buf.len() < 4 || buf[0] != 0xFF || buf[1] != 0xD8 {
        return None;
    }
    let mut i = 2usize;
    while i + 9 <= buf.len() {
        if buf[i] != 0xFF {
            i += 1;
            continue;
        }
        // Skip fill bytes (a run of 0xFF) to land on the marker code.
        let mut m = i + 1;
        while m < buf.len() && buf[m] == 0xFF {
            m += 1;
        }
        if m >= buf.len() {
            return None;
        }
        let marker = buf[m];
        // Standalone markers (no length word): SOI, EOI, RSTn, TEM.
        if marker == 0xD8 || marker == 0xD9 || (0xD0..=0xD7).contains(&marker) || marker == 0x01 {
            i = m + 1;
            continue;
        }
        if m + 3 > buf.len() {
            return None;
        }
        let len = u16::from_be_bytes([buf[m + 1], buf[m + 2]]) as usize;
        // SOF0..SOF15 carry the frame size; DHT(C4), JPG(C8), DAC(CC) do not.
        let is_sof =
            (0xC0..=0xCF).contains(&marker) && marker != 0xC4 && marker != 0xC8 && marker != 0xCC;
        if is_sof {
            if m + 8 > buf.len() {
                return None;
            }
            // after marker: len(2) precision(1) height(2) width(2)
            let h = u16::from_be_bytes([buf[m + 4], buf[m + 5]]) as u32;
            let w = u16::from_be_bytes([buf[m + 6], buf[m + 7]]) as u32;
            return Some((w, h));
        }
        i = m + 1 + len;
    }
    None
}

/// Whether an image this size is worth shrinking: only if its larger side is
/// above the floor.
pub fn should_downscale(w: u32, h: u32, floor: u32) -> bool {
    w.max(h) > floor
}

/// Target `(width, height)` so the larger side is at most `cap` pixels, keeping
/// aspect ratio. `cap == 0` means "original" (no change), and an image already
/// within the cap is returned unchanged.
pub fn cap_dims(w: u32, h: u32, cap: u32) -> (u32, u32) {
    if cap == 0 {
        return (w, h);
    }
    let big = w.max(h);
    if big <= cap {
        return (w, h);
    }
    let scale = cap as f64 / big as f64;
    let nw = ((w as f64 * scale).round() as u32).max(1);
    let nh = ((h as f64 * scale).round() as u32).max(1);
    (nw, nh)
}

/// Target `(width, height)` for a downscale by integer `factor` (2 = half, and
/// so on), never letting the larger side fall below `floor` and never below
/// 1px. Returns the original size unchanged when there's nothing worth doing.
pub fn target_dims(w: u32, h: u32, factor: u32, floor: u32) -> (u32, u32) {
    let factor = factor.max(2);
    let big = w.max(h);
    if big <= floor {
        return (w, h);
    }
    let mut target_big = (big / factor).max(1);
    if target_big < floor {
        target_big = floor;
    }
    if target_big >= big {
        return (w, h);
    }
    let scale = target_big as f64 / big as f64;
    let nw = ((w as f64 * scale).round() as u32).max(1);
    let nh = ((h as f64 * scale).round() as u32).max(1);
    (nw, nh)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cache_dirs_builds_both_when_present() {
        let v = cache_dirs("C:\\LA", "C:\\T");
        assert_eq!(v.len(), 2);
        assert!(v[0].ends_with("rbx-storage"));
        assert!(v[1].ends_with("http"));
    }

    #[test]
    fn cache_dirs_skips_empty_roots() {
        assert_eq!(cache_dirs("", "").len(), 0);
        assert_eq!(cache_dirs("C:\\LA", "").len(), 1);
    }

    #[test]
    fn png_offset_finds_signature() {
        let mut buf = vec![0u8; 16];
        buf[..8].copy_from_slice(&PNG_SIG);
        assert_eq!(png_offset(&buf, 64), Some(0));

        let mut wrapped = vec![1u8, 2, 3, 4];
        wrapped.extend_from_slice(&PNG_SIG);
        wrapped.extend_from_slice(&[0u8; 8]);
        assert_eq!(png_offset(&wrapped, 64), Some(4));

        assert_eq!(png_offset(&[0u8; 32], 64), None);
        assert_eq!(png_offset(&[0u8; 2], 64), None);
    }

    #[test]
    fn png_offset_respects_window() {
        let mut wrapped = vec![0u8; 100];
        wrapped[50..58].copy_from_slice(&PNG_SIG);
        assert_eq!(png_offset(&wrapped, 10), None);
        assert_eq!(png_offset(&wrapped, 64), Some(50));
    }

    #[test]
    fn png_dims_reads_ihdr() {
        let mut png = Vec::new();
        png.extend_from_slice(&PNG_SIG);
        png.extend_from_slice(&[0, 0, 0, 13]); // chunk length
        png.extend_from_slice(b"IHDR");
        png.extend_from_slice(&2048u32.to_be_bytes());
        png.extend_from_slice(&1024u32.to_be_bytes());
        assert_eq!(png_dims(&png), Some((2048, 1024)));
    }

    #[test]
    fn png_dims_rejects_non_png() {
        assert_eq!(png_dims(&[0u8; 24]), None);
    }

    #[test]
    fn cap_dims_caps_larger_side() {
        assert_eq!(cap_dims(1024, 1024, 256), (256, 256));
        assert_eq!(cap_dims(1000, 500, 256), (256, 128));
        assert_eq!(cap_dims(585, 559, 512), (512, 489));
    }

    #[test]
    fn cap_dims_leaves_small_or_original() {
        assert_eq!(cap_dims(200, 200, 256), (200, 200)); // already under
        assert_eq!(cap_dims(2048, 2048, 0), (2048, 2048)); // 0 = original
    }

    #[test]
    fn target_dims_halves_large_texture() {
        assert_eq!(target_dims(2048, 1024, 2, 256), (1024, 512));
    }

    #[test]
    fn target_dims_pins_to_floor() {
        // 300px larger side, factor 2 would give 150 < 256 floor, so pin to 256.
        let (w, h) = target_dims(300, 200, 2, 256);
        assert_eq!(w.max(h), 256);
        assert_eq!((w, h), (256, 171));
    }

    #[test]
    fn target_dims_leaves_small_images_alone() {
        assert_eq!(target_dims(256, 256, 2, 256), (256, 256));
        assert_eq!(target_dims(128, 64, 4, 256), (128, 64));
    }

    #[test]
    fn target_dims_quarter() {
        assert_eq!(target_dims(1024, 1024, 4, 64), (256, 256));
    }

    fn fake_rbxh(body: &[u8]) -> Vec<u8> {
        let mut f = Vec::new();
        f.extend_from_slice(b"RBXH");
        f.extend_from_slice(&2u32.to_le_bytes()); // version
        f.extend_from_slice(&0u32.to_le_bytes()); // linklen 0 = inline
        f.extend_from_slice(&[0u8; 13]); // offsets 12..25 boilerplate
        f.extend_from_slice(&(body.len() as u32).to_le_bytes()); // clen @25
        f.extend_from_slice(&[0xDEu8, 0xAD, 0xBE, 0xEF, 0, 0, 0, 0]); // 29..37
        f.extend_from_slice(body);
        f
    }

    #[test]
    fn rbxh_inline_body_validates_structure() {
        let body = vec![1u8; 100];
        let file = fake_rbxh(&body);
        assert_eq!(rbxh_inline_body(&file, file.len()), Some(RBXH_HEADER));
        // wrong total length -> rejected
        assert_eq!(rbxh_inline_body(&file, file.len() + 1), None);
        // not RBXH -> rejected
        assert_eq!(rbxh_inline_body(&[0u8; 64], 64), None);
    }

    #[test]
    fn rbxh_rewrap_is_byte_exact_for_same_body() {
        let body = vec![7u8; 80];
        let file = fake_rbxh(&body);
        assert_eq!(rbxh_rewrap(&file, &body), file);
    }

    #[test]
    fn rbxh_rewrap_updates_length() {
        let body = vec![7u8; 80];
        let file = fake_rbxh(&body);
        let smaller = vec![9u8; 30];
        let out = rbxh_rewrap(&file, &smaller);
        assert_eq!(rbxh_inline_body(&out, out.len()), Some(RBXH_HEADER));
        assert_eq!(&out[RBXH_HEADER..], &smaller[..]);
        assert_eq!(&out[29..37], &file[29..37]); // mystery bytes preserved
    }

    #[test]
    fn raw_fmt_detects_png_and_jpeg() {
        let mut png = vec![0u8; 8];
        png.copy_from_slice(&PNG_SIG);
        assert_eq!(raw_fmt(&png), Some(RawFmt::Png));
        assert_eq!(raw_fmt(&[0xFF, 0xD8, 0xFF, 0xE0]), Some(RawFmt::Jpeg));
        assert_eq!(raw_fmt(&[0u8; 16]), None);
    }

    #[test]
    fn jpeg_dims_reads_sof() {
        // SOI, then APP0 segment, then SOF0 with 640x480.
        let mut j = vec![0xFF, 0xD8];
        j.extend_from_slice(&[0xFF, 0xE0, 0x00, 0x04, 0x11, 0x22]); // APP0, len 4
        j.extend_from_slice(&[0xFF, 0xC0, 0x00, 0x11, 0x08]); // SOF0, len, precision
        j.extend_from_slice(&480u16.to_be_bytes()); // height
        j.extend_from_slice(&640u16.to_be_bytes()); // width
        j.extend_from_slice(&[0u8; 8]);
        assert_eq!(jpeg_dims(&j), Some((640, 480)));
    }

    #[test]
    fn jpeg_dims_rejects_non_jpeg() {
        assert_eq!(jpeg_dims(&[0u8; 32]), None);
    }

    #[test]
    fn should_downscale_threshold() {
        assert!(should_downscale(512, 128, 256));
        assert!(!should_downscale(256, 256, 256));
        assert!(!should_downscale(100, 100, 256));
    }
}
