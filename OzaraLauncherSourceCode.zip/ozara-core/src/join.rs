//! Building the official `roblox://` link that opens the real Roblox client.

/// True if `s` is a non-empty run of ASCII digits (a place or universe id).
pub fn is_numeric_id(s: &str) -> bool {
    !s.is_empty() && s.len() <= 20 && s.bytes().all(|b| b.is_ascii_digit())
}

/// True for a server (job) id: hex digits and dashes only, like a UUID.
pub fn is_job_id(s: &str) -> bool {
    !s.is_empty() && s.len() <= 64 && s.bytes().all(|b| b.is_ascii_hexdigit() || b == b'-')
}

/// Link that joins a game. With a job id it asks for that exact server.
/// Returns None if either id looks wrong, so nothing odd is ever passed to the OS.
pub fn join_link(place_id: &str, job_id: Option<&str>) -> Option<String> {
    if !is_numeric_id(place_id) {
        return None;
    }
    match job_id {
        None => Some(format!("roblox://experiences/start?placeId={place_id}")),
        Some(job) if is_job_id(job) => Some(format!(
            "roblox://experiences/start?placeId={place_id}&gameInstanceId={job}"
        )),
        Some(_) => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plain_and_server_links() {
        assert_eq!(
            join_link("1818", None).unwrap(),
            "roblox://experiences/start?placeId=1818"
        );
        assert_eq!(
            join_link("1818", Some("a41f9c2e-0b7d-4c11-9a52-0c3d4e5f6a7b")).unwrap(),
            "roblox://experiences/start?placeId=1818&gameInstanceId=a41f9c2e-0b7d-4c11-9a52-0c3d4e5f6a7b"
        );
    }

    #[test]
    fn rejects_bad_input() {
        assert!(join_link("18 18", None).is_none());
        assert!(join_link("1818&evil=1", None).is_none());
        assert!(join_link("1818", Some("abc&x=1")).is_none());
        assert!(join_link("", None).is_none());
    }
}
