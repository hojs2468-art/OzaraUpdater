//! Where Ozara's builds live, and how the installer and updater find them.
//!
//! Ozara distributes itself through GitHub Releases: you upload `ozara.exe` as an
//! asset on each release, and tag the release with the version (e.g. `v0.2.26`).
//! The installer downloads the newest `ozara.exe`; the updater asks GitHub which
//! version is newest and compares it with the running one.

/// Master switch for the online updater. Left OFF for now — Ozara won't contact
/// GitHub at all while this is false. Flip it to `true` once you've created the
/// repo below and published a release, and the Updates page turns on.
pub const UPDATES_ENABLED: bool = true;

/// Your GitHub repository, as `owner/name`.
///
/// CHANGE THIS to your own repo before building the installer or publishing an
/// update. It must be a public repo with Releases that each attach an `ozara.exe`.
pub const GITHUB_REPO: &str = "hojs2468-art/OzaraUpdater";

/// The exact asset file name uploaded to each release.
pub const ASSET_NAME: &str = "ozara.exe";

/// GitHub API URL for the latest release (returns JSON with `tag_name`).
pub fn latest_release_api() -> String {
    format!("https://api.github.com/repos/{GITHUB_REPO}/releases/latest")
}

/// Direct download URL for the newest `ozara.exe` (GitHub redirects this to the
/// actual asset of whatever release is currently "latest").
pub fn latest_exe_url() -> String {
    format!("https://github.com/{GITHUB_REPO}/releases/latest/download/{ASSET_NAME}")
}

/// Pulls the version tag out of the GitHub "latest release" JSON, without needing
/// a JSON library: it just finds the `"tag_name"` field. Returns e.g. `v0.2.26`.
pub fn tag_from_release_json(json: &str) -> Option<String> {
    let key = "\"tag_name\"";
    let i = json.find(key)? + key.len();
    let rest = &json[i..];
    let colon = rest.find(':')?;
    let after = &rest[colon + 1..];
    let open = after.find('"')? + 1;
    let tail = &after[open..];
    let close = tail.find('"')?;
    Some(tail[..close].trim().to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builds_urls() {
        assert!(latest_release_api().contains("/repos/"));
        assert!(latest_exe_url().ends_with("ozara.exe"));
    }

    #[test]
    fn reads_tag_from_json() {
        let json = r#"{"url":"x","tag_name": "v0.2.26" ,"name":"Ozara"}"#;
        assert_eq!(tag_from_release_json(json).as_deref(), Some("v0.2.26"));
        assert_eq!(tag_from_release_json("{}"), None);
    }
}
