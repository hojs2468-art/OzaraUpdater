//! Ozara core: everything that does not need a window or the network.
//! Standard library only, so it can be tested anywhere.

pub mod flags;
pub mod fps;
pub mod join;
pub mod logs;
pub mod oauth;
pub mod paths;
pub mod playtime;
pub mod release;
pub mod servers;
pub mod texcache;
pub mod version;
