//! Pure helpers for Roblox's OAuth 2.0 sign-in (authorization code flow with PKCE).
//! Randomness and hashing live in the app; everything here is plain string work.

/// Percent-encode everything except RFC 3986 unreserved characters.
pub fn percent_encode(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'.' | b'_' | b'~' => out.push(b as char),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

pub fn percent_decode(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'%' if i + 2 < bytes.len() => {
                let hex = std::str::from_utf8(&bytes[i + 1..i + 3]).ok().and_then(|h| u8::from_str_radix(h, 16).ok());
                match hex {
                    Some(v) => {
                        out.push(v);
                        i += 3;
                    }
                    None => {
                        out.push(b'%');
                        i += 1;
                    }
                }
            }
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            b => {
                out.push(b);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// URL that sends the user to Roblox's consent page.
/// Scopes requested: identity (openid, profile) plus two read-only extras —
/// user.advanced:read (premium/verified status) and user.social:read (linked
/// social accounts). Both are visible on Roblox's own consent screen; the user
/// can decline them there and Ozara still works with just identity.
pub fn authorize_url(client_id: &str, redirect_uri: &str, code_challenge: &str, state: &str) -> String {
    format!(
        "https://apis.roblox.com/oauth/v1/authorize?client_id={}&redirect_uri={}&scope=openid%20profile%20user.advanced%3Aread%20user.social%3Aread&response_type=code&code_challenge={}&code_challenge_method=S256&state={}",
        percent_encode(client_id),
        percent_encode(redirect_uri),
        percent_encode(code_challenge),
        percent_encode(state)
    )
}

/// What the browser sent back to Ozara's local redirect address.
#[derive(Debug, PartialEq, Eq)]
pub enum Callback {
    Code { code: String, state: String },
    Denied(String),
    /// Some other request (favicon and so on): ignore it.
    Other,
}

/// Parse the first line of an HTTP request, e.g. `GET /callback?code=..&state=.. HTTP/1.1`.
pub fn parse_callback(request: &str) -> Callback {
    let line = request.lines().next().unwrap_or("");
    let mut parts = line.split_whitespace();
    if parts.next() != Some("GET") {
        return Callback::Other;
    }
    let target = parts.next().unwrap_or("");
    let (path, query) = target.split_once('?').unwrap_or((target, ""));
    if path != "/callback" {
        return Callback::Other;
    }
    let mut code = None;
    let mut state = None;
    let mut error = None;
    for pair in query.split('&') {
        let (k, v) = pair.split_once('=').unwrap_or((pair, ""));
        match k {
            "code" => code = Some(percent_decode(v)),
            "state" => state = Some(percent_decode(v)),
            "error" => error = Some(percent_decode(v)),
            _ => {}
        }
    }
    if let Some(e) = error {
        return Callback::Denied(e);
    }
    match (code, state) {
        (Some(code), Some(state)) => Callback::Code { code, state },
        _ => Callback::Other,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn encodes_and_decodes() {
        assert_eq!(percent_encode("http://localhost:1/cb"), "http%3A%2F%2Flocalhost%3A1%2Fcb");
        assert_eq!(percent_decode("a%20b+c%3D"), "a b c=");
        assert_eq!(percent_decode("100%"), "100%");
        assert_eq!(percent_decode("%zz"), "%zz");
    }

    #[test]
    fn builds_url() {
        let u = authorize_url("123", "http://localhost:53682/callback", "CH", "ST");
        assert!(u.starts_with("https://apis.roblox.com/oauth/v1/authorize?client_id=123&"));
        assert!(u.contains("redirect_uri=http%3A%2F%2Flocalhost%3A53682%2Fcallback"));
        assert!(u.contains("scope=openid%20profile"));
        assert!(u.contains("code_challenge_method=S256"));
        assert!(u.ends_with("state=ST"));
    }

    #[test]
    fn parses_callbacks() {
        assert_eq!(
            parse_callback("GET /callback?code=abc%2D1&state=xyz HTTP/1.1\r\nHost: localhost"),
            Callback::Code { code: "abc-1".into(), state: "xyz".into() }
        );
        assert_eq!(
            parse_callback("GET /callback?error=access_denied&state=x HTTP/1.1"),
            Callback::Denied("access_denied".into())
        );
        assert_eq!(parse_callback("GET /favicon.ico HTTP/1.1"), Callback::Other);
        assert_eq!(parse_callback("POST /callback?code=a&state=b HTTP/1.1"), Callback::Other);
        assert_eq!(parse_callback("GET /callback HTTP/1.1"), Callback::Other);
    }
}
