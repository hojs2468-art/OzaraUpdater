// Gives OzaraSetup.exe the Ozara icon, same as the main app.
fn main() {
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows") {
        let mut res = winres::WindowsResource::new();
        res.set_icon("../ozara-app/assets/ozara.ico");
        if let Err(e) = res.compile() {
            println!("cargo:warning=Could not embed the installer icon: {e}");
        }
    }
}
