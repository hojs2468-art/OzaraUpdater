//! OzaraSetup — the installer.
//!
//! Downloads the newest `ozara.exe` from GitHub Releases and installs it for the
//! current user (no admin needed): into `%LOCALAPPDATA%\Ozara`, with Start-menu
//! and Desktop shortcuts, then offers to launch it. It only ever writes inside
//! the user's own folders and downloads one file over HTTPS — nothing else.

use ozara_core::release;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

fn main() {
    println!("Ozara installer");
    println!("---------------");
    if let Err(e) = run() {
        eprintln!("\nInstall failed: {e}");
        pause("Press Enter to close.");
        std::process::exit(1);
    }
}

fn run() -> Result<(), String> {
    let dir = install_dir()?;
    std::fs::create_dir_all(&dir).map_err(|e| format!("Could not create {}: {e}", dir.display()))?;
    let exe_path = dir.join("ozara.exe");

    println!("Downloading the latest Ozara from GitHub…");
    let bytes = download(&release::latest_exe_url())?;
    // A GitHub "no release yet" page comes back as HTML, not an .exe; catch that
    // instead of writing a broken file.
    if bytes.len() < 4 || &bytes[..2] != b"MZ" {
        return Err(
            "The download didn't look like an Ozara program. Make sure a release with ozara.exe exists on GitHub."
                .into(),
        );
    }
    write_file(&exe_path, &bytes)?;
    println!("Installed to {}", exe_path.display());

    // Shortcuts (best-effort — a failure here doesn't fail the install).
    if let Err(e) = make_shortcuts(&exe_path) {
        println!("(Could not create shortcuts: {e})");
    } else {
        println!("Added Start-menu and Desktop shortcuts.");
    }

    println!("\nDone! Ozara is installed.");
    if ask_yes_no("Launch Ozara now? [Y/n] ") {
        let _ = Command::new(&exe_path).spawn();
    }
    Ok(())
}

/// `%LOCALAPPDATA%\Ozara`.
fn install_dir() -> Result<PathBuf, String> {
    std::env::var_os("LOCALAPPDATA")
        .map(|p| PathBuf::from(p).join("Ozara"))
        .ok_or_else(|| "Could not find your local app-data folder.".into())
}

fn download(url: &str) -> Result<Vec<u8>, String> {
    let resp = ureq::get(url)
        .set("User-Agent", "OzaraSetup")
        .call()
        .map_err(|e| format!("Download failed: {e}"))?;
    let mut buf = Vec::new();
    resp.into_reader()
        .read_to_end(&mut buf)
        .map_err(|e| format!("Could not read the download: {e}"))?;
    Ok(buf)
}

fn write_file(path: &Path, bytes: &[u8]) -> Result<(), String> {
    std::fs::write(path, bytes).map_err(|e| format!("Could not write {}: {e}", path.display()))
}

/// Makes `.lnk` shortcuts via PowerShell (no extra crates, no COM boilerplate).
fn make_shortcuts(exe: &Path) -> Result<(), String> {
    let targets = [
        shortcut_path("APPDATA", r"Microsoft\Windows\Start Menu\Programs\Ozara.lnk"),
        shortcut_path("USERPROFILE", r"Desktop\Ozara.lnk"),
    ];
    for target in targets.into_iter().flatten() {
        if let Some(parent) = target.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        let script = format!(
            "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{}');\
             $s.TargetPath='{}';$s.WorkingDirectory='{}';$s.IconLocation='{}';$s.Save()",
            target.display(),
            exe.display(),
            exe.parent().unwrap_or(exe).display(),
            exe.display(),
        );
        let status = powershell(&script);
        if !matches!(status, Ok(true)) {
            return Err("PowerShell could not create a shortcut.".into());
        }
    }
    Ok(())
}

fn shortcut_path(base_env: &str, rel: &str) -> Option<PathBuf> {
    std::env::var_os(base_env).map(|b| PathBuf::from(b).join(rel))
}

#[cfg(windows)]
fn powershell(script: &str) -> Result<bool, String> {
    use std::os::windows::process::CommandExt;
    Command::new("powershell")
        .creation_flags(0x0800_0000) // CREATE_NO_WINDOW
        .args(["-NoProfile", "-NonInteractive", "-Command", script])
        .status()
        .map(|s| s.success())
        .map_err(|e| e.to_string())
}

#[cfg(not(windows))]
fn powershell(_script: &str) -> Result<bool, String> {
    Err("not Windows".into())
}

fn ask_yes_no(prompt: &str) -> bool {
    print!("{prompt}");
    let _ = io::stdout().flush();
    let mut line = String::new();
    if io::stdin().read_line(&mut line).is_err() {
        return false;
    }
    let a = line.trim().to_lowercase();
    a.is_empty() || a == "y" || a == "yes"
}

fn pause(prompt: &str) {
    print!("{prompt}");
    let _ = io::stdout().flush();
    let mut s = String::new();
    let _ = io::stdin().read_line(&mut s);
}
